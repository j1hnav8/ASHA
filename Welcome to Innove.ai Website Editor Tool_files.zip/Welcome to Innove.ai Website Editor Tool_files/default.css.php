/*============== Body ==============*/
/* Responsive css */

@media only screen and (max-width: 640px) {
    .embed-container {
        padding-bottom: 0% !important;
    }
}
@media only screen and (max-width: 960px) {
    .embed-container {
        padding-bottom: 0% !important;
    }
}
@media only screen and (max-width: 1040px) {
    .embed-container {
        padding-bottom: 0% !important;
    }
}

.britcam-shape li{
	font-weight: 800 !important;
}

.widget-section .default-form input[type="text"], .widget-section .default-form input[type="email"], .widget-section .default-form textarea{

    text-align: justify;
}

.social-icons{
	background-color: #a1003b;
    width: 42px;
    height: 42px;
	margin-left: 50px !important;
    margin: 5px;
    display: flow;
	color: whitesmoke;
    border-radius: 100px;
    text-align: center;
    line-height: 45px;
}

@media (max-width:1024px) and (min-width:786px){
	.wb-header .navbar-collapse{
		padding: 0px 240px !important;
	}

	.wb-header .logo{
		z-index: 99999 !important;
		left: 15px !important;
	}

	body .logoWidget span{
		color: black !important;
	}

	.wb-page h1, .wb-footer h1{
		font-size: 38px !important;
	}

	.para-normal{
		text-align: center !important;
	}

	.wb-heroHeader-content h1{
        font-size: 55px !important;
        margin-top: 160px !important;
	}

	.custom-row{
		display: block !important;
	}


	.left-curvy{
		position: absolute !important;
		right: 490px;
	}

	ul.imgs-gallery li{
		width: 300px !important;
	}

	ul.imgs-gallery{
		float: inline-end !important;
		width: 980px !important;
	}

	.wb-heroHeader-content ul li a{
		left: 77px !important;
		position: relative !important;
	}

	.home-section{
		padding: 30px 0px 30px 0px !important	}

	.para-height{
		min-height: 320px !important;
		text-align: right;
	}
	.name-place{
		font-size: 17px !important;
	}

	.main-cards{
		min-height: 350px !important;
	}

	.style-three .techno-sinlge-service-box{
		min-height: 540px !important;
	}

	.corner-img{
		width: 1020px !important;
	}
	
	.home-section-2nd{
		text-align: center !important;
	}

	.about{
		text-align: center;
	}

	.about_area{
		text-align: center;
	}

	.about .sub-image.last{
		right: 187px !important;
		position: relative !important;
	}

	.about .sub-image{
		position: relative;
         right: 168px !important;
	}

	.down-sml{
		margin-top: 5px !important;
		right: 168px;
		position: relative;
	}

	.home-section{
		padding: 0px !important;
	}
	
	.home-section{
		text-align: center !important;
	}



	.wb-heroHeader-content h6{
		font-size: 20px !important;
	}

	.wb-heroHeader-content{
		width: 100% !important;
	}

/* 
	.right-curvy{
		top: 3px !important;
		width: 288px !important;
        left: 481px !important;
	} */

	.section_title{
		margin-top: 20px !important;
	}

	.home-section-img{
		min-height: 100% !important;
	}
	.right-curvy{
		left: 450px !important;
	}

	
	.footer-copyright ul li a{
		right: 40px !important;
	}

}

.logoWidget span{
	color: #000000 !important;
    position: relative;
    margin-top: 7px !important;
    left: 10px;
    z-index: 1000;
}

@media (min-width: 768px) and (max-width: 991.98px) {

	.wb-page form input[type="email"]{
		width: 100% !important;
	}

	.footer-copyright ul li a{
		right: 0px !important;
	    margin-top: 0px !important;
	}
	.ul-links{
		margin-left: -47px !important;
	}

	.wb-footer .footer-content{
		text-align: center !important;
	}

	body .wb-header .logo{
		left: 15px !important;
	}

	body .testimonial-img{
		position: absolute;
		margin-left: 300px;
		margin-top: -30px;	
	}

	body .name-place{        margin-top: 20px !important;}

	.wb-page h1, .wb-footer h1{
		font-size: 36px !important;
	}

	.para-normal{
		text-align: center !important;
	}


	.custom-row{
		display: block !important;
	}


	body .ul-links{
        position: relative;
        left: 260px;
        margin-bottom: 20px;
	}

	.form-box{
    margin-top: 20px !important;
	margin-bottom: 60px !important;
	padding: 40px !important;
	}

	.left-curvy{
		position: absolute;
	}
	
	.wb-heroHeader-content{
        width: 100% !important;
		text-align: center;
	}

	.para-height{
		min-height: 0px !important;
	}

	.style-three .techno-sinlge-service-box{
		min-height: 0px !important;
	}

	.main-cards{
		min-height: 0px !important;
	}

	.home-section{
		padding: 0px !important;
	}
	
	.about .sub-image.last{
		margin-right: 60px !important;
	}

	.down-sml{
        margin-left: -265px !important;
		object-fit: cover !important;
	}

	.about .sub-image{
		margin-left: -265px !important;
	}

	.home-section-2nd{
		text-align: center !important;
	}

	.britcam-shape{
		padding: 5px 35px 0 !important;
	}

	.home-section{
		text-align: center !important;
	}

	
	.left-curvy{
		position: absolute;
		right: 377px !important;
		top: -1px !important;	}

	.about_area{
		text-align: center !important;
	}
/* 
	.right-curvy{
		top: 0px !important;
		left: 362px !important;
		width: 338px !important;
	} */

	.ContactFormWidget input[type="text"], .ContactFormWidget input[type="password"], .ContactFormWidget input[type="email"], .ContactFormWidget textarea, .ContactFormWidget select{
		padding: 0px !important;
	}

	.wb-heroHeader-content h1{
		margin-bottom: 20px !important;
	}

	.wb-heroHeader-content h1{
		text-align: center;
		font-size: 40px !important;
		width: 100% !important;
	}

	.wb-header .navbar-collapse{

	}
}

@media (max-width: 575.98px) and (min-width:321px){
	.custom-row{
		display: block !important;
	}

	body .footer-copyright ul li a{
    right: 0px;
    margin-top: 0px;
	}

	body .testimonial-img{
		margin-left: 160px;
    position: absolute;
    margin-top: -125px;
	}
	body .wb-header .logo{
		left: 15px !important;
	}

	.style-three .techno-sinlge-service-box{
		min-height: auto !important;
	}

	.about .sub-image{    margin-right: 206px !important;}
	.down-sml{    margin-right: 207px !important;object-fit: cover !important;}
	.wb-page h1, .wb-footer h1{
		font-size: 33px !important;
	}

	.para-normal{
		text-align: center !important;
	}



	.right-curvy{
		left: 85px !important;
		max-width: 190px !important;
	}

	.form-box{
		display: none !important;
	}

	.left-curvy{
		max-width: 190px !important;
		left: 8px;
		position: absolute;
	}
	.wb-heroHeader-content ul li a{
		width: 30px !important;
		height: 30px !important;
		line-height: 32px !important;
		font-size: 13px !important;
	
	}
	.home-section{
		padding: 0px !important;
	}

	.main-cards{
		min-height: 0px!important;
	}

	.para-height{
		min-height: 0px !important;
	}

	.britcam-shape{
		width: 60% !important;
		height: 43px !important;
		padding: 10px 36px 0 !important;
	}
	
	/* .right-curvy{
		width: 174px !important;
		left: 208px !important;
	} */

	/* .left-curvy{
		margin-right: 188px !important; 
		width: 170px !important;
	} */

	.about_area{
		text-align: center !important;
	}

		.about .sub-image.last{
		width: 204px !important;
		object-fit: cover !important;
		margin-right: 1px !important;
	}

	/* .right-curvy{
		left: 235px !important;
		width: 170px !important;
	} */

	.home-section-img{
		width: 100% !important;
		object-fit: cover;
		margin-left: -17px !important;
		min-height: 386px !important;

	}

	.home-section-2nd{
		padding: 0px !important;
	}

	.home-section{
		padding: 0px !important;
	}

	.corner-img {    width: 530px !important;}


	.home-section-img{
		width: 100% !important;
		object-fit: cover !important;
	}

	.home-section{
		text-align: center !important;
	}

	.wb-heroHeader-content h6{
		font-size: 13px !important;
		margin-top: 5px !important;
	}

	.wb-heroHeader-content h1{
		font-size: 39px !important;
		margin-top: 70px !important;
	}
}


@media (max-width: 320px){
	.britcam-shape{
		padding: 10px 4px 0 !important;
		width: 70% !important;
	}

	body .wb-header .logo{
		left: 15px !important;
	}

	body .social-icons{
		width: 32px;
		height: 32px;
		margin: 0px;
		line-height: 31px;
	}

	body .name-place{
     text-align: unset !important;
	 margin-top: 0px !important;
	}
	

	.para-normal{
		text-align: center !important;
	}

	.wb-page h1, .wb-footer h1{
		font-size: 30px !important;
	}

	body .footer-copyright ul li a{
		right: 0px;
		margin-top: 0px;
		}


	.form-box{
		display: none !important;
	}


	.custom-row{
		display: block !important;
	}

	body .about .sub-image{     margin-left: -134px !important;}

	.wb-heroHeader-wrapper{
        top: 270px !important;
	}

	.ul-links{
	    right: 87px !important;	
	}

	.right-curvy{
		margin-right: 93px !important;
		max-width: 130px !important;
	}

	.left-curvy{
		position: absolute;
        max-width: 117px !important;
		left: 14px !important;
        height: 197px !important;
	}

	.wb-heroHeader-wrapper{
        transform: translateX(-22%) translateY(-20%) !important
	}

	.wb-heroHeader-content h1{
		width: 100% !important;
	}


	body .about .sub-image.last{
		height: 21rem !important;
		position: relative;
        top: 108px;
        left: 28px;
	}

	body .down-sml{
		min-width: 273px !important;
		object-fit: cover !important;
	}
	
	body .about .sub-image{
		height: 21rem !important;
	}

	/* .right-curvy{
		width: 130px !important;
		left: 155px !important;
	} */

	.home-section{
		padding: 0px !important;
	}


	.wb-heroHeader-content h1{        font-size: 32px !important;}

	.wb-heroHeader-content ul li a{
	    width: 22px !important;
		font-size: 12px !important;
		line-height: 21px !important;
    height: 22px !important;	
	}


	.testimonial-img{
        width: 80px !important;
        height: 80px !important;
        margin-left: 70px !important;

	}
	.corner-img{
		width: 376px !important;
	}

	.breadcrumb-section .title-heading h1{
		right: 22px !important;
		position: relative !important;
	}

	.home-section-img{
		
		object-fit: cover !important;
	}
	

	.home-section-2nd{
		padding: 0px !important;
	}

	.testimonials-cards{
		padding: 10px !important;
	}
	
}

/* Responsive css end */


/* Custom css */
.main-heading{
	text-transform: none;
    width: 601px;
    font-weight: 800;
}

.footer-logo h5{
	text-decoration: none;
    font-family: 'Montserrat';
    color: white !important;
    text-transform: uppercase;
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 10px;
    display: block;
}

.panel-group .panel+.panel{
	margin-top: 0px !important;
}

.qa-img1{
	display: block;
	width: 200px;
    height: 376px;
	position: relative;
	margin-bottom: 10px;
}

.custom-row{
	display: flex;
	align-items: center;
}

.qa-img2{
	width: 200px;
    position: relative;
    top: -385px;
    left: 213px;
    height: 376px;
    margin-bottom: 10px;
}

.qa-img3{
	width: 200px;
    position: relative;
    top: -770px;
	left: 423px;
    height: 376px;
	margin-bottom: 10px;
}

li{
	color: #a1003b;
}

.britcam-shape{
	position: absolute;
    right: 0px;
	opacity: 0.9;
    bottom: 0;
    background: black;
    width: 38%;
    height: 48px;
    padding: 10px 83px 0;
    clip-path: polygon(12% 0%, 100% 0%, 100% 100%, 0% 100%);
}


.breadcumb-content ul li a:before {
    position: absolute;
    content: "";
    right: 5px;
    top: 9px;
    background: #fff;
    width: 16px;
    height: 2px;
    transition: 0.5s;
}


[id*="accordion-"].AccordionWidgetPopup .panel-title, [id*="accordion-"].AccordionWidget .panel-title{
	font-family: 'Montserrat' !important;
}

[id*="accordion-"].accordion-style2 .panel-title a{
    background: #000000;
}

.panel-default>.panel-heading+.panel-collapse>.panel-body{
	min-height: 0px !important;
}

[id*="accordion-"].accordion-style2 .panel-title a{
	font-size: 18px !important;
}
[id*="accordion-"].accordion-style2 .panel-body{
	font-size: 18px !important;
}

body [id*="accordion-"].accordion-style2 .panel-title a{
	background-color: black;
}

body [id*="accordion-"].accordion-style2 .panel-title a.collapsed{
	color: #656565 !important;
	font-size: 18px !important;
}

[id*="accordion-"].accordion-style2 .panel-title a:before, [id*="accordion-"].accordion-style2 .panel-title a.collapsed:before{
	color: #a1003b !important;
}

[id*="accordion-"].accordion-style2 .panel-title a:before, [id*="accordion-"].accordion-style2 .panel-title a.collapsed:before{
	background-color: transparent !important;
}

[id*="accordion-"].accordion-style2 .panel-title:before{
	border-bottom: 0px solid rgba(0, 0, 0, 0) !important;
    border-left: 0px solid #eee !important;
    border-top: 0px solid rgba(0, 0, 0, 0) !important;
}

.main-cards{
	box-shadow: 0 15px 28px 9px rgba(0,0,0,0.09), 0 29px 7px -10px rgba(0,0,0,0.04);
    border-radius: 10px;
	padding: 30px;
	margin-bottom: 30px;
	min-height: 516px;
}

.icons-area{
	color: #ffffff;
    top: 4px;
    font-size: 28px;
    left: -4px;
	position: relative;
}

.testimonial-img{
    width: 70px;
	object-fit: fill;
    height: 70px;
    border-radius: 86px;
}

.daily-hours{
	list-style: none;
	text-decoration: none;
	color: black;
	position: relative;
    right: 52px;
	font-family: 'raleway';
}

figure.effect-sadie img{
	object-fit: cover;
}




.quote-icon{
	border: 1px solid rgb(255, 255, 255);
    width: 60px;
	/* position: relative;
	left: 11px; */
	background: #a1003b;
	margin-bottom: 40px;
    height: 60px;
	font-size: 35px;
    padding: 12px;
    line-height: 42px;
    border-radius: 60px;
}

.left-curvy{
	border-bottom-left-radius: 100px;
	border-top-left-radius: 100px;
	max-width: 250px;

}

.right-curvy{
    max-width: 250px;
	left: 120px;
    position: relative;
	border-bottom-right-radius: 100px;
	border-top-right-radius: 100px;

}

.about {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
	padding: 90px 0px !important;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    gap: 4rem;
}

.about-features{
    list-style: none;
	padding: 10px 10px;
}

.wb-heroHeader-content ul li a span.fa{
	color: white;
}

.about .sub-image.double img:first-child {
    height: 70% !important;
	border-radius: 5px !important;
}
.about .sub-image.double img:last-child {
    height: 31% !important;
	border-radius: 5px !important;
}
.about .sub-image.last {
    height: 47rem !important;
    margin-top: -47rem;
    float: right;
    position: relative;
    margin-right: 19px;
}

.white{
	color: white !important;
}

ul, ol{
	list-style: none;
}

.dynamic-color{
    color: #a1003b !important;
}

.about .content {
    -webkit-box-flex: 1;
    -ms-flex: 1 1 42rem;
    flex: 1 1 42rem;
}

.heading .sub {
    letter-spacing: 0.2rem;
    display: inline-block;
    font-size: 2rem;
    font-weight: 600;
    line-height: 1;
    color: #a1003b;
    margin-bottom: 0.5rem;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-align: end;
    -ms-flex-align: end;
    align-items: flex-end;
    gap: 1rem;
}

.img-slider{
	padding: 70px 0 !important;
}

.about .heading {
    -webkit-box-align: start;
    -ms-flex-align: start;
    -ms-grid-row-align: flex-start;
    align-items: flex-start;
}

.down-sml{
	height: 14.5rem;
	min-width: 214px !important;
	margin-top: 7px;
	object-fit: cover !important;
    border-radius: 5px;
}

.about .sub-image {
    -webkit-box-flex: 1;
    -ms-flex: 1 1 15rem;
    flex: 1 1 15rem;
    height: 32rem !important;
	border-radius: 4px;
    /* display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal; */
    -ms-flex-direction: column;
    flex-direction: column;
    gap: 0.5rem;
}

.about .image {
    -webkit-box-flex: 1;
    -ms-flex: 1 1 42rem;
    flex: 1 1 42rem;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    gap: 0.5rem;
    overflow: hidden;
    position: relative;
}

.corner-img{
	position: relative;
    right: 77px;
	border-right: 60px solid #a1003b;
	border-bottom: 25px solid #a3a3a3;
	border-top: 25px solid #a3a3a3;
    width: 730px;
}

.home-section-2nd{
	height: auto;
	padding: 30px !important;
}
 
.home-section-2ndpara{
	line-height: 35px;
    font-size: 16px;
	margin-top: 100px;

}



.fun-flix-type{
height: auto;
}

.fun-heading{
	text-align: center !important;
	font-weight: bolder !important;
	font-size: 60px !important;
}

.style-three .techno-sinlge-service-box:hover:after{
	height: 100%;
    width: 73%;
}


.style-three .techno-sinlge-service-box:after{
	position: absolute;
    content: "";
    z-index: -1;
    background: #a3a3a3;
    bottom: 0;
    left: 0;
    height: 0%;
    width: 0%;
    clip-path: polygon(0% 0%, 100% 100%, 100% 100%, 0% 100%);
    transition: 1s;
}

.fun-para{
	text-align: center;
	font-size: 20px !important;
}

.color{
	color: #a1003b;
}

.ul-links{
	display: inline-flex;
	margin-left: -45px;
	list-style: none;
	margin-top: 13px;
}

.testimonials-cards {
    padding: 60px 0px 60px 0px ! important;
}


.theme-button-header{
	margin: 0;
    display: inline-block;
    color: #ffffff;
	border: 2px solid #a1003b;
    padding: 13px 24px;
	font-weight: 500;
    font-family: 'Montserrat', sans-serif;
    position: relative;
    line-height: normal;
    cursor: pointer;
    font-size: 14px;
	margin-top: 15px;
    padding: 5px 14px;
	left: 1004px;
    top: -51px;
    font-weight: bold;
    -webkit-border-radius: 100px;
    -moz-border-radius: 100px;
	background-color: #a1003b;
    -ms-border-radius: 100px;
    -o-border-radius: 100px;
    border-radius: 10px;
    -webkit-transition: all .5s;
    -moz-transition: all .5s;
    -o-transition: all .5s;
    transition: all 0.5s;
}

.wb-heroHeader-content ul li a {
    background-color: #a1003b;
    width: 42px;
    height: 42px;
	margin: 5px;
	display: flow;
    border-radius: 100px;
    text-align: center;
    line-height: 45px;
}

.theme-button-header:hover{
	background-color: #a1003b;
	border: 2px solid #a1003b;
	color: rgb(0, 0, 0);
	text-decoration: none;
}

.em-about-counter-title{
	margin-top: 50px;
	text-align: center;
}

.custom-icons{
	font-size: 30px;
	text-align: center;
	margin-top: 40px;
	color: #a1003b;
}

.theme-button-second{
	margin: 0;
	margin-bottom: 20px;
    display: inline-block;
	color: #fff;
    background-color: #a1003b;
    border: 1px solid transparent;
    text-transform: uppercase;
    padding: 8px 20px;
    font-family: 'Montserrat', sans-serif;
    position: relative;
    line-height: normal;
    cursor: pointer;
    font-size: 10px;
    margin-top: 15px;
    font-weight: bold;
    -webkit-border-radius: 100px;
    -moz-border-radius: 100px;
    -ms-border-radius: 100px;
    -o-border-radius: 100px;
    border-radius: 5px;
    -webkit-transition: all .5s;
    -moz-transition: all .5s;
    -o-transition: all .5s;
    transition: all 0.5s;
}

.navbar-default .navbar-nav>li>a:hover, .navbar-default .navbar-nav>li>a:focus{
	color: #a1003b !important;
}

.navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:focus{
	background-color: transparent !important;
}

.theme-button-second:hover{
	text-decoration: none;
	color: rgb(255, 255, 255);
    background-color: transparent;
	border: 1px solid #a1003b;
}

.theme-button-form{
    border: 1px solid black;
    border-radius: 10px;
    width: 100px;
    background: #000000;
    color: white;
    padding: 3px;
}
.widget-section-11-1 .block-contact-info p{
    width: unset !important;
	float: none !important;
}

.widget-section-11-1 .item{
	padding: 30px 30px 30px 30px !important;
}

.widget-section-11-1 .block-social a{
	border: 1px solid black;
	padding-top: 1px !important;
}

.widget-section [class*="theme-dark-color"] label, .widget-section [class*="theme-dark-color"] span, .widget-section [class*="theme-dark-color"] strong, .widget-section [class*="theme-dark-color"] a, .widget-section [class*="theme-dark-color"] p, .widget-section [class*="theme-dark-color"], .widget-section [class*="theme-dark-color"] h1, .widget-section [class*="theme-dark-color"] h2, .widget-section [class*="theme-dark-color"] h3, .widget-section [class*="theme-dark-color"] h4, .widget-section [class*="theme-dark-color"] h5, .widget-section [class*="theme-dark-color"] h6, .widget-section[class*="theme-dark-color"] label, .widget-section[class*="theme-dark-color"] span, .widget-section[class*="theme-dark-color"] strong, .widget-section[class*="theme-dark-color"] a, .widget-section[class*="theme-dark-color"] p, .widget-section[class*="theme-dark-color"], .widget-section[class*="theme-dark-color"] h1, .widget-section[class*="theme-dark-color"] h2, .widget-section[class*="theme-dark-color"] h3, .widget-section[class*="theme-dark-color"] h4, .widget-section[class*="theme-dark-color"] h5, .widget-section[class*="theme-dark-color"] h6, .widget-section[class*="theme-dark-color"] .section-title p{
	color: black !important;
}

.ContactFormWidget input[type="text"], .ContactFormWidget input[type="password"], .ContactFormWidget input[type="email"], .ContactFormWidget textarea, .ContactFormWidget select{
	font-family: FontAwesome, 'Raleway', "Helvetica Neue", Helvetica, Arial, sans-serif !important;
	padding: 5px;
	text-align: center;
	border: 1px solid rgb(93, 93, 93) !important;
	border-radius: 7px;
}

.style-three .techno-sinlge-service-box {
    transition: .5s;
    position: relative;
    z-index: -0;
	min-height: 490px;
    text-align: left;
    background: #19191b;
    box-shadow: 0px 0 6px rgb(26 46 85 / 10%);
    padding: 40px 38px 30px;
    border-radius: 5px;
    margin-bottom: 30px;
}

.style-three .techno-service-icon i:after {
    position: absolute;
    content: "";
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    margin: 0;
    background: #515151;
    border-radius: 50%;
    z-index: -1;
    transform: scale(0);
    transition: 1s;
}

.wb-page section {
	position: relative;
	width: 100%;
	zoom: 1;
	clear: both;
	overflow: hidden;
}

.style-three .techno-service-title h2:before {
    position: absolute;
    content: "";
    left: 0;
    bottom: -18px;
    background: #a1003b;
    width: 43px;
    height: 2px;
    transition: .5s;
}

.style-three .service-button2 a {
    display: inline-block;
	font-family: 'Montserrat';
	text-decoration: none;
    font-weight: 600;
    color: #a1003b;
    margin-top: 7px;
    transition: .5s;
}

.techno-service-title p {
    transition: .5s;
}
.white p {
    color: #fff;
}

.style-three .techno-service-title h2 {
    font-size: 24px;
	color: white;
    margin: 24px 0 38px;
    transition: .5s;
    position: relative;
    z-index: 1;
    line-height: 1.3;
}

.style-three .techno-sinlge-service-box:hover:before {
    height: 100%;
    background: #a1003b;
}

.style-three .techno-service-icon i {
    font-size: 52px;
    color: #a1003b;
    display: inline-block;
    transition: .5s;
    margin: 0;
    height: 90px;
    width: 90px;
    line-height: 90px;
    background: #252526;
    text-align: center;
    border-radius: 50%;
    position: relative;
    z-index: 1;
}

.style-three .techno-service-title h2:before{
	color: white;
}

.style-three .techno-sinlge-service-box:hover .techno-service-title h2:before {
    background: #fff;
}

.style-three .techno-sinlge-service-box:hover .service-button2 a, .style-three .techno-sinlge-service-box:hover .service-button2 span i{
    color: #fff;
}

.techno-sinlge-service-box:hover .techno-service-icon i, .techno-sinlge-service-box:hover .techno-service-title h2, .techno-sinlge-service-box:hover .techno-service-title p{
	color:white;
}


.style-three .techno-sinlge-service-box:before {
    position: absolute;
    content: "";
    z-index: -1;
    width: 100%;
    height: 0;
    background: rgb(168 168 167);
    left: 0;
    bottom: 0;
    transition: .5s;
    border-radius: 5px;
}

.style-three .techno-sinlge-service-box:hover .techno-service-icon i::after {
    background: #5e5d5c;
    transform: scale(1);
}

.form-head{
    font-size: 22px !important;
	text-align: center;
    font-family: 'Montserrat' !important;
	margin-top: -10px !important;
	font-weight: 700 !important;
	color: white !important;
}

.dreamit-section-title h1{
	font-size: 40px;
    color: black;
    font-weight: 700;
    line-height: 1;
}

.dreamit-section-title {
    margin-bottom: 35px;
}


.about_area {
    padding: 60px 0px 60px 0px !important;
}

.home-section-para{
    margin-top: 20px;
}

.home-section-img{
    height: 100%;
    width: 100%;
    min-height: 355px;
	border-radius: 10px;
}

.home-section{
	height: auto;
	background: #f1f1f1 !important;
}


.theme-button-form:hover{
    background-color: #e9c61800;
    border: 1px solid #ffffff;
    color: white;
}

.widget-form-07 .form-box form {
    padding: 50px;
    position: relative;
    text-align: center;
}


.form-box{
    background: #a1003b;
	opacity: 0.9;
	margin-top: 120px;
	padding: 80px;
	font-family: 'Montserrat';
	border-radius: 10px;
}
/*============== Body ==============*/
body {
	background: #fff;
    font-family: 'Montserrat';
	color: #191919;
	font-size: 17px;
	line-height: 27px;
	-webkit-font-smoothing: antialiased;
	-webkit-text-size-adjust: 100%;
}
/*** page Selection ***/
::selection {
	background-color: #4b4b4b;
	color: white;
}

.wb-page a {
	color: #ffffff;
	text-decoration: none;
}
.wb-page a:hover, .wb-page a:focus {
	color: #a1003b;
	text-decoration: none;
	transition: all 0.5s ease;
}
/* headings */
.wb-page h1, .wb-footer h1, .wb-page h2, .wb-footer h2, .wb-page h3, .wb-footer h3, .wb-page h4, .wb-footer h4, .wb-page h5, .wb-footer h5, .wb-page h6, .wb-footer h6 {
	font-family: 'Montserrat', sans-serif;
	font-weight: bold;
	margin-top: 0;
	margin-bottom: 10px;
	/* text-transform: uppercase; */
	color: #000000;
	line-height: 1.5;
}
.wb-page h1, .wb-footer h1 {
	font-size: 40px;
}
.wb-page h2, .wb-footer h2 {
	font-size: 32px;
}
.wb-page h3, .wb-footer h3 {
	font-size: 28px;
}
.wb-page h4, .wb-footer h4 {
	font-size: 24px;
}
.wb-page h5, .wb-footer h5 {
	font-size: 15px;
}
.wb-page h6, .wb-footer h6 {
	font-size: 16px;
}
.wb-page p, .wb-footer p {
	color: #3a393b;
	font-family: 'Montserrat', sans-serif;
	font-weight: normal;
	line-height: 27px;
	font-size: 16px;
	margin: 0 0 5px 0;
	padding: 0;
}


/* buttons
.wb-page .theme-button, .wb-page .theme-button-second {
	margin: 0;
	display: inline-block;
	text-transform: uppercase;
	padding: 13px 24px;
	font-family: 'Montserrat', sans-serif;
	position: relative;
	line-height: normal;
	cursor: pointer;
	font-size: 14px;
	font-weight: bold;
	-webkit-border-radius: 100px;
	-moz-border-radius: 100px;
	-ms-border-radius: 100px;
	-o-border-radius: 100px;
	border-radius: 100px;
	-webkit-transition: all .5s;
	-moz-transition: all .5s;
	-o-transition: all .5s;
	transition: all 0.5s;
}
.wb-page .theme-button {
	color: #fff;
	background-color: #db0dcb;
	border: 1px solid transparent;
}
.wb-page .theme-button:hover {
	background-color: transparent;
	border: 1px solid #db0dcb;
	color: #db0dcb;
}
.wb-page .theme-button-second {
	color: #db0dcb;
	background-color: transparent;
	border: 1px solid #db0dcb;
}
.wb-page .theme-button-second:hover {
	background-color: #db0dcb;
	border: 1px solid #db0dcb;
	text-decoration: none;
	color: #fff;
}
.wb-page .theme-button:focus, .theme-button-second:focus {
	outline: none;
	color: #fff;
} */
/*** sections padding ***/
.wb-page .sec-padding-lg {
	padding: 80px 0;
}
.wb-page .sec-padding-md {
	padding: 60px 0;
}
.wb-page .sec-padding-sm {
	padding: 40px 0;
}
.wb-page .sec-padding-xs {
	padding: 20px 0;
}
/*** sections margin ***/
.wb-page .sec-margin-xl {
	margin: 100px 0;
}
.wb-page .sec-margin-lg {
	margin: 80px 0;
}
.wb-page .sec-margin-md {
	margin: 60px 0;
}
.wb-page .sec-margin-sm {
	margin: 40px 0;
}
.wb-page .sec-margin-xs {
	margin: 20px 0;
}
/*** no padding, no marging ***/
.wb-page .p-0 {
	padding: 0;
}
.wb-page .pt-0 {
	padding-top: 0px;
}
.pb-0 {
	padding-bottom: 0px;
}
.wb-page .pl-0 {
	padding-left: 0px;
}
.pr-0 {
	padding-right: 0px;
}
.wb-page .m-0 {
	margin: 0;
}
.wb-page .mt-0 {
	margin-top: 0px;
}
.mb-0 {
	margin-bottom: 0px;
}
.wb-page .ml-0 {
	margin-left: 0px;
}
.mr-0 {
	margin-right: 0px;
}
/*** Form CSS ***/
.wb-page form {
}
.wb-page form label {
	display: none;
}
.wb-page form input[type="text"] {
	margin-top: 5px;
    text-align: justify;
    padding: 7px !important;
    width: 100%;
    height: 100%;
}
.wb-page form input[type="email"] {
    text-align: justify;
    margin-top: 5px;
    width: 100%;
    padding: 7px !important;
    height: 100%;
}
.wb-page form textarea {      text-align: justify;
    margin-top: 5px;
    width: 100%;
    padding: 7px !important;
    height: 100%;
}
.wb-page form button {
	background-color: black;
	color: white;
	margin-bottom: 10px;
    border-radius: 10px;
    padding: 9px 10px;
	border: 0px solid !important;
}

.wb-page form button:hover{
background-color: white;
color: black;
border: 1px solid #a1003b !important;
}

.wb-page form ::-webkit-input-placeholder { /* Chrome */
color: #ccc;
}
.wb-page form :-ms-input-placeholder { /* IE 10+ */
color: #ccc;
}
.wb-page form ::-moz-placeholder { /* Firefox 19+ */
color: #ccc;
opacity: 1;
}
.wb-page form :-moz-placeholder { /* Firefox 4 - 18 */
color: #ccc;
opacity: 1;
}
.wb-page form input:focus, .wb-page form textarea:focus, .wb-page form select:focus {
	outline: none;
}
/* Custome Classes */
.wb-page .centered-row {
	text-align: center;
}
.wb-page .centered-col {
	display: inline-block;
	float: none;
}
.wb-page .relative {
	position: relative;
}
.wb-page .fixed {
	position: fixed;
}
.wb-page .absolute {
	position: absolute;
}
/*** Home Page CSS ***/
/*============== wb-Header Start ==============*/
.wb-header {
	padding: 10px 0;
	position: fixed;
	height: 66px;
	z-index: 1;
	width: 100%;
}
.wb-header.sticky {
	background: #fff;
	position: fixed;
	-webkit-animation-duration: .5s;
	animation-duration: .5s;
	-webkit-animation-name: sticky-animation;
	animation-name: sticky-animation;
	-webkit-animation-timing-function: ease-out;
	animation-timing-function: ease-out;
	-webkit-animation-fill-mode: both;
	animation-fill-mode: both;
	box-shadow: 0px 0 20px -1px rgba(0, 0, 0, .1);
	-ms-box-shadow: 0px 0 20px -1px rgba(0, 0, 0, .1);
	-moz-box-shadow: 0px 0 20px -1px rgba(0, 0, 0, .1);
	-o-box-shadow: 0px 0 20px -1px rgba(0, 0, 0, .1);
	-webkit-box-shadow: 0px 0 20px -1px rgba(0, 0, 0, .1);
}
@-webkit-keyframes sticky-animation {
 0% {
 opacity: 0;
 -webkit-transform: translateY(-100%);
}
 100% {
 opacity: 1;
 -webkit-transform: translateY(0);
}
}
@keyframes sticky-animation {
 0% {
 opacity: 0;
 transform: translateY(-100%);
}
 100% {
 opacity: 1;
 transform: translateY(0);
}
}
.wb-header.sticky .navbar-nav>li>a, .wb-header.sticky a.navbar-brand {
	color: #000;
}
.wb-header .logo {
	padding: 0;
	background-color: transparent;
	float: left;
	position: relative;
}
.wb-header .logo > a {
	display: block;
}
.wb-header .logo > a > img {
	max-height: 100px;
}
.wb-header .navbar-brand {
	color: #fff;
	float: left;
	height: 50px;
	padding: 15px 10px;
	font-size: 24px;
	font-family: 'Montserrat';sans-serif;
	line-height: 20px;
	font-weight: bold;
}
.wb-header .navbar-brand:hover {
	color: #fff;
}
.wb-header .navbar-default {
	background-color: transparent;
}
.wb-header .navbar {
	border: 0;
	margin-bottom: 0;
	padding: 0;
	min-height: auto;
}
.wb-header .navbar-toggle {
	position: absolute;
	right: 0;
	padding: 10px;
	background-color: transparent;
	background-image: none;
	border: 0;
    width: 36px;
    height: 36px;
	border-radius: 5px;
	padding: 0;
	top: 39%;
	transform: translateY(-50%);
}
.wb-header .navbar-toggle .icon-bar {
    width: 27px;
    height: 4px;
	border-radius: 0;
	display: block;
	margin: 0 auto;
	background-color: #a1003b;
}
/* .wb-header .navbar-toggle:hover, .wb-header .navbar-toggle:focus {
	background-color: #5352ed;
} */
.wb-header .navbar-toggle .icon-bar+.icon-bar {
	margin-top: 4px;
}
.wb-header .navbar-collapse {
	border: 0;
	box-shadow: none;
	-webkit-box-shadow: none;
	padding: 0 15px;
	background: white;
	overflow-x: visible;
}
.wb-header .navbar-collapse.collapse.in {
	overflow-y: auto;
}
.wb-header .navbar-nav {
	margin: 0;
}

.para-height{
	min-height: 260px;
}

.name-place{
	font-weight: 800 !important;
}

.wb-header .navbar-nav>li {
	/* text-transform: uppercase; */
	position: relative;
}
/* .wb-header .navbar-nav>li::after {
	content: '';
	width: 5px;
	height: 5px;
	background-color: #000;
	position: absolute;
	top: 50%;
	transform: translateY(-50%);
	border-radius: 100%;
}
.wb-header .navbar-nav>li:first-child::after {
	content: '';
	display: none;
} */
.wb-header .navbar-nav>li>a {
    color: #000000;
    font-weight: 800;
	font-family: 'Montserrat';
    font-size: 15px;
	padding: 11px 10px;
	font-size: 14px;
}
.wb-header .navbar-button {
	position: absolute;
	right: 0;
	top: 50%;
	transform: translateY(-50%);
}
.wb-header .navbar-button > a {
	font-size: 15px;
	font-weight: 100;
    font-family: 'Montserrat';
	padding: 15px;
	background-color: #3a393b;
	border-radius: 6px;
	color: #fff;
}
.wb-header .navbar-button > a:hover {
	color: #fff;
	text-decoration: none;
}
.wb-header .navbar-button > a > i.fa {
	font-size: 30px;
	margin-right: 10px;
	position: relative;
	top: 4px;
}
.wb-header .navbar-toggle .icon-bar:nth-of-type(3) {
	top: 1px;
}
.wb-header .navbar-toggle .icon-bar:nth-of-type(4) {
	top: 2px;
}
.wb-header .navbar-toggle .icon-bar {
	position: relative;
	transition: all 500ms ease-in-out;
}
.wb-header .navbar-toggle.active .icon-bar:nth-of-type(2) {
	top: 6px;
	transform: rotate(45deg);
}
.wb-header .navbar-toggle.active .icon-bar:nth-of-type(3) {
	background-color: transparent;
}
.wb-header .navbar-toggle.active .icon-bar:nth-of-type(4) {
	top: -6px;
	transform: rotate(-45deg);
}
.wb-header .cl-effect-1.navbar-nav>li>a {
	padding-left: 0;
	padding-right: 0;
}
.wb-header .cl-effect-3.navbar-nav>li>a::after {
	top: 80%;
}
.wb-header .cl-effect-3.navbar-nav>li>a {
	padding: 30px 15px !important;
}
.wb-header .cl-effect-4.navbar-nav>li>a::after {
	top: 80%;
}
.wb-header .cl-effect-4.navbar-nav>li>a {
	padding: 30px 15px !important;
}
.wb-header .cl-effect-6.navbar-nav>li {
	margin: 15px 0;
}
.wb-header .cl-effect-7.navbar-nav>li>a {
	padding: 11px 20px !important;
}
.wb-header .navbar-nav.cl-effect-7 {
	margin: 29px 0;
}
.wb-header .navbar-nav.cl-effect-8 {
	margin: 30px 0;
}
.wb-header .cl-effect-8.navbar-nav>li {
	margin-right: 10px;
}
.wb-header .cl-effect-8.navbar-nav>li>a {
	padding: 10px 15px !important;
}
.wb-header .navbar-nav.cl-effect-12 {
	margin: 25px 0;
}
.wb-header .cl-effect-13.navbar-nav>li>a::before {
	top: 70%;
}
.wb-header .navbar-nav.cl-effect-14 {
	margin: 27px 0px;
}
.wb-header .cl-effect-14.navbar-nav>li>a {
	padding: 0px 15px !important;
}
.wb-header .navbar-nav.cl-effect-21 {
	margin: 28px 0;
}
.wb-header .cl-effect-22.navbar-nav>li>a {
	padding: 30px 15px !important;
}

@media (max-width: 991px) {
.wb-header .navbar {
	z-index: 99999;
}
.wb-header .navbar-header {
	float: none;
}
.wb-header .navbar-left, .navbar-right {
	float: none !important;
}
.wb-header .navbar-toggle {
	display: block;
}
/* .wb-header .navbar-collapse {
	border-top: 1px solid transparent;
	box-shadow: inset 0 1px 0 rgba(255,255,255,0.1);
} */
.wb-header .navbar-fixed-top {
	top: 0;
	border-width: 0 0 1px;
}

.wb-header .navbar-nav {
	float: none!important;
	margin-top: 7.5px;
}
.wb-header .navbar-nav>li {
	float: none;
}
.wb-header .navbar-nav>li::after {
	content: '';
	display: none;
}
.wb-header .navbar-nav>li>a {
	padding-top: 10px;
	padding-bottom: 10px;
	color: black;
}
.wb-header .collapse.in {
	display: block !important;
}
.wb-header .navbar-collapse {
	border: 0;
	position: fixed;
	background-color: #fff;
	width: 220px;
	left: -220px;
	transition: all 0.5s ease;
	top: 0;
	height: 100vh !important;
	z-index: 99999;
	float: left;
	-webkit-box-shadow: 2px 0 10px 0 rgba(0,0,0,0.7);
	box-shadow: 2px 0 10px 0 rgba(0,0,0,0.7);
}
.wb-header .navbar-collapse.collapse.in {
	display: block !important;
	overflow-y: auto;
	left: 0px;
	transition: all 0.5s ease;
}
.wb-header .navbar-button {
	position: static;
	bottom: 0;
	transform: translateY(0);
}
.wb-header .navbar-button > a {
	font-size: 14px;
}
.wb-header .navbar-button > a > i.fa {
	font-size: 24px;
}
.wb-header .navbar-nav.navbar-right:last-child {
	margin-right: 0;
}
.wb-header .cl-effect-8.navbar-nav>li {
	margin-bottom: 10px;
	margin-right: 0;
}
.wb-header .navbar-nav.cl-effect-12 a::before, .wb-header .navbar-nav.cl-effect-12 a::after {
	left: 50px;
}
}
/*============== wb-heroHeader Start ==============*/
.wb-heroHeader {
	padding: 0;
	height: 800px;
	width: 100%;
	position: relative;
}
.wb-heroHeader::before {
	content: '';
	position: absolute;
	top: 0;
	left: 0;
	height: 100%;
	width: 100%;
}
/* .wb-heroHeader-content {
	position: relative;
    width: 623px;    right: 70px;
    top: 0px;
} */
.wb-heroHeader-content h1 {
    color: #fff;
    font-size: 60px;
	margin-top: 90px;
	width: 100%;
    line-height: 120%;
}
.wb-heroHeader-content h6 {
	font-size: 22px;
	margin-bottom: 0;
	text-transform: capitalize;
}
.wb-heroHeader-wrapper {
	-webkit-transform: translateX(-50%) translateY(-50%);
	-moz-transform: translateX(-50%) translateY(-50%);
	-ms-transform: translateX(-50%) translateY(-50%);
	-o-transform: translateX(-50%) translateY(-50%);
	transform: translateX(15%) translateY(-50%);
    width: 60%;
}
/* .wb-heroHeader-content:before, .wb-heroHeader-content:after {
	-moz-transition: all 500ms ease-out;
	-o-transition: all 500ms ease-out;
	-webkit-transition: all 500ms ease-out;
	transition: all 500ms ease-out;
	-ms-transition: all 500ms ease-out;
}
.wb-heroHeader-content:before {
	content: '';
	position: absolute;
	left: 50%;
	display: block;
	width: 500px;
	height: 142px;
	border: 13px solid #5352ed;
	border-bottom: none;
	-webkit-transform: translateX(-50%);
	-moz-transform: translateX(-50%);
	-ms-transform: translateX(-50%);
	-o-transform: translateX(-50%);
	transform: translateX(-50%);
	top: -125px;
}
.wb-heroHeader-content:after {
	content: '';
	position: absolute;
	left: 50%;
	display: block;
	width: 500px;
	height: 142px;
	border: 13px solid #5352ed;
	border-top: none;
	-webkit-transform: translateX(-50%);
	-moz-transform: translateX(-50%);
	-ms-transform: translateX(-50%);
	-o-transform: translateX(-50%);
	transform: translateX(-50%);
	top: 140px;
} */
.wb-heroHeader.dark::before {
	background-color: rgba(0, 0, 0, 0.5);
}
.wb-heroHeader.light::before {
	background-color: rgba(255, 255, 255, 0.5);
}
.wb-heroHeader.dynamic::before {
	background-color: rgba(217, 27, 91, 0.5);
}
.wb-heroHeader-content h1, .wb-heroHeader-content h2, .wb-heroHeader-content h3, .wb-heroHeader-content h4, .wb-heroHeader-content h5, .wb-heroHeader-content h6 {

}
.wb-heroHeader.dark .wb-heroHeader-content > h1, .wb-heroHeader.dark .wb-heroHeader-content > h2, .wb-heroHeader.dark .wb-heroHeader-content > h3, .wb-heroHeader.dark .wb-heroHeader-content > h4, .wb-heroHeader.dark .wb-heroHeader-content > h5, .wb-heroHeader.dark .wb-heroHeader-content > h6, .wb-heroHeader.dark .wb-heroHeader-content > p {
	color: #fff;
}
.wb-heroHeader.dynamic .wb-heroHeader-content > h1, .wb-heroHeader.dynamic .wb-heroHeader-content > h2, .wb-heroHeader.dynamic .wb-heroHeader-content > h3, .wb-heroHeader.dynamic .wb-heroHeader-content > h4, .wb-heroHeader.dynamic .wb-heroHeader-content > h5, .wb-heroHeader.dynamic .wb-heroHeader-content > h6, .wb-heroHeader.dynamic .wb-heroHeader-content > p {
	color: #fff;
}
.wb-heroHeader.light .wb-heroHeader-content > h1, .wb-heroHeader.light .wb-heroHeader-content > h2, .wb-heroHeader.light .wb-heroHeader-content > h3, .wb-heroHeader.light .wb-heroHeader-content > h4, .wb-heroHeader.light .wb-heroHeader-content > h5, .wb-heroHeader.light .wb-heroHeader-content > h6, .wb-heroHeader.light .wb-heroHeader-content > p {
	color: #000;
}
.wb-heroHeader-content .heroHeader-btn {
	background-color: #fff;
	padding: 15px 40px;
	border-radius: 0;
	font-size: 16px;
	font-weight: 600;
	text-transform: uppercase;
	font-family: 'Montserrat', sans-serif;
	margin-top: 30px;
}
/*** Breadcrumb Section ***/
.breadcrumb-section {
	height: 400px;
	position: relative;
}
.breadcrumb-section:before {
	content: '';
	width: 100%;
	height: 100%;
	position: absolute;
	left: 0;
	top: 0;
}
.breadcrumb-section.dark:before {
    background-color: rgb(0 0 0 / 72%);
}
.breadcrumb-section .title-heading {
	position: absolute;
	top: 50%;
    left: 75%;
	transform: translate(-50%, -50%);
	text-align: center;
}
.breadcrumb-section .title-heading * {
	color: #fff;
}
.breadcrumb-section .title-heading h1, .breadcrumb-section .title-heading p {
	margin-bottom: 0;
}
.breadcrumb-section .title-heading h1 {
	font-size: 43px;
}
/* Mixing CSS */
.page-heading {
	margin-bottom: 80px;
}
/*** Footer CSS ***/
.wb-footer {
	background-color: #5251ec;
	position: relative;
}
.wb-footer:before {
    content: '';
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    background-color: #000;
}
.wb-footer .footer-content ul {
    list-style: none;
    margin: 0;
    padding: 0;
}


.footer-links ul {
    margin: 0;
    padding: 0;
    list-style: none;
}

.footer-links ul li {
    overflow: hidden;
}

.footer-links ul li a {
    color: #fff;
    text-decoration: none;
    font-size: 14px;
    overflow: hidden;
}

.footer-logo a {
    text-decoration: none;
	font-family: 'Montserrat';
    color: #fff;
    text-transform: uppercase;
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 10px;
    display: block;
}



.grid figure h2{
	word-spacing: 7px !important;
}

.wb-footer .footer-content p {
    font-size: 14px;
}

.footer-links ul li span.fa {
    color: #fff;
    margin-right: 10px;
    position: relative;
}

.wb-footer .footer-content {
	padding: 20px 0;
}
.wb-footer .footer-content h5, .wb-footer .footer-content p {
	color: #ffffff;
}
.wb-footer .footer-content p {
	margin-bottom: 0;
}
.footer-gallery {}

.footer-gallery ul li img {
    width: 100%;
    height: 100%;
    border-radius: 5px;
}

.footer-gallery ul {
    list-style: none;
    margin: 0;
    padding: 0;
}

.footer-gallery ul li {
    display: inline-block;
    margin-bottom: 10px;
    border-radius: 5px;
    width: 70px;
    height: 70px;
}
.wb-footer .footer-copyright {
	padding: 5px;
	text-align: center;
	/* border-top: 1px solid #fff; */
}
.wb-footer .footer-copyright p {
	margin: 0;
	font-size: 14px;
	color: #ffffff;
	font-weight: normal;
	    text-align: left;

}
.footer-copyright ul {
	margin-top: 10px;
	text-align: center;
	list-style: none;
	margin-bottom: 0;
}
.footer-copyright ul li {
	display: inline-block;
	box-shadow: 0 0 10px 0 rgba(0,0,0,.1);
}
.footer-copyright ul li a {border: 1px solid white;        position: relative;right: 90px;margin-top: 40px;background-color: #181818;    width: 45px;height: 45px;border-radius: 100px;text-align: center;    line-height: 46px;display: block;    font-size: 18px;}
.footer-copyright ul li a i.fa {
	color: #5251ec;
}

.footer-copyright ul li a span.fa {
    color: #a1003b;
}
/*.wb-footer {
  background-color: #5352ed;
  position: relative;
}
.wb-footer .footer-copyright {
    padding: 10px;
    background-color: #fff;
    color: #fff;
    text-align: center;
}
.wb-footer .footer-copyright p {
    margin: 0;
    font-size: 16px;
    color: #3a393b;
    font-weight: normal;
}
.wb-footer .footer-content {
    padding: 70px 0;
}

.wb-footer .footer-content ul, .icon-list-content ul {
    list-style: none;
    margin: 0;
    padding: 0;
}
.wb-footer .footer-content ul li {

	 color:#fff;
}

.wb-footer .footer-content h6 {
    font-family: 'Montserrat', sans-serif;
    font-weight: 600;
    color: #fff;
}
.wb-footer .footer-content p {
    font-size: 14px;
    color: #fff;
}
.wb-footer .footer-copyright p {
    margin: 0;
    font-size: 16px;
    color: #3a393b;
    font-weight: normal;
}
.wb-footer .footer-content a {
    color: #fff;
    font-size: 14px;
}
.footer-social-links > ul > li {
    display: block;
    float: left;
    margin-right: 15px;
}
.footer-social-links > ul > li > a > i.fa {
    color: #fff;
    font-size: 20px;
}*/

/*** Gallery CSS ***/

.grid {
	max-width: 100%;
	list-style: none;
	width: 100%;
}
.grid figure {
	width: 100%;
	max-height: 300px;
	margin: 5px 0;
	background: none;
}
.grid figure img {
	width: 100%;
}
.grid figure figcaption {
	text-transform: capitalize;
}
figure.effect-marley h2, figure.effect-marley p {
	color: #fff;
}
figure.effect-marley {
	background: #000;
}
ul.fullwidthGallery.imgs-gallery {
	width: 100%;
}
ul.fullwidthGallery.imgs-gallery li {
	width: 33.33%;
	margin-right: 0;
}
.fullwidthGallery figure.effect-marley {
	margin: 0;
}
.borderGallery figure.effect-marley {
	background: #000000;
	border: 1px solid #fff;
}
.borderGallery figure.effect-marley figcaption::before {
	border-top: 1px solid #fff;
	border-bottom: 1px solid #fff;
}

.text-center{
	text-align: center !important;
}

@media only screen and (min-width: 768px) and (max-width: 1024px) {
ul.fullwidthGallery.imgs-gallery li {
	width: 49.3%;
	margin-right: 5px;
}
ul.imgs-gallery li {
	width: 480px;
}
}

@media only screen and (min-width: 480px) and (max-width: 767px) {
ul.imgs-gallery {
	width: 100%;
	float: left;
}
ul.imgs-gallery li {
	margin-right: 0px;
	width: 100%;
}
ul.fullwidthGallery.imgs-gallery li {
	width: 100%;
	margin-right: 0;
}
ul.fullwidthGallery.imgs-gallery li figure.effect-layla img, figure.effect-layla h2 {
	-webkit-transform: translate3d(0, 0px, 0);
}
}

@media only screen and (max-width: 479px) {
ul.imgs-gallery {
	width: 100%;
	float: left;
}
ul.imgs-gallery li {
	margin-right: 0px;
	width: 100%;
}
ul.fullwidthGallery.imgs-gallery li {
	width: 100%;
	margin-right: 0;
}
}

/*** Responsive CSS ***/
@media (max-width: 1200px) {
}

@media (max-width: 1024px) {
}

@media (max-width: 991px) {
}

@media (min-width: 768px) and (max-width: 1023px) {
.wb-heroHeader {
	height: auto;
}
.wb-heroHeader-content:before {
	width: 360px;
	border: 10px solid #5352ed;
	border-bottom: 0;
	height: 100px;
	top: -80px;
}
.wb-heroHeader-content:after {
	width: 360px;
	border: 10px solid #5352ed;
	border-top: 0;
	height: 100px;
	top: 110px;
}
.wb-heroHeader-content h1 {
	font-size: 40px;
}
.wb-heroHeader-content h6 {
	font-size: 18px;
}
/*.wb-footer .footer-social-bnr h3 {font-size: 20px;text-align: left;margin: 7px 0;}
.wb-footer .footer-social-bnr {text-align: center;}
.wb-footer .footer-social-bnr ul {float: none;display: inline-block;}
.wb-footer .footer-content table {width: 90%;}
.wb-footer .footer-content table>tbody>tr>td, .wb-footer .footer-content a, .wb-footer .icon-list-content > ul > li, .wb-footer .footer-copyright p {font-size: 13px;}
.wb-footer .icon-list-content > ul > li > i.fa {font-size: 14px;left: -5px;top: 0px;}
.wb-footer .icon-list-content > ul > li {padding-left: 15px;line-height: normal;} */
}

@media (max-width: 640px) {
.wb-header {
	position: static;
}
.wb-heroHeader {
	height: 400px;
}
.wb-heroHeader-wrapper {
	width: 100%;
	top: 96px;
}
.wb-heroHeader-content:before {
	width: 230px;
	height: 50px;
	border: 5px solid #5352ed;
	top: -50px;
	border-bottom: 0;
}
.wb-heroHeader-content:after {
	width: 230px;
	height: 50px;
	border: 5px solid #5352ed;
	top: 65px;
	border-top: 0;
}
.wb-heroHeader-content h6 {
	font-size: 12px;
}
.wb-page h2 {
	font-size: 25px;
}
.page-heading {
	margin-bottom: 50px;
}

.footer-social-bnr {
	text-align: center;
}
.footer-social-bnr ul {
	margin: 0;
	text-align: center;
}
/* .wb-footer .footer-social-bnr {text-align: center;}
.wb-footer .footer-social-bnr h3 {font-size: 18px;text-align: center;}
.wb-footer .footer-social-bnr ul {display: inline-block;float: none;} */
.wb-footer .footer-content {
	text-align: center;
}
.wb-footer .footer-content h6, .wb-footer .footer-content p {
	text-align: center;
}
/* .wb-footer .footer-content table {width: 80%;margin:0 auto 20px auto;} */
/*.wb-footer .footer-content .footer-social-links {text-align: center;}
.wb-footer .footer-content ul {margin-bottom: 30px;text-align: center;display: inline-block;}
.wb-footer .icon-list-content ul {padding: 30px 0 0 0;margin-bottom: 0;}
.wb-footer .icon-list-content > ul > li {margin: 0 0 15px 0;line-height: normal;padding: 15px 0;}
.wb-footer .icon-list-content > ul > li > i.fa {left: 50%;top: -18px;font-size: 20px;}*/
}

