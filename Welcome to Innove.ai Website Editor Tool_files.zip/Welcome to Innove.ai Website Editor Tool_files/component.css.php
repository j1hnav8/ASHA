@import url('https://fonts.googleapis.com/css?family=Open+Sans:300,400,700|Raleway:400,500|Roboto:400,700');
.dm-animated-btn {
	color: #fff;
	display: inline-block;
	font-size: 14px;
	text-decoration: none;
	cursor: pointer;
	line-height: normal;
	padding: 10px 40px;
 	background: #000;
	transition: all 0.5s ease;
}
header.fixedHeader .header-image-text {
    display:none
}

.header-image-text {
    max-width:760px;
    width:100%;
    position: relative;
    left: auto;
    right: auto;
    top:auto;
    bottom: auto;
    margin: 0px auto;
}

.header-image-text .carousel-caption {
    position: inherit !important;
    top: auto;
    left: auto;
    bottom: auto;
    right: auto;
}
/*** headerImage Style CSS Start ***/
.header-image-text.headerStyle1 {
    border: 3px double rgba(255,255,255,0.3);
    top: 10%;
    max-width: 600px;
}

.header-image-text.headerStyle2 {position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);bottom: auto;text-align: center;}

.header-image-text.headerStyle2 * {
    color: #fff;
}

.header-image-text.headerStyle2 h4 {
    font-size: 20px;
    font-weight: 100;
    color: #fff;
    line-height: 1.5;
    margin-top: 0;
    margin-bottom: 10px;
}

.header-image-text.headerStyle2 h1 {
    font-size: 60px;
    line-height: 1.1;
    color: #fff;
    margin-top: 0;
    margin-bottom: 10px;
}

.header-image-text.headerStyle2  ul {
    list-style: none;
    padding: 0;
    margin: 0 auto;
    text-align: center;
    display: inline-block;
}

.header-image-text.headerStyle2 ul li {
    display: block;
    float: left;
    position: relative;
    margin-right: 30px;
    font-size: 20px;
    color: #ffffff;
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
}

.header-image-text.headerStyle2 ul li:after {
    content: '';
    width: 10px;
    height: 10px;
    background-color: #000;
    border-radius: 100px;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    margin-left: 10px;
}

.header-image-text.headerStyle2 .theme-button {
    margin-right: 15px;
}
/*=======FORM-1======*/
.dragndropContactForm label, legend {
	display: block;
	font-size: 14px;
 	color: #000;
	margin-bottom: 10px;
	font-weight: normal;
}
.dragndropContactForm input[type="text"], .dragndropContactForm input[type="password"], .dragndropContactForm input[type="email"], .dragndropContactForm textarea, .dragndropContactForm select {
	color: #000;
}
.dragndropContactForm input[type="text"]:focus, .dragndropContactForm input[type="password"]:focus, .dragndropContactForm input[type="email"]:focus, .dragndropContactForm textarea:focus {
	background: #fff;
	color: #000;
 	border: 1px solid #000;
}
.dragndropRichTextWidget {
	margin: 0;
	padding: 0;
}
.dragndropRichTextWidget h1, .dragndropRichTextWidget h2, .dragndropRichTextWidget h3, .dragndropRichTextWidget h4, .dragndropRichTextWidget h5, .dragndropRichTextWidget h6 {
 	color: #000;
}
.dragndropRichTextWidget .fa {
 	color: #000;
}
.dragndropSocialMedia ul {
	margin: 0;
	padding: 0;
	display: block;
	width: 100%;
	float: left;
	text-align: center;
}
.dragndropSocialMedia ul li {
	list-style: none;
	display: inline-block;
	float: none;
	margin-right: 10px;
	margin-bottom: 10px;
	font-size: 35px;
}
.dragndropSocialMedia ul li a {
	text-decoration: none;
 	color: #000;
}
.dragndropSocialMedia.social-media {
	background: none !important;
}
.dragndropSocialMedia.social-media li {
	background: none !important;
}
.dragndropSocialMedia ul li span {
	 color: #000;
}
.img-responsive {
	width: 100%;
}
.imageWidget .img-circle {
	width: 250px;
	height: 250px;
	margin: 0 auto;
}
.dragndropImgGallery .grid figure {
	background: rgba(0, 0, 0, 0.9) !important;
}
.embed-container {
	position: relative;/*padding-bottom: 19.25%;*/
	padding-top: 30px;
	height: auto;
	overflow: hidden;
}
.embed-container iframe {
	/*position: absolute;*/
	top: 0;
	left: 0;
	width: 100%;/*height: 100%;*/
}
.fixedClass {
	position: fixed;
	z-index: 999;
	transition: all 0.2s ease-in-out;
}
.top-0 {
	top: 0px;
}
header.static-header {
	position: static;
}
header.fixedHeader {
	transition: all 0.4s ease;
	z-index: 1001;
	position: fixed;
	width: 100%;
	box-shadow: 0px 0px 2px 2px rgba(0,0,0,0.2);
    height: inherit!important;
    background: #fff!important;
}
/******** =========================  Tempalte  SingleSlider CSS Start ==================== ********/

section.slider .heroImage::before {
	position: absolute;
	top: 0;
	left: 0;
	z-index: 0;
	display: block;
	width: 100%;
	min-height: 100%;
	height: inherit;
	background: rgba(0,0,0,0.2);
	content: '';
}
section.slider, section.themeSlider {
	position: relative;
	padding: 0px;
}
header{padding:10px 0;}
header .logo{padding:0;}
section.heroSlider img {
	float: none;
}
section.heroSlider .heroHeading h1 {
	line-height: 1.2;
}
section.heroSlider .heroHeading h2 {
	line-height: 1.2;
}
section.heroSlider .heroHeading h3 {
	line-height: 1.2;
}
section.heroSlider .heroHeading h4 {
	line-height: 1.2;
}
section.heroSlider .heroHeading h5 {
	line-height: 1.4;
}
section.heroSlider .heroHeading h6 {
	line-height: 1.5;
}
section.heroSlider .heroHeading h1, section.heroSlider .heroHeading h2, section.heroSlider .heroHeading h3, section.heroSlider .heroHeading h4, section.heroSlider .heroHeading h5, section.heroSlider .heroHeading h6, section.heroSlider .heroHeading p {
	margin: 10px 0;
	padding: 0;
	display: block;
	/*text-align: left;*/
	/*font-weight: bold;*/
	/*color: #fff;*/
	
}
section.heroSlider .heroHeading p {
	line-height: 1.5;
	font-weight: normal;
	/*color: #fff;*/
	/*font-size: 20px;*/
    /*text-align:left;*/
}
/*section.slider .heroHeading {
	position: absolute;
    top: 50%;
    -webkit-transform:translate(-50%, -50%);
	transform: translate(-50%, -50%);
	left: 50%;
    right:auto;
    height:auto;
    margin-top:0;
    padding: 0px 30px;
	width: 80%;
    margin: auto;
    
}
*/ 
    
/*.heroHeading.fadeInLeft {
    -webkit-animation-name: none;
    animation-name: none;
}*/
/*.heroHeading.animated {
    -webkit-animation-duration: !important;
    animation-duration: !important;
    -webkit-animation-fill-mode: !important;
    animation-fill-mode: none !important;
    animation-name: none !important;
}*/
/*section.slider .heroHeading .theme-button, section.slider .heroHeading .theme-button-second {padding: 12px 40px;font-size:16px;margin-top:5px;}*/

/******** =========================  Tempalte  SingleSlider CSS End ==================== ********/
/* ----------------------- widget-section ----------------------- */
.widget-section[class*=".widget-section-"] p,
.widget-section[class*=".widget-section-"] span,
.widget-section[class*=".widget-section-"] em,
.widget-section[class*=".widget-section-"] strong,
.widget-section[class*=".widget-section-"] i {
    margin: 0;
    padding: 0;
}
.widget-section-13-1 .item
/*@import url('https://fonts.googleapis.com/css?family=Raleway:400,500');*/

.page section {
    position: relative;
    overflow: visible !important;
}
.widget-section[class*=".widget-section-"] {font: 400 14px/1.5em 'Raleway', "Helvetica Neue", Helvetica, Arial, sans-serif;color: #666666;}
.widget-section {
    width: 100%;
    /*font: 400 14px/1.5em 'Raleway', "Helvetica Neue", Helvetica, Arial, sans-serif;
    color: #666666;*/
    padding: 70px 0;
    position: relative;
    background-color: #fff;
}
.widget-section[class*=".widget-section-"] p { font-size: 14px;  font-style: normal; }

/* Heading */
.widget-section[class*="widget-section-"] h1,
.widget-section[class*="widget-section-"] h2,
.widget-section[class*="widget-section-"] h3,
.widget-section[class*="widget-section-"] h4,
.widget-section[class*="widget-section-"] h5,
.widget-section[class*="widget-section-"] h6 {
  font-family: 'Raleway', sans-serif;
  line-height: 1em;
  font-weight: 500;
  font-style: normal;
  color: #333333;
  margin:0;
  padding:0;}

.widget-section[class*="widget-section-"] h1 { font-size: 46px; }
.widget-section[class*="widget-section-"] h2 { font-size: 40px;  margin-bottom: 15px;}
.widget-section[class*="widget-section-"] h3 { font-size: 36px; }
.widget-section[class*="widget-section-"] h4 { font-size: 30px; margin-bottom: 15px;}
.widget-section[class*="widget-section-"] h5 { font-size: 24px; margin-bottom: 10px;}
.widget-section[class*="widget-section-"] h6 { font-size: 18px; margin-bottom: 10px; }

.widget-section[class*="widget-section-"] .col-lg-12 .section-title { margin-bottom: 50px; }
.widget-section[class*="widget-section-"] .section-title { margin-bottom: 20px; }

/* Paragraph */
.widget-section[class*="widget-section-"] .section-title p {
    font-size: 18px;
    color: #444444;
    font-weight: 500;
}

/* Image */
.widget-section[class*="widget-section-"] .item .widget-img { margin-bottom: 25px; }
.widget-section[class*="widget-section-"] .item .widget-img:last-child { margin-bottom: 0; }

/* Icon */
.widget-section .icon {
    margin-bottom: 20px;
    text-align: center;
    /*    font-size: 48px;*/
    background-color: #ccc;
    display: inline-block;
    color: #fff;
}
.widget-section .icon i,.widget-section .icon em {
    display: block;
    position: relative;
    top: 50%;
    -webkit-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
}


/* ----------------------- bg-img/pattren/color widget-section ----------------------- */
/*background-img*/
.widget-section[class*="bg-img-"] {
    background-repeat: no-repeat;
    background-size: cover;
}
.bg-img-1  { background-image: url('//static.sitemantic.com/webbuilder/images/bg/img-1.jpg') ; }
.bg-img-2  { background-image: url('//static.sitemantic.com/webbuilder/images/bg/img-2.jpg') ; }
.bg-img-3  { background-image: url('//static.sitemantic.com/webbuilder/images/bg/img-3.jpg') ; }

/* pattren*/
.theme-pattren-1 { background-image: url('//static.sitemantic.com/webbuilder/images/pattern/light/pattern-1.png'); }
.theme-pattren-2 { background-image: url('//static.sitemantic.com/webbuilder/images/pattern/light/pattern-2.png'); }
.theme-pattren-3 { background-image: ;}
.theme-pattren-4 { background-image: ;}
.theme-pattren-5 { background-image: ;}

/*light color*/
.theme-light-color-1 { background-color: #f7faff;}
.theme-light-color-2 { background-color: #fef8e1;}
.theme-light-color-3 { background-color: #e5f5ff;}
.theme-light-color-4 { background-color: #fff2f2;}
.theme-light-color-5 { background-color: #f9ebff;}
.theme-light-color-6 { background-color: #fbffdc;}
.theme-light-color-7 { background-color: #f4ffe2;}
.theme-light-color-8 { background-color: #f5f5f5;}
.theme-light-color-9 { background-color: #fafafa;}

.widget-section [class*="theme-light-color"] label,
.widget-section [class*="theme-light-color"] span,
.widget-section [class*="theme-light-color"] strong,
.widget-section [class*="theme-light-color"] a,
.widget-section [class*="theme-light-color"] p,
.widget-section [class*="theme-light-color"],
.widget-section [class*="theme-light-color"] h1,
.widget-section [class*="theme-light-color"] h2,
.widget-section [class*="theme-light-color"] h3,
.widget-section [class*="theme-light-color"] h4,
.widget-section [class*="theme-light-color"] h5,
.widget-section [class*="theme-light-color"] h6,
.widget-section[class*="theme-light-color"] label,
.widget-section[class*="theme-light-color"] span,
.widget-section[class*="theme-light-color"] strong,
.widget-section[class*="theme-light-color"] a,
.widget-section[class*="theme-light-color"] p,
.widget-section[class*="theme-light-color"],
.widget-section[class*="theme-light-color"] h1,
.widget-section[class*="theme-light-color"] h2,
.widget-section[class*="theme-light-color"] h3,
.widget-section[class*="theme-light-color"] h4,
.widget-section[class*="theme-light-color"] h5,
.widget-section[class*="theme-light-color"] h6,
.widget-section[class*="theme-light-color"] .section-title p{
  color: #666;
}

/*dark color*/
.theme-dark-color-1 { background-color: #3498db;}
.theme-dark-color-2 { background-color: #d95459;}
.theme-dark-color-3 { background-color: #1abc9c; }
.theme-dark-color-4 { background-color: #554072; }
.theme-dark-color-5 { background-color: #363558; }
.theme-dark-color-6 { background-color: #f9ab03; }
.theme-dark-color-7 { background-color: #f2c500; }
.theme-dark-color-8 { background-color: #33495f; }
.theme-dark-color-9 { background-color: #7f4537; }
.theme-dark-color-10 { background-color: #cc66a5; }
.theme-dark-color-11 { background-color: #1b1e25; }

.widget-section [class*="theme-dark-color"] label,
.widget-section [class*="theme-dark-color"] span,
.widget-section [class*="theme-dark-color"] strong,
.widget-section [class*="theme-dark-color"] a,
.widget-section [class*="theme-dark-color"] p,
.widget-section [class*="theme-dark-color"],
.widget-section [class*="theme-dark-color"] h1,
.widget-section [class*="theme-dark-color"] h2,
.widget-section [class*="theme-dark-color"] h3,
.widget-section [class*="theme-dark-color"] h4,
.widget-section [class*="theme-dark-color"] h5,
.widget-section [class*="theme-dark-color"] h6,
.widget-section[class*="theme-dark-color"] label,
.widget-section[class*="theme-dark-color"] span,
.widget-section[class*="theme-dark-color"] strong,
.widget-section[class*="theme-dark-color"] a,
.widget-section[class*="theme-dark-color"] p,
.widget-section[class*="theme-dark-color"],
.widget-section[class*="theme-dark-color"] h1,
.widget-section[class*="theme-dark-color"] h2,
.widget-section[class*="theme-dark-color"] h3,
.widget-section[class*="theme-dark-color"] h4,
.widget-section[class*="theme-dark-color"] h5,
.widget-section[class*="theme-dark-color"] h6,
.widget-section[class*="theme-dark-color"] .section-title p{
  color: #fff;
}

.widget-section .dark-text-color ,
.widget-section .dark-text-color label,
.widget-section .dark-text-color p {color: #666666;}
.widget-section  .dark-text-color h1,
.widget-section  .dark-text-color h2,
.widget-section  .dark-text-color h3,
.widget-section  .dark-text-color h4,
.widget-section  .dark-text-color h5,
.widget-section .dark-text-color h6 { color: #333333 ;}

.widget-section .light-text-color,
.widget-section .light-text-color p,
.widget-section  .light-text-color h1,
.widget-section  .light-text-color h2,
.widget-section  .light-text-color h3,
.widget-section  .light-text-color h4,
.widget-section  .light-text-color h5,
.widget-section .light-text-color h6 { color: #fff ;}

/*------------------------------------------------------------------------------
SHAPES START  (square, circle, hexagon)
--------------------------------------------------------------------------------*/
/* SQUARE */
.icon-square .icon {
  width: 90px;
  height: 90px;
}

/* CIRCLE */
.icon-circle .icon{
  text-align: center;
  width: 90px;
  height: 90px;
  border-radius: 50%;
}

/* HEXAGON */
.icon-hexagon .icon {
	width: 100px;
	height: 55px;
	background: #ccc;
	position: relative;
  margin-bottom: 45px;
}
.icon-hexagon .icon-before {
	content: "";
	position: absolute;
	top: -25px;
	left: 0;
	width: 0;
	height: 0;
	border-left: 50px solid transparent;
	border-right: 50px solid transparent;
	border-bottom: 25px solid #ccc;
}
.icon-hexagon .icon-after {
	content: "";
	position: absolute;
	bottom: -25px;
	left: 0;
	width: 0;
	height: 0;
	border-left: 50px solid transparent;
	border-right: 50px solid transparent;
	border-top: 25px solid #ccc;
}

/*-------------------------------------------------------------------------
SHAPES END
-------------------------------------------------------------------------*/

/* ----------------------- widget-section-01 ----------------------- */
.widget-section-01-1,
.widget-section-01-1 h2,
.widget-section-01-1 h6,
 .widget-section-01-1 p { text-align: center; }

/*.widget-section-01-1 div[class*="col-"]:nth-of-type(2) .icon { background-color: #34bedb; }*/
/*.widget-section-01-1 div[class*="col-"]:nth-of-type(2) .icon:before { border-bottom-color: #34bedb; }*/
/*.widget-section-01-1 div[class*="col-"]:nth-of-type(2) .icon:after { border-top-color: #34bedb; }*/
/*.widget-section-01-1 div[class*="col-"]:nth-of-type(3) .icon { background-color: #f9a356; }*/
/*.widget-section-01-1 div[class*="col-"]:nth-of-type(3) .icon:before { border-bottom-color: #f9a356; }*/
/*.widget-section-01-1 div[class*="col-"]:nth-of-type(3) .icon:after { border-top-color: #f9a356; }*/
/*.widget-section-01-1 div[class*="col-"]:nth-of-type(4) .icon { background-color: #59b495; }*/
/*.widget-section-01-1 div[class*="col-"]:nth-of-type(4) .icon:before { border-bottom-color: #59b495; }*/
/*.widget-section-01-1 div[class*="col-"]:nth-of-type(4) .icon:after { border-top-color: #59b495; }*/
/*.widget-section-01-1 div[class*="col-"]:nth-of-type(5) .icon { background-color: #d8626e; }*/
/*.widget-section-01-1 div[class*="col-"]:nth-of-type(5) .icon:before { border-bottom-color: #d8626e; }*/
/*.widget-section-01-1 div[class*="col-"]:nth-of-type(5) .icon:after { border-top-color: #d8626e; }*/


/* ------ widget-section-01-1 ------ */
.widget-section-01-2 ,
.widget-section-01-2 h2,
.widget-section-01-2 h6,
.widget-section-01-2 p  {
  text-align: center;
}


/*.widget-section-01-2 .col-xs-push-1 div[class*="col-"]:nth-of-type(1) .icon { background-color: #3a3a42; }
.widget-section-01-2 .col-xs-push-1 div[class*="col-"]:nth-of-type(1) .icon:before { border-bottom-color: #3a3a42; }
.widget-section-01-2 .col-xs-push-1 div[class*="col-"]:nth-of-type(1) .icon:after { border-top-color: #3a3a42; }
.widget-section-01-2 .col-xs-push-1 div[class*="col-"]:nth-of-type(2) .icon { background-color: #173652; }
.widget-section-01-2 .col-xs-push-1 div[class*="col-"]:nth-of-type(2) .icon:before { border-bottom-color: #173652; }
.widget-section-01-2 .col-xs-push-1 div[class*="col-"]:nth-of-type(2) .icon:after { border-top-color: #173652; }
.widget-section-01-2 .col-xs-push-1 div[class*="col-"]:nth-of-type(3) .icon { background-color: #465967; }
.widget-section-01-2 .col-xs-push-1 div[class*="col-"]:nth-of-type(3) .icon:before { border-bottom-color: #465967; }
.widget-section-01-2 .col-xs-push-1 div[class*="col-"]:nth-of-type(3) .icon:after { border-top-color: #465967; }*/



/* ------ widget-section-01-3 ------ */

.widget-section-01-3,
.widget-section-01-3 h6,
.widget-section-01-3 p {
  text-align: center;
}
.widget-section-01-3 .icon {
  width: 60px;
  height: 60px;
/*  font-size: 36px;*/
  color: #444;
/*  background-color: #fff;*/
}
/* ------ widget-section-01-4 ------ */
.widget-section-01-4 ,
.widget-section-01-4 h6,
.widget-section-01-4 p {
  text-align: center;
}
.widget-section-01-4 .icon {
  background-color: transparent;
  color: #444;
}
.widget-section-01-4 .icon i {
      transform: initial;
}
/* ----------------------- widget-section-02 ----------------------- */
.widget-section-02-1,
.widget-section-02-1 h2,
.widget-section-02-1 h5,
.widget-section-02-1 p {
  text-align: center;
}
.widget-section-02-1 .widget-img {
    border-radius: 50%;
    width: 245px;
    height: 245px;
    overflow: hidden;
    display: inline-block;
    vertical-align: middle;
}
.widget-section-02-1 .item {
    display: inline-block;
    /*max-width: 300px;
    width: 100%;*/
}
@media only screen and (min-width: 992px) and (max-width: 1199px) {
    .widget-section-02-1 div[class*="col-"]:nth-of-type(2) .item{ margin-bottom: 30px; }
    .widget-section-02-1 div[class*="col-"]:nth-of-type(3) .item{ margin-bottom: 30px; }

}
@media only screen and (max-width:380px) {
    .widget-section-02-1 .widget-img {
        width: 225px;
        height: 225px
    }
}
/* ----------------------- widget-section-03 ----------------------- */
.widget-section-03-1,
.widget-section-03-1 p {
  text-align: justify;
}
.widget-section-03-1 h4,
.widget-section-03-1 h5,
.widget-section-03-1 h6 {
  text-align: left;
}

/* ----------------------- widget-section-04 ----------------------- */
.widget-section-04-1,
.widget-section-04-1 h2,
.widget-section-04-1 h5,
.widget-section-04-1 p {
  text-align: left;
}
.widget-section-04-1 .widget-img {

}
.img-max-width-1 .widget-img { max-width: 265px; width: 100%; }
.img-max-width-2 .widget-img { max-width: 360px; width: 100%; }
.img-max-width-3 .widget-img { max-width: 570px; width: 100%; }
.img-max-width-4 .widget-img { max-width: 555px; width: 100%; }
.img-max-width-5 .widget-img { max-width: 800px; width: 100%; }


/* ----------------------- widget-section-05 ----------------------- */
.widget-section-05-1,
.widget-section-05-1 h2,
.widget-section-05-1 p {
  text-align: left;
}
/* ----------------------- widget-section-05 ----------------------- */
.widget-section-06-1,
.widget-section-06-1 h2,
.widget-section-06-1 p {
  text-align: left;
}

/* ----------------------- widget-section-07 ----------------------- */
.widget-section-07-1,
.widget-section-07-1 h2,
.widget-section-07-1 p {
  text-align: center;
}
.widget-section-07-1 .col-lg-12 .section-title {
    margin-bottom: 25px;
}
.widget-section-07-1 .widget-img {
    display:inline-block;
    vertical-align: middle;
}


/* ----------------------- half-col-input  ----------------------- */
@media only screen and (min-width:992px) {
  .widget-section .half-col-btn .dm-contact-btn,
  .widget-section .half-col-textarea .dm-contact-textarea,
.widget-section .half-col-input .dm-contact-input {
  max-width: 50%;
  width: 100%;
  float: left;
}

.widget-section .half-col-input .dm-contact-input:nth-child(3) { padding-left: 20px;}

}
/* -------------------------------------------------------------
  Form
----------------------------------------------------------------*/
.widget-section .block-form label {
  text-transform: uppercase;
  font-size: 13px;
  font-weight: 400;
  letter-spacing: 1px;
  margin-bottom: 0px;
  color: #333;
  text-align: left;
}
/* ----------------------- default form  ----------------------- */
.widget-section .default-form input[type="text"],
.widget-section .default-form input[type="email"],
.widget-section .default-form textarea {
  color: #666;
  width: 100%;
  font-size: 14px;
  font-family: FontAwesome , 'Raleway', "Helvetica Neue", Helvetica, Arial, sans-serif;
  padding: 10px 15px ;
  margin-bottom: 20px;
  border: 1px solid #8c8c8c;
}
.widget-section .default-form textarea {
  min-height: 100px;
}
.widget-section .default-form .captchaCode {
  margin-bottom: 20px;
}

.widget-section .default-form ::-webkit-input-placeholder { /* Chrome */ color: #a9a9a9; }
.widget-section .default-form :-ms-input-placeholder { /* IE 10+ */ color: #a9a9a9; }
.widget-section .default-form ::-moz-placeholder { /* Firefox 19+ */ color: #a9a9a9; opacity: 1; }
.widget-section .default-form :-moz-placeholder { /* Firefox 4 - 18 */ color: #a9a9a9; opacity: 1; }

/* -----------------------  Border-form  ----------------------- */

.widget-section .border-form  input[type="text"],
.widget-section .border-form  input[type="email"],
.widget-section .border-form textarea {
  background-color: transparent;
  border-color: #fff;
  color: #fff;
}

.widget-section .border-form ::-webkit-input-placeholder { /* Chrome */ color: #fff; }
.widget-section .border-form :-ms-input-placeholder { /* IE 10+ */ color: #fff; }
.widget-section .border-form ::-moz-placeholder { /* Firefox 19+ */ color: #fff; opacity: 1; }
.widget-section .border-form :-moz-placeholder { /* Firefox 4 - 18 */ color: #fff; opacity: 1; }

/* -----------------------  bg-form  ----------------------- */
.widget-section .bg-form  input[type="text"],
.widget-section .bg-form  input[type="email"],
.widget-section .bg-form textarea {
  background-color: #f2f2f2;
  border: 0;
}

/* -----------------------  border-2-form  ----------------------- */
.widget-section .border-2-form  input[type="text"],
.widget-section .border-2-form  input[type="email"]{
  background-color: transparent;
  border: 0;
  border-bottom: 1px solid #fff;
  color: #fff;
}

.widget-section .border-2-form textarea {
  background-color: transparent;
    border: 1px solid #fff;
      color: #fff;
}

/* -----------------------  transparent-form  ----------------------- */
.widget-section .transparent-form  input[type="text"],
.widget-section .transparent-form input[type="email"],
.widget-section .transparent-form textarea {
  border: 0;
  background-color: rgba(255, 255, 255, 0.5);
}
.widget-section .transparent-form ::-webkit-input-placeholder { /* Chrome */ color: #fff; }
.widget-section .transparent-form :-ms-input-placeholder { /* IE 10+ */ color: #fff; }
.widget-section .transparent-form ::-moz-placeholder { /* Firefox 19+ */ color: #fff; opacity: 1; }
.widget-section .transparent-form :-moz-placeholder { /* Firefox 4 - 18 */ color: #fff; opacity: 1; }
/*------------------------ widget-section-08-1 ------------------------ */
.widget-section-08-1,
.widget-section-08-1 h2,
.widget-section-08-1 h6,
.widget-section-08-1 p {
  text-align: left;
}
.widget-section-08-1 .block-container {
  background-color: rgba(255, 255, 255, 0.9);
  padding: 40px;
}
.widget-section-08-1 .section-title span {
  color: #f2c500;
}
.widget-section-08-1 .block-form {
  box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.50);
  background-color: #fff;
  padding: 40px;
}

.widget-section-08-1 .block-form .block-title {
  margin-bottom: 35px;
}

.widget-section-08-1 .widget-content {
  margin-bottom: 20px;
}
.widget-section-08-1 .block-contact-info {
  margin-bottom: 20px;
  list-style: none;
}
.widget-section-08-1 .block-contact-info p {
  margin-bottom: 10px;
}
.widget-section-08-1 .block-contact-info li {
  margin-bottom: 10px;
}
.widget-section-08-1 .block-social {
  font-size: 20px;
}
.widget-section-08-1 .block-social li {
  list-style: none;
  display: inline-block;
  margin-right: 10px;
 }

.widget-section-08-1 .block-social a {
  color: #666;
}

@media only screen and (max-width: 600px) {
.widget-section-08-1  .col-md-6:last-child .item {
  margin-left: -30px;
  margin-right: -30px;
}
.widget-section-08-1 .block-container {
  padding: 30px;
}
.widget-section-08-1 .block-form {
    padding: 30px 20px;
}
}

/*------------------------- widget-section-09-1 ------------------------------*/
.widget-section-09-1,
.widget-section-09-1 h2,
.widget-section-09-1 h6,
.widget-section-09-1 p {
  text-align: left;
}
.widget-section-09-1:after {
  content: '';
  position: absolute;
  width: 100%;
  height: 50%;
  background-color: #fff;
  bottom: 0;
  left: 0;

}
.widget-section-09-1 .section-title {
  margin-bottom: 50px;
}
.widget-section-09-1 .block-container {
  background-color: #fff;
  box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.50);
  z-index: 2;
  position: relative;
  overflow: hidden;
}
.widget-section-09-1 .block-container .col-md-6:first-child .item {
  padding:50px 40px 50px 40px;
}

.widget-section-09-1 .block-container .col-md-6:last-child .item {
  background-color: #2d3e50;
  padding:50px 40px;
  position: relative;
}
.widget-section-09-1 .block-container .col-md-6:last-child .item:after {
  content: '';
  width: 100%;
  height: 1000px;
  position: absolute;
  left: 0;
  top: 100%;
  background-color: #2d3e50;
}
.widget-section-09-1 .block-title {
  margin-bottom: 35px;
}

.widget-section-09-1 .block-contact-info  {
    list-style: none;
      margin-bottom: 20px;
}

.widget-section-09-1 .block-contact-info p  {
    margin-bottom: 10px;
}
.widget-section-09-1 .block-social li{
  list-style: none;
  display: inline-block;
  margin-right: 10px;
}

.widget-section-09-1 .block-social a {
  color: #fff;
  font-size: 20px;
}
@media only screen and (min-width: 992px) {
  .widget-section-09-1 .block-container .col-md-6:last-child .item {
      min-height: 432px;
    }
}
@media only screen and (max-width: 991px) {
  .widget-section-09-1 .block-container .col-md-6:last-child .item {
    margin-bottom: 0;
  }
}
/*--------------------------------------------------------------------*/
.widget-section-10-1,
.widget-section-10-1 h3,
.widget-section-10-1 p {
  text-align: left;
}
.widget-section-10-1 {
  padding-top: 0;
  padding-bottom: 0;
}
.widget-section-10-1 .section-title {
  margin-bottom: 50px;
}
.widget-section-10-1 iframe {
  width: 100%;
}

.widget-section-10-1 .col-half{
  background-color: rgba(85, 64, 114, 0.96);
  position: absolute;
  top: 0;
  left: 0;
  width: 50%;
  height: 100%;
  padding:50px 0 50px 100px;
}

.widget-section-10-1 .col-half:after,
.widget-section-10-1 .col-half:before{
    display: table;
    content: " "
  }
  .widget-section-10-1 .col-half:after {
    clear: both;
  }
.widget-section-10-1 .block-contact-info {
  margin-bottom: 20px;
  list-style: none;
}
.widget-section-10-1 .block-contact-info li {
  margin-bottom: 10px;
}
.widget-section-10-1 .block-contact-info p {
  margin-bottom: 20px;
}
.widget-section-10-1 .block-contact-info .fa {
  width: 32px;
  height: 32px;
  background-color: #f68e1f;
  border-radius: 50%;
  text-align: center;
  padding-top: 8px;
  margin-right: 20px;
  color: #fff;
  font-size:16px
}

.widget-section-10-1 .block-social span {
  margin-right: 10px;
}
.widget-section-10-1 .block-social a {
  color: #fff;
  font-size: 20px;
}

@media only screen and (max-width: 991px) {
.widget-section-10-1 .col-half{
    position: static;
    width: 100%;
    padding:50px;
}
}

@media only screen and (min-width: 992px) {
.widget-section-10-1 .center-container {
    max-width: 570px;
    width: 100%;
    float: right;
}
}
@media only screen and (max-width: 600px) {
  .widget-section-10-1 .col-half {
    padding-left: 30px;
    padding-right: 30px;
  }
}

/*-------------------------------- widget-section-11-1 ------------------------------------*/
.widget-section-11-1 p,
.widget-section-11-1 h6 {
  text-align: center;
}
.widget-section-11-1 h6 .block-form {
  text-align: left;
}
.widget-section-11-1 {
  padding-top: 0;
}
.widget-section-11-1 iframe {
  height: 365px;
  width: 100%;

}

.widget-section-11-1 .block-container {
  box-shadow: 0px 0px 15px 0px rgba(0,0,0,0.50);
  background-color: #fff;
}
.widget-section-11-1 .block-title {
  margin-bottom: 30px;
}
.widget-section-11-1 .item {
    padding: 50px 100px 50px 100px;
}
.widget-section-11-1 .block-social {
    text-align: center;
}
.widget-section-11-1 .block-social li {
  list-style: none;
  display: inline-block;
  margin-right: 10px;
 }
.widget-section-11-1 .block-social a {
  display: inline-block;
  width: 30px;
  height: 30px;
  background-color: #fff;
  border-radius: 50%;
  text-align: center;
  padding-top: 4px;
  font-size: 16px;
}
.widget-section-11-1 .block-social .fa {
  color: #333;
}
  .widget-section-11-1 .block-contact-info p {
  margin-bottom: 19px
  }
@media only screen and (max-width: 600px) {
  .widget-section-11-1 .item {
    padding: 30px;
}
}
@media only screen and (min-width: 768px) {
.widget-section-11-1 .block-container {
  margin-top: -180px;
}
}

@media only screen and (min-width: 992px) {
  .widget-section-11-1 .block-contact-info p {
    width: 50%;
    padding-left: 10px;
    padding-right: 10px;
    float: left;
  }
}

/*-------------------------------- widget-section-12-1 ------------------------------------*/
.widget-section-12-1,
.widget-section-12-1 p,
.widget-section-12-1 h5,
.widget-section-12-1 h6 {
  text-align: left;
}
.widget-section-12-1 .block-container {
  background-color: #fff;
  overflow:hidden;
}
.widget-section-12-1 .block-container .col-md-6:first-child .item {
    padding: 50px 40px;
}
.widget-section-12-1 .widget-content {
  margin-bottom: 20px;
}
.widget-section-12-1 .block-contact-info {
  padding-left: 25px;
}
.widget-section-12-1 .block-contact-info p {
  margin-bottom: 20px;
  position: relative;
}
.widget-section-12-1 .block-contact-info p .fa {
  font-size: 18px;
  position: absolute;
  left:-25px;
  top: 50%;
  transform: translateY(-50%);
}
.widget-section-12-1 .block-social {
  font-size: 18px;
}.widget-section-12-1 .block-social ul {
  padding-left: 0;
}
.widget-section-12-1 .block-social li {
  list-style: none;
  display: inline-block;
  margin-right: 10px;
}
.widget-section-12-1 .block-social a {
  color: #333;
}
.widget-section-12-1 .block-container .col-md-6:last-child .item {
    background-color: #f2c500;
    padding: 50px 40px;
    position: relative;
}
.widget-section-12-1 .block-container .col-md-6:last-child .item:before {
  content: '';
  width: 100%;
  height: 1000px;
  position: absolute;
  left: 0;
  top: 100%;
  background-color: #f2c500;
}
.widget-section-12-1 .block-title {
  margin-bottom: 30px;
}
.widget-section-12-1 .border-form {
    color: #fff;
}
@media only screen and (max-width: 991px) {
  .widget-section-12-1 .block-contact-info p {
  display: inline-block;
  margin-right: 20px;
  margin-left: 20px;
  }
}


@media only screen and (min-width: 992px) {
.widget-section-12-1 .block-container .col-md-6:last-child .item:after {
  right: 100%;
	top: 50%;
	border: solid transparent;
  border-width: 20px;
	content: " ";
	height: 0;
	width: 0;
	position: absolute;
	pointer-events: none;
	border-right-color: #f2c500;
  transform: translateY(-50%);
}
}


/*-------------------------------- widget-section-13-1 ------------------------------------*/

.widget-section-13-1,
.widget-section-13-1 h6 {
  text-align: left;
}
.widget-section-13-1 .item {
  background-color: #fff;
  padding: 50px 40px;
  border-left: 15px solid #11bbf1;
}
.widget-section-13-1 .widget-content {
  margin-bottom: 30px;
}
@media only screen and (max-width: 600px) {
  .widget-section-13-1 .item {
    background-color: #fff;
    padding: 50px 20px;
  }
}
/*-------------------------------- widget-section-14-1 ------------------------------------*/

.widget-section-14-1,
.widget-section-14-1 h2,
.widget-section-14-1 p {
  text-align: left;
}
.widget-section-14-1 iframe{
  width: 100%;
  height: 380px;
}
.widget-section-14-1 .section-title {
  margin-bottom: 50px;
}
.widget-section-14-1 .block-contact-info {
  display: inline-block;
  margin-right: 20px;
  text-align: left;
}
.widget-section-14-1 .block-contact-info p {
  margin-bottom: 20px;
}
.widget-section-14-1 .block-contact-info .fa {
  font-size: 24px;
  min-width: 36px;
  text-align: center;
}
.widget-section-14-1 .block-social {
  display: inline-block;
}
.widget-section-14-1 .block-social li {
  list-style: none;
  margin-bottom: 20px;
}
.widget-section-14-1 .block-social a {
  display: block;


}
.widget-section-14-1 .block-social .fa {
    font-size: 24px;
    width: 36px;
text-align: center;
}

/*-------------------------------- widget-section-15-1 ------------------------------------*/
.widget-section-15-1,
.widget-section-15-1 h2,
.widget-section-15-1 p {
  text-align: center;
}

/*-------------------------------- widget-section-16-1 ------------------------------------*/
 .widget-section-16-1,
 .widget-section-16-1 h2,
 .widget-section-16-1  p {
   text-align: center;
 }
  .widget-section-16-1 .default-form textarea {
    height: 41px;
    min-height: auto;
  }
@media only screen and (min-width: 992px) {
  .widget-section-16-1 .default-form .dm-contact-btn {
    padding-left: 20px;
  }
  .widget-section-16-1 .default-form button {
      width: 100%;
  }
}
/*-------------------------------- widget-section-17-1 ------------------------------------*/
.widget-section-17-1 h2 {
  text-align: center;
}
.widget-section-17-1 .block-contact-info p {
  text-align: right;
}
.widget-section-17-1 .block-social {
  text-align: left;
}
.widget-section-17-1 p {
  position: relative;
  margin-bottom: 40px;
}
.widget-section-17-1  .fa {
font-family: FontAwesome, Raleway, "Helvetica Neue", Helvetica, Arial, sans-serif;
}
.widget-section-17-1 p .fa {
    font-size: 24px;
    position: absolute;
    top: 3px;
    right: -36px;
    border-left: 1px solid #fff;
    padding-left: 17px;
    width: 20px;
    padding-top: 12px;
    padding-bottom: 12px;
}
.widget-section-17-1 .block-social {
  font-size: 20px;
}

.widget-section-17-1 .block-contact-info {
  padding-right: 80px;
}


.widget-section-17-1 .block-social {
  margin-bottom: 20px;
}
.widget-section-17-1 .block-social  ul {
  padding-left: 0;
}
.widget-section-17-1 .block-social li {
  list-style: none;
  display: inline-block;
  margin-right: 30px;
}
.widget-section-17-1 .block-social li .fa {
  font-size: 24px;
}


@media only screen and (max-width: 991px) {
.widget-section-17-1 .block-contact-info {
  padding-right: 0;
  text-align: center;
}
.widget-section-17-1 .block-contact-info p {
  display: inline-block;
  margin-left: 50px;
  margin-right: 50px;
}
}


/*-------------------------------- BUTTON ------------------------------------*/
.dm-button {
  background-color: #000;
  font-size: 12px;
  font-weight: 500;
  color: #fff;
  padding: 5px 20px;
  text-transform: uppercase;
  letter-spacing: 1px;
  display: inline-block;
  vertical-align: middle;
  text-align: center;
}
.dm-button:hover,
.dm-button:focus {
    text-decoration: none;
    color: #fff;
    outline:none;
}
/*------------------- Style -------------------*/
.dm-button-style-1 {
  border-radius:1000px;
}
.dm-button-style-2 {
  border-radius:0;
}
.dm-button-style-3 {
  border-radius:5px;
}
.dm-button-style-4 {
  border-radius:0px;
  position: relative;
  margin-right: 34px;
}
.dm-button-style-4:before {
  content: '';
  position: absolute;
  left: 100%;
  top: 0;
  width: 36px;
  height: 100%;
  background-color: red;
}
.dm-button-style-4:after {
  font-family: FontAwesome;
  content: '\f054';
  position: absolute;
  top: 50%;
  right: -24px;
  transform: translateY(-50%);
}
/*------------------- Size -------------------*/
.dm-button-lg {
  min-width: 194px;
  padding-top: 10px;
  padding-bottom: 10px;
}
.dm-button-md {
  min-width: 165px;
  padding-top: 7px;
  padding-bottom: 7px;
}
.dm-button-sm {
  min-width: 150px;
  padding-top: 7px;
  padding-bottom: 7px;
}
.dm-button-xs {
  font-size: 10px;
  min-width: 115px;
  padding-top: 7px;
  padding-bottom: 7px;
}
.dm-button-tiny {
  font-size: 10px;
  min-width: 90px;
  padding-top: 6px;
  padding-bottom: 6px;
}

.dm-button-lg.dm-button-style-4 { min-width: 158px; }
.dm-button-md.dm-button-style-4 { min-width: 129px; }
.dm-button-sm.dm-button-style-4 { min-width: 114px; }
.dm-button-xs.dm-button-style-4 { min-width: 79px; }
.dm-button-tiny.dm-button-style-4 { min-width: 54px; }



/*--------------------------------------------------------------------*/
/*col-md*/
@media only screen and (max-width: 991px) {
  .widget-section { text-align: center;}
  .widget-section .item  { margin-bottom: 30px; }
  .widget-section .widget-img { display: inline-block; }

  .widget-section  div[class*="col-"]:last-child  .item  { margin-bottom: 0; }
    /* col-xs-push*/
  .widget-section  div[class*="col-sm-push"] div[class*="col-"]  .item { margin-bottom: 30px; }
  .widget-section  div[class*="col-sm-push"] div[class*="col-"]:last-child  .item { margin-bottom: 0; }
  .widget-section  div[class*="col-xs-push"] div[class*="col-"]  .item { margin-bottom: 30px; }
  .widget-section  div[class*="col-xs-push"] div[class*="col-"]:last-child  .item { margin-bottom: 0; }

}
 
/******** =========================  Carousel Styles ==================== ********/

/* Carousel base class */
.carousel {
    height: 500px;    
}
.carousel-inner > .item > img {
    width:100%;
}
.carousel, .carousel .item, .carousel-inner > .item > img {
	height: 500px;
}

/* Since positioning the image, we need to help out the caption */
.carousel-caption {
    z-index: 0;
	bottom: 130px;
}

.carousel-indicators li {
  border: 1px solid #000;
  background: #000;
}

.carousel-caption h1, .carousel-caption p {
  color: #000;
  text-shadow: none;
}
.carousel-control {
  text-shadow: none;
  opacity: 10;
}
.carousel-control .icon-prev, .carousel-control .icon-next, .carousel-control .fa-angle-left, .carousel-control .fa-angle-right {
  position: absolute;
  top: 50%;
  z-index: 5;
  display: inline-block;
}
.carousel-control .fa-angle-left, .carousel-control .fa-angle-right, .carousel-control .icon-prev, .carousel-control .icon-next {
  width: 31px;
  height: 33px;
  margin-top: -15px;
  font-size: 30px;
}
.carousel-control .icon-next, .carousel-control .fa-angle-right {
  right: 50%;
  margin-right: -10px;
  background: #000;
  border-radius: 5px;
}
.carousel-control .fa-angle-left, .carousel-control .icon-prev {
  margin-left: -15px;
}
.carousel-control .icon-prev, .carousel-control .fa-angle-left {
  left: 50%;
  margin-left: -10px;
  background: #000;
  border-radius: 5px;
}
.carousel-control.right, .carousel-control.left {
  background-image: none;
}
.carousel-control span.fa{
    color:#fff ! important;
}
a.left.carousel-control, a.right.carousel-control  {
    background: none;
}
.imageCarouselWidget {
  padding: 0px;
}
/******** ======================= sliderStyle1 =============================== ********/
.sliderStyle1 .carousel-caption h1, .sliderStyle1 .carousel-caption h2, .sliderStyle1 .carousel-caption h3, .sliderStyle1 .carousel-caption h4, .sliderStyle1 .carousel-caption h5, .sliderStyle1 .carousel-caption h6,
.sliderStyle1 .carousel-caption p{
	text-align:left;
}
.sliderStyle2 .carousel-caption h1, .sliderStyle3 .carousel-caption h1, .sliderStyle2 .carousel-caption h2, .sliderStyle3 .carousel-caption h2, .sliderStyle2 .carousel-caption h3, .sliderStyle3 .carousel-caption h3, .sliderStyle2 .carousel-caption h4, .sliderStyle3 .carousel-caption h4, .sliderStyle2 .carousel-caption h5, .sliderStyle3 .carousel-caption h5, .sliderStyle2 .carousel-caption h6, .sliderStyle3 .carousel-caption h6,
.sliderStyle2 .carousel-caption p, .sliderStyle3 .carousel-caption p
{
	text-align: center;
}

.sliderStyle1 .carousel-caption h1, .sliderStyle2 .carousel-caption h1, .sliderStyle1 .carousel-caption h2, .sliderStyle2 .carousel-caption h2, .sliderStyle1 .carousel-caption h3, .sliderStyle2 .carousel-caption h3, .sliderStyle1 .carousel-caption h4, .sliderStyle2 .carousel-caption h4, .sliderStyle1 .carousel-caption h5, .sliderStyle1 .carousel-caption h5, .sliderStyle1 .carousel-caption h6, .sliderStyle2 .carousel-caption h6, .sliderStyle1 .carousel-caption p, .sliderStyle2 .carousel-caption p {
    
    color: #fff ! important;
    text-shadow: 0 1px 2px rgba(0,0,0,.6) ! important;
}
.sliderStyle3 .carousel-caption h1, .sliderStyle3 .carousel-caption h2, .sliderStyle3 .carousel-caption h3,
.sliderStyle3 .carousel-caption h4, .sliderStyle3 .carousel-caption h5, .sliderStyle3 .carousel-caption h6,
.sliderStyle3 .carousel-caption p{color:#000 ! important;}

.sliderStyle1 .carousel-caption {
  bottom: 23%;
  width: 50%;
  padding: 20px;
  left: 20%;
  text-align:left ! important;
  margin:auto;

}
.sliderStyle1 .carousel-caption h1, .sliderStyle1 .carousel-caption h2, .sliderStyle1 .carousel-caption h3,
.sliderStyle1 .carousel-caption h4, .sliderStyle1 .carousel-caption h5, .sliderStyle1 .carousel-caption h6,
.sliderStyle1 .carousel-caption p {
	
	text-align: left;
}


/******** ========================= sliderStyle2 =========================== ********/
.sliderStyle2 .carousel-caption {
  bottom: 23%;
  padding: 30px;
  left: 25%;
  margin: auto;
}

/******** ========================== sliderStyle3 =========================== ********/
.sliderStyle3 .carousel-caption {
    bottom: 23%;
    background: #fff;
    width: 50%;
    padding: 30px;
    left: 25%;
    margin: auto;
}

/******** ================== Carousel Styles End ================ ********/

/******** =========================  NEW TEMPLATE SLIDER CSS START  ==================== ********/

.themeSlider .carousel-caption, .themeSlider .sliderStyle3 .carousel-caption {
	position: absolute;
	background: rgba(51,51,51,.5);
	text-align: center !important;
	padding: 30px 30px;
    top: 50%;
    margin-top:0;
	text-shadow: 0 1px 2px rgba(0,0,0,.6);
     -webkit-transform:translate(-50%, -50%);
	transform: translate(-50%, -50%);
	left: 50%;
    right:0;
    width:60%;
	bottom:auto !important;
}
.themeSlider .sliderStyle1 .carousel-caption, .themeSlider .sliderStyle2 .carousel-caption {
	background: none;
    padding: 30px 30px;
    text-align: left !important;
    text-shadow: 0 1px 2px rgba(0,0,0,.6);
     -webkit-transform:translate(-50%, -50%);
	transform: translate(-50%, -50%);
	left: 50%;
    right:0;
    width:70%;
	bottom:auto !important;
    
}
.themeSlider .sliderStyle2 .carousel-caption {
	background: rgba(0,0,0,.4);
}
.themeSlider .sliderStyle3 .carousel-caption {
	/*background-color: rgba(250, 250, 250, 0.64)
	  background: rgba(255,255,255,0.75);*/
	  background: rgba(255,255,255,.7);
       
}

.themeSlider .carousel-caption .theme-button, .themeSlider .carousel-caption .theme-button-second {
	margin: 10px 0;
    padding: 10px 20px;
    font-size: 16px;
}
.themeSlider .carousel-caption .theme-button:hover, .themeSlider .sliderStyle2 .carousel-caption .theme-button:hover{color:#fff;}
.themeSlider .carousel-caption h1 {
	font-size: 45px;
}
.themeSlider .carousel-caption h2 {
	font-size: 40px;
}
.themeSlider .carousel-caption h3 {
	font-size: 36px;
}
.themeSlider .carousel-caption h4 {
	font-size: 30px;
}
.themeSlider .carousel-caption h5 {
	font-size: 24px;
}
.themeSlider .carousel-caption h6 {
	font-size: 20px;
}
.themeSlider carousel-caption p {
	font-size: 18px;
}
.themeSlider .carousel-caption h1, .themeSlider .carousel-caption h2, .themeSlider .carousel-caption h3, .themeSlider .carousel-caption h4, .themeSlider .carousel-caption h5, .themeSlider .carousel-caption h6, .themeSlider .carousel-caption p, .themeSlider .sliderStyle3 .carousel-caption h1, .themeSlider .sliderStyle3 .carousel-caption h2, .themeSlider .sliderStyle3 .carousel-caption h3, .themeSlider .sliderStyle3 .carousel-caption h4, .themeSlider .sliderStyle3 .carousel-caption h5, .themeSlider .sliderStyle3 .carousel-caption h6, .themeSlider .sliderStyle3 .carousel-caption p {
	text-align: center;
}
.themeSlider .sliderStyle1 .carousel-caption h1, .themeSlider .sliderStyle2 .carousel-caption h1, .themeSlider .sliderStyle1 .carousel-caption h2, .themeSlider .sliderStyle2 .carousel-caption h2, .themeSlider .sliderStyle1 .carousel-caption h3, .themeSlider .sliderStyle2 .carousel-caption h3, .themeSlider .sliderStyle1 .carousel-caption h4, .themeSlider .sliderStyle2 .carousel-caption h4, .themeSlider .sliderStyle1 .carousel-caption h5, .themeSlider .sliderStyle2 .carousel-caption h5, .themeSlider.sliderStyle1 .carousel-caption h6, .themeSlider .sliderStyle2 .carousel-caption h6, .themeSlider .sliderStyle1 .carousel-caption p, .themeSlider .sliderStyle2 .carousel-caption p {
	text-align: left;
}

.themeSlider .carousel-caption h1, .themeSlider .carousel-caption h2, .themeSlider .carousel-caption h3, .themeSlider .carousel-caption h4, .themeSlider .carousel-caption h5, .themeSlider .carousel-caption h6 {
	font-weight: 900;
	margin: 10px 0;
	padding: 0;
	line-height: 1.2;
}

.themeSlider .carousel-caption h1, .themeSlider .carousel-caption h2, .themeSlider .carousel-caption h3, .themeSlider .carousel-caption h4, .themeSlider .carousel-caption h5, .themeSlider .carousel-caption h6, .themeSlider .carousel-caption p {
	color: #fff;
    text-shadow: 1px 1px 1px #000, 1px 0px 2px #000;
	/*text-shadow: -1px -1px 1px #111, 2px 2px 1px #363636;*/
}
.themeSlider .sliderStyle3 .carousel-caption h1, .themeSlider .sliderStyle3 .carousel-caption h2, .themeSlider .sliderStyle3 .carousel-caption h3, .themeSlider .sliderStyle3 .carousel-caption h4, .themeSlider .sliderStyle3 .carousel-caption h5, .themeSlider .sliderStyle3 .carousel-caption h6, .themeSlider .sliderStyle3 .carousel-caption p {
	color: #000 !important;
	text-shadow:none;

}
.themeSlider .carousel-caption p, .themeSlider .sliderStyle1 .carousel-caption p, .themeSlider .sliderStyle2 .carousel-caption p, .themeSlider .sliderStyle3 .carousel-caption p {
	margin: 10px 0;
	padding: 0;
	line-height: 1.5;
	letter-spacing: normal;
}
.themeSlider .carousel-inner .item:before{
	position: absolute;
    top: 0;
    left: 0;
    z-index: 0;
    display: block;
    width: 100%;
    min-height: 100%;
    height: inherit;
    background: rgba(0,0,0,0.3);
    content: '';
} 	

.themeSlider .carousel-caption a, .themeSlider .sliderStyle1 .carousel-caption a, .themeSlider .sliderStyle2 .carousel-caption a, .themeSlider .sliderStyle3 .carousel-caption a{text-shadow:none;}
.themeSlider .carousel-inner > .item > img {
	width: 100%;
}
.themeSlider .carousel, .themeSlider .carousel .item, .themeSlider .carousel-inner > .item > img {
	height: 500px;
}
.themeSlider .carousel-indicators li {
  border: 1px solid #000;
  background: #000;
}
.themeSlider .carousel-control {
  text-shadow: none;
  opacity: 10;
}
.themeSlider .carousel-control .icon-prev, .themeSlider .carousel-control .icon-next, .themeSlider .carousel-control .fa-angle-left, .themeSlider .carousel-control .fa-angle-right {
  position: absolute;
  top: 50%;
  z-index: 5;
  display: inline-block;
}
.themeSlider .carousel-control .fa-angle-left, .themeSlider .carousel-control .fa-angle-right, .themeSlider .carousel-control .icon-prev, .themeSlider .carousel-control .icon-next {
  width: 31px;
  height: 33px;
  margin-top: -15px;
  font-size: 30px;
}
.themeSlider .carousel-control .icon-next, .themeSlider .carousel-control .fa-angle-right {
  right: 50%;
  margin-right: -10px;
  background: #000;
  border-radius: 5px;
}
.themeSlider .carousel-control .fa-angle-left, .themeSlider .carousel-control .icon-prev {
  margin-left: -15px;
}
.themeSlider .carousel-control .icon-prev, .themeSlider .carousel-control .fa-angle-left {
  left: 50%;
  margin-left: -10px;
  background: #000;
  border-radius: 5px;
}
.themeSlider .carousel-control.right, .themeSlider .carousel-control.left {
  background-image: none;
}
.themeSlider .carousel-control span.fa{
    color:#fff !important;
}
a.left.carousel-control, a.right.carousel-control  {
    background: none;
}	

.imageCarouselWidget {
  padding: 0px;
}

/******** =========================  NEW TEMPLATE SLIDER CSS END  ==================== ********/

/******** =========================  NEW TEMPLATE SLIDER RESPONSIVE CSS START  ==================== ********/


@media only screen and (max-width:1040px) {

.themeSlider .carousel-caption, .themeSlider .sliderStyle3 .carousel-caption {
	padding: 20px 10px;
    margin-top: 0;
}
.themeSlider .sliderStyle1 .carousel-caption, .themeSlider .sliderStyle2 .carousel-caption {
	padding: 20px 20px;
     margin-top:0;
    width:75%;
    left:50%;
    right:0;	
}
.themeSlider .carousel-caption h1 {
	font-size: 36px;
}

}

@media only screen and (min-width: 768px) and (max-width: 1023px) {

.themeSlider .carousel-caption, .themeSlider .sliderStyle3 .carousel-caption {
	padding: 20px 20px;
    margin-top: 0;
    width:70%;
}
.themeSlider .sliderStyle1 .carousel-caption, .themeSlider .sliderStyle2 .carousel-caption {
	padding: 10px 10px;
    margin-top:0;
    width:75%;
    left:50%;
    right:0;	
}
.themeSlider .carousel-caption h1 {
	font-size: 30px;
}
.themeSlider .carousel-caption p {
	font-size: 16px;
}
.themeSlider .carousel-caption .theme-button, .themeSlider .carousel-caption .theme-button-second {
	font-size: 14px;
	padding: 6px 20px;
}
.themeSlider .carousel, .themeSlider .carousel .item, .themeSlider .carousel-inner > .item > img {
	height: 400px;
}

}

@media only screen and (max-width:640px) {

/*.themeSlider .sliderStyle1 .carousel-caption, .themeSlider .sliderStyle2 .carousel-caption {
	padding: 15px 15px;
	right: 10%;
	left: 10%;
	margin-top:0;
}*/
/*.themeSlider .carousel-caption, .themeSlider .sliderStyle3 .carousel-caption {
	right: 12%;
	left: 12%;
}*/
.themeSlider .carousel-caption h1, .themeSlider .carousel-caption h2, .themeSlider .carousel-caption h3, .themeSlider .carousel-caption h4, .themeSlider .carousel-caption h5, .themeSlider .carousel-caption h6, .themeSlider .carousel-caption p {
	margin: 5px 0;
}
.themeSlider .carousel, .themeSlider .carousel .item, .themeSlider .carousel-inner > .item > img {
	height: 300px;
}
.themeSlider .carousel-caption .theme-button, .themeSlider .carousel-caption .theme-button-second {
	font-size: 14px;
	padding: 6px 20px;
	margin: 5px 0;	
}

}

@media only screen and (max-width: 480px) {


.themeSlider .carousel-caption, .themeSlider .sliderStyle3 .carousel-caption, .themeSlider .sliderStyle1 .carousel-caption, .themeSlider .sliderStyle2 .carousel-caption{
	padding: 10px 10px;
    margin-top: 0;
    left:50%;
    right:0;
    width:80%;
}
.themeSlider .carousel-caption h1, .themeSlider .carousel-caption h2, .themeSlider .carousel-caption h3, .themeSlider .carousel-caption h4, .themeSlider .carousel-caption h5, .themeSlider .carousel-caption h6{
	text-overflow: ellipsis;
 	-o-text-overflow: ellipsis;
 	-ms-text-overflow: ellipsis;
	white-space: nowrap;
	overflow: hidden;
	display: block;
}
.themeSlider .carousel-caption .theme-button, .themeSlider .carousel-caption .theme-button-second {
	font-size: 12px;
	padding: 4px 12px;
	margin:5px 0;
}
.themeSlider .carousel-caption h1, .themeSlider .carousel-caption h2, .themeSlider .carousel-caption h3, .themeSlider .carousel-caption h4, .themeSlider .carousel-caption h5, .themeSlider .carousel-caption h6 {
	font-size: 20px;
}
.themeSlider .carousel-caption p, .themeSlider .sliderStyle3 .carousel-caption p {
	font-size: 12px;
}
.themeSlider .carousel-caption h1, .themeSlider .carousel-caption h2, .themeSlider .carousel-caption h3, .themeSlider .carousel-caption h4, .carousel-caption h5, .themeSlider .carousel-caption h6, .themeSlider .carousel-caption p{
	margin: 5px 0;
}
.themeSlider .carousel, .themeSlider .carousel .item, .themeSlider .carousel-inner > .item > img {
	height: 200px;
}
.themeSlider .carousel-control {
	width: 10%;
}
.themeSlider .carousel-control .icon-prev, .themeSlider .carousel-control .fa-angle-left {
	left: 40%;
}
.themeSlider .carousel-control .icon-next, .themeSlider .carousel-control .fa-angle-right {
	right: 40%;
}
.fa-angle-left:before, .fa-angle-right:before {
	line-height: 25px;
}
.themeSlider .carousel-control .fa-angle-left, .themeSlider .carousel-control .fa-angle-right, .themeSlider .carousel-control .icon-prev, .themeSlider .carousel-control .icon-next {
	width: 25px;
	height: 25px;
	font-size: 15px;
}

}

@media only screen and (max-width:403px) {

.themeSlider .carousel-caption, .themeSlider .sliderStyle3 .carousel-caption, .themeSlider .sliderStyle1 .carousel-caption, .themeSlider .sliderStyle2 .carousel-caption{
	padding: 10px 10px;
    margin-top: 0;
    left:50%;
    right:0;
    width:80%;
}
.themeSlider .carousel-caption h1, .themeSlider .carousel-caption h2, .themeSlider .carousel-caption h3, .themeSlider .carousel-caption h4, .themeSlider .carousel-caption h5, .themeSlider .carousel-caption h6, .themeSlider .carousel-caption p{
	margin: 5px 0;
}
.themeSlider .carousel-caption h1, .themeSlider .carousel-caption h2, .themeSlider .carousel-caption h3, .themeSlider .carousel-caption h4, .themeSlider .carousel-caption h5, .themeSlider .carousel-caption h6, .themeSlider .carousel-caption p{
	text-overflow: ellipsis;
 	-o-text-overflow: ellipsis;
 	-ms-text-overflow: ellipsis;
	white-space: nowrap;
	overflow: hidden;
	display: block;
}
.themeSlider .carousel-caption h1, .themeSlider .carousel-caption h2, .themeSlider .carousel-caption h3, .themeSlider .carousel-caption h4, .themeSlider .carousel-caption h5, .themeSlider .carousel-caption h6 {
	font-size: 20px;
}
.themeSlider .carousel-caption p, .themeSlider .sliderStyle3 .carousel-caption p {
	font-size: 12px;
}
.themeSlider .carousel-caption .theme-button, .themeSlider .carousel-caption .theme-button-second {
	font-size: 12px;
	padding: 4px 12px;
	margin:5px 0;
}

}

/******** =========================  NEW TEMPLATE SLIDER RESPONSIVE CSS END ==================== ********/






.widget-title {
    background-color: #000;
    color: #fff;
    padding: 20px 0;
    text-align: center;
    font-size: 30px;
    font-weight: bold;
    text-transform: uppercase;
}
.widget-blog-06[class*="theme-dark-color-"] .blog-item-box.small .blog-item-box-content *,
.widget-blog-05[class*="theme-dark-color-"] .blog-item-box.small .blog-item-box-content * {
    color: #fff;
}
.widget-blog-04[class*="theme-dark-color-"] .blog-item-box-content * {
    color: #000;
}
/***** Blog Widget 01 *****/
.widget-blog-01 .blog-item-box {
    width: 100%;
    height: 100%;
    position: relative;
}

.widget-blog-01 .blog-item-box .blog-item-box-image {
    position: relative;
    width: 100%;
    height: 400px;
}
.widget-blog-01 .blog-item-box .blog-item-box-image:before {content: '';width: 100%;height: 100%;position: absolute;top: 0;left: 0;background-color: rgba(0,0,0,0.3);}

.widget-blog-01 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
}

.widget-blog-01 .blog-item-box .blog-item-box-content {
    position: absolute;
    bottom: 20px;
    left: 20px;
}

.widget-blog-01 [class|=col]:nth-child(3) .blog-item-box-image {
    height: 195px;
    margin-bottom: 10px;
}

.widget-blog-01 [class*=col-] {
    padding-left: 5px;
    padding-right: 5px;
}

.widget-blog-01 .blog-item-box .blog-item-box-content h3, .widget-blog-01 .blog-item-box .blog-item-box-content h6 {
    margin-top: 0;
    margin-bottom: 5px;
    color: #fff;
    text-align: left;
}

.widget-blog-01 .blog-item-box .blog-item-box-content h3 {
    font-size: 24px;
    font-weight: bold;
}

.widget-blog-01 .blog-item-box .blog-item-box-content h6 {
    font-size: 14px;
}

.widget-blog-01 .blog-item-box .blog-item-box-content h6 span {font-weight: bold;}
@media (min-width: 768px) and (max-width: 1023px) {
.widget-blog-01 .blog-item-box .blog-item-box-content {
    width: 100%;
	left:10px;
}

.widget-blog-01 .blog-item-box .blog-item-box-content * {
    text-align: left;
}

.widget-blog-01 .blog-item-box .blog-item-box-content h3 {
    font-size: 18px;
}

.widget-blog-01 .blog-item-box .blog-item-box-content 
 h6 {
    font-weight: normal;
}
}
@media max-width: 640px) {
.widget-blog-01 .blog-item-box .blog-item-box-content {
    width: 90%;
    left: 50%;
    transform: translateX(-50%);
}
}
/***** Blog Widget 02 *****/
.widget-blog-02 .blog-item-box {
    width: 100%;
    height: 100%;
    padding: 0px;
    position: relative;
}

.widget-blog-02 .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 670px;
    position: relative;
}

.widget-blog-02 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
}

.widget-blog-02 [class|=col]:nth-child(1) .blog-item-box-image {
    height: 223.3px;
}

.widget-blog-02 .blog-item-box .blog-item-box-content {position: absolute;top: 50%;text-align: center;left: 50%;background-color: #fff;transform: translate(-50%, -50%);padding: 30px;display: inline-block;}
.widget-blog-02 [class|=col]:nth-child(1) .blog-item-box-content {
    padding: 10px;
    width: 230px;
}
.widget-blog-02 [class|=col]:nth-child(1) .blog-item-box-content h3 {
    font-size: 18px;
}
.widget-blog-02 [class*=col-] {
    padding-left: 0;
    padding-right: 0;
}
/***** Blog Widget 03 *****/
.widget-blog-03 .blog-item-box {
    width: 100%;
    height: 100%;
    border: 1px solid #eaecec;
    box-shadow: 0px 9px 29px 0px #e4e8ea;
    padding: 10px;
    border-radius: 10px;
}

.widget-blog-03 .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 400px;
}

.widget-blog-03 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
    border-radius: 10px;
}

.widget-blog-03 .blog-item-box .blog-item-box-content {
    text-align: left;
    padding: 15px;
}

.widget-blog-03 .blog-item-box .blog-item-box-content h3, .widget-blog-03 .blog-item-box .blog-item-box-content h6 {
    margin-top: 0;
    margin-bottom: 10px;
}

.widget-blog-03 .blog-item-box .blog-item-box-content h3 {
    font-size: 24px;
    font-weight: bold;
    text-transform: uppercase;
}

.widget-blog-03 .blog-item-box .blog-item-box-content h6 {font-size: 14px;font-weight: normal;}

.widget-blog-03 .blog-item-box .blog-item-box-content h6 span {
    font-weight: bold;
}

.widget-blog-03 .blog-item-box .blog-item-box-content p {
    font-size: 14px;
    line-height: 25px;
    color: #444;
}

.widget-blog-03 [class|=col]:nth-child(2) .blog-item-box {
    margin-bottom: 30px;
    width: 100%;
    float: left;
    height: 171px;
    max-height: 171px;
    overflow: hidden;
}

.widget-blog-03 [class|=col]:nth-child(2) .blog-item-box-image {
    width: 140px;
    height: 140px;
    float: left;
}

.widget-blog-03 [class|=col]:nth-child(2) .blog-item-box-content {
    margin-left: 150px;
    background-color: transparent;
    padding: 5px;
}

.widget-blog-03 [class|=col]:nth-child(2) .blog-item-box-content p {
    margin-bottom: 0;
}
/***** Blog Widget 04 *****/
.widget-blog-04 .blog-item-box {
    width: 100%;
    height: 100%;
    position: relative;
}

.widget-blog-04 .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 400px;
}

.widget-blog-04 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
}

.widget-blog-04 .blog-item-box .blog-item-box-content {position: relative;left: 0;top: auto;right: auto;bottom: 0;z-index: 3;width: 420px;margin-top: -132px;padding: 40px;border: 1px dashed rgba(22,28,28,.1);background-color: #fff;}

.widget-blog-04 .blog-item-box .blog-item-box-content h3, .widget-blog-04 .blog-item-box .blog-item-box-content h6, .widget-blog-04 .blog-item-box .blog-item-box-content p {
    margin-top: 0;
    margin-bottom: 10px;
}

.widget-blog-04 .blog-item-box .blog-item-box-content h3 {
    font-size: 24px;
    font-weight: bold;
}

.widget-blog-04 [class|=col]:nth-child(1) .blog-item-box, .widget-blog-04 [class|=col]:nth-child(2) .blog-item-box {
    margin-bottom: 30px;
}

.widget-blog-04 .blog-item-box .blog-item-box-content .post-category {
    font-size: 16px;
    font-weight: normal;
    margin-bottom: 20px;
    color: #fd9a4d;
}
@media (min-width: 768px) and (max-width: 1023px) {
	
.widget-blog-04 .blog-item-box .blog-item-box-content {
    width: 100%;
    top: 0;
    margin-top: 0;
}

.widget-blog-04 .blog-item-box .blog-item-box-content .post-category {
    text-align: left;
}
.widget-blog-04 .blog-item-box .blog-item-box-content h3 {
    font-size: 18px;
}

.widget-blog-04 .blog-item-box .blog-item-box-content h6 {
    font-weight: normal;
}
}
@media (max-width: 640px) {
.widget-blog-04 .blog-item-box  .blog-item-box-image {
    height: 220px;
}
.widget-blog-04 .blog-item-box  .blog-item-box-content {
    width: 100%;
    top: 0;
    margin-top: 0;
    padding: 15px;
}
.widget-blog-04 .blog-item-box .blog-item-box-content .post-category {
    text-align: left;
    margin-bottom: 10px;
}
.widget-blog-04 .blog-item-box .blog-item-box-content h3 {
    font-size: 18px;
}
.widget-blog-04 .blog-item-box .blog-item-box-content h6 {
    font-weight:normal;
}
}
/***** Blog Widget 05 *****/
.widget-blog-05 .blog-item-box {
    width: 100%;
    height: 100%;
}
.widget-blog-05 .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 470px;
    position: relative;
}

.widget-blog-05 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
}

.widget-blog-05 [class|=col]:nth-child(2) .blog-item-box-image {
    height: 200px;
}

.widget-blog-05 .blog-item-box .blog-item-box-content {
    padding: 30px 0;
}

.widget-blog-05 .blog-item-box .blog-item-box-content h6, .widget-blog-05 .blog-item-box .blog-item-box-content h3, .widget-blog-05 .blog-item-box .blog-item-box-content p {
    margin-top: 0;
    margin-bottom: 10px;
}

.widget-blog-05 .blog-item-box .blog-item-box-content h6 {
    margin-bottom: 20px;
    font-size: 14px;
    color: #888;
}

.widget-blog-05 .blog-item-box .blog-item-box-content h3 {
    font-size: 24px;
    font-weight: bold;
}

.widget-blog-05 .blog-item-box .blog-item-box-content p {
    font-size: 14px;
    line-height: 25px;
}
@media (max-width: 640px) {
.widget-blog-05 .blog-item-box .blog-item-box-content * {
    text-align: left;
}
}
@media (min-width: 768px) and (max-width: 1023px) {
.widget-blog-05 .blog-item-box .blog-item-box-image {
    height: 320px;
}
.widget-blog-05 .blog-item-box .blog-item-box-content h6 {
    margin-bottom: 10px;
    font-weight: normal;
}
.widget-blog-05 .blog-item-box .blog-item-box-content h3 {
    font-size: 18px;
}
}
/***** Blog Widget 06 *****/
.widget-blog-06 .blog-item-box {
    width: 100%;
    height: 100%;
    position: relative;
}

.widget-blog-06 .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 220px;
    position: relative;
    border-radius: 5px;
}

.widget-blog-06 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
    border-radius: 5px;
}

.widget-blog-06 [class|=col] .blog-item-box.small .blog-item-box-image {height: 100px;width: 130px;float: left;}

.widget-blog-06 .blog-item-box .blog-item-box-content {
    padding: 10px 0;
}

.widget-blog-06 [class|=col] .blog-item-box.small .blog-item-box-content {
    overflow: hidden;
    margin-left: 130px;
    position: static;
    width: auto;
    background-color: transparent;
}

.widget-blog-06 .blog-item-box .blog-item-box-content h3, .widget-blog-06 .blog-item-box .blog-item-box-content h6, .widget-blog-06 .blog-item-box .blog-item-box-content p {
    margin-top: 0;
    margin-bottom: 10px;
}
.widget-blog-06 .blog-item-box .blog-item-box-content h3 {
    font-size: 24px;
    font-weight: bold;
}

.widget-blog-06 .blog-item-box.small .blog-item-box-content h3 {
    font-size: 18px;
}
.widget-blog-06 .blog-item-box.small {
    float: left;
    margin-bottom: 20px;
}

.widget-blog-06 .blog-item-box .blog-item-box-content {
    position: absolute;
    bottom: 0;
    padding: 10px;
    width: 100%;
}

.widget-blog-06 .blog-item-box:first-child {
    margin-bottom: 20px;
}

.widget-blog-06 .blog-item-box .blog-item-box-content * {
    color: #fff;
}

.widget-blog-06 .blog-item-box.small .blog-item-box-content * {
    color: #000;
}

.widget-blog-06 .blog-item-box .blog-item-box-image:before {content: '';width: 100%;height: 100%;position: absolute;top: 0;left: 0;background-color: #000;opacity: 0.6;border-radius: 5px;}

.widget-blog-06 .blog-item-box.small .blog-item-box-image::before {
    content: '';
    display: none;
}
.widget-blog-06 .blog-item-box {
    width: 100%;
    height: 100%;
    position: relative;
}

.widget-blog-06 .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 220px;
    position: relative;
    border-radius: 5px;
}

.widget-blog-06 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
    border-radius: 5px;
}

.widget-blog-06 [class|=col] .blog-item-box.small .blog-item-box-image {height: 100px;width: 130px;float: left;}

.widget-blog-06 .blog-item-box .blog-item-box-content {
    padding: 10px 0;
}

.widget-blog-06 [class|=col] .blog-item-box.small .blog-item-box-content {
    overflow: hidden;
    margin-left: 130px;
    position: static;
    width: auto;
    background-color: transparent;
}

.widget-blog-06 .blog-item-box .blog-item-box-content h3, .widget-blog-06 .blog-item-box .blog-item-box-content h6, .widget-blog-06 .blog-item-box .blog-item-box-content p {
    margin-top: 0;
    margin-bottom: 10px;
}

.widget-blog-06 .blog-item-box.small {
    float: left;
    margin-bottom: 20px;
}

.widget-blog-06 .blog-item-box .blog-item-box-content {
    position: absolute;
    bottom: 0;
    padding: 10px;
    width: 100%;
}

.widget-blog-06 .blog-item-box:first-child {
    margin-bottom: 20px;
}

.widget-blog-06 .blog-item-box .blog-item-box-content * {
    color: #fff;
}

.widget-blog-06 .blog-item-box.small .blog-item-box-content * {
    color: #000;
}

.widget-blog-06 .blog-item-box .blog-item-box-image:before {content: '';width: 100%;height: 100%;position: absolute;top: 0;left: 0;background-color: #000;opacity: 0.6;border-radius: 5px;}

.widget-blog-06 .blog-item-box.small .blog-item-box-image::before {
    content: '';
    display: none;
}
@media (min-width: 768px) and (max-width: 1024px) {
.widget-blog-06 .blog-item-box .blog-item-box-image {
    height: 320px;
}
.widget-blog-06 .blog-item-box.small {
    width: 50%;
}
.widget-blog-06 [class|=col] .blog-item-box.small .blog-item-box-content {
    text-align: left;
}
}

@media (max-width: 640px) {
.widget-blog-06 [class|=col] .blog-item-box.small .blog-item-box-image, .widget-blog-06 [class|=col] .blog-item-box.small .blog-item-box-content {
    width: 100%;
}

.widget-blog-06 [class|=col] .blog-item-box.small .blog-item-box-image {
    height: 150px;
}

.widget-blog-06 [class|=col] .blog-item-box.small .blog-item-box-content {
    margin-left: 0;
}

.widget-blog-06 [class|=col] .blog-item-box.small .blog-item-box-content h6 {
    font-weight: normal;
}
}
/***** Blog Widget 07 *****/
.widget-blog-07 {
    width: 100%;
    height: 100%;
    position: relative;
}

.widget-blog-07 .blog-item-box {
    position: relative;
}

.widget-blog-07 .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 390px;
    position: relative;
}

.widget-blog-07 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
}

.widget-blog-07 .blog-item-box .blog-item-box-content {
    position: absolute;
    bottom: 10px;
    left: 50%;
    text-align: center;
    transform: translateX(-50%);
    width: 100%;
}

.widget-blog-07 .blog-item-box .blog-item-box-image:before {content: '';width: 100%;height: 100%;position: absolute;top: 0;left: 0;background-color: rgba(0,0,0,0.3);}


.widget-blog-07 [class*=col-] {
    padding-left: 0;
    padding-right: 0;
}

.widget-blog-07 .blog-item-box .blog-item-box-content * {
    color: #fff;
    text-align: center;
}
/***** Blog Widget 08 *****/
.widget-blog-08 [class*=col-]:nth-child(2) {padding-left: 5px;padding-right: 5px;}

.widget-blog-08 [class*=col-] {
    padding-left: 0;
    padding-right: 0;
}

.widget-blog-08 .blog-item-box {
    width: 100%;
    height: 100%;
    position: relative;
}

.widget-blog-08 .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 390px;
    position: relative;
}

.widget-blog-08 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
}

.widget-blog-08 .blog-item-box .blog-item-box-content {
    text-align: center;
    width: 80%;
    margin: 0 auto;
    position: relative;
    top: -40px;
    background-color: #fff;
    padding: 15px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
    box-shadow: 0 1px 4px -1px rgb(0 0 0 / 5%);
}

.widget-blog-08 .blog-item-box .blog-item-box-content h6 {}

.widget-blog-08 .blog-item-box .blog-item-box-content .post-category {
    position: absolute;
    top: -10px;
    background-color: #f28d4b;
    border-radius: 5px;
    color: #fff;
    padding: 4px 20px;
    font-size: 14px;
    text-align: center;
    margin: 0 auto;
    left: 50%;
    transform: translateX(-50%);
}

widget-blog-09 .side-left, widget-blog-09 .side-right {
    width: 50%;
    float: left;
}

.widget-blog-09 .side-left, .widget-blog-09 .side-right {
    width: 50%;
    float: left;
}

.widget-blog-09 [class*="col-"] {
    padding-left: 0;
    padding-right: 0;
}

.widget-blog-09 .side-right .blog-item-box.small {
    width: 100%;
    display: table;
    border-bottom: 1px solid #e5e5e5;
    padding: 10px 0;
}

.widget-blog-09 .side-right .blog-item-box.small .blog-item-box-image {
    display: table-cell;
    width: 100px;
    height: 75px;
}

.widget-blog-09 .side-right .blog-item-box.small .blog-item-box-content {
    display: table-cell;
    overflow: hidden;
    padding-left: 10px;
    vertical-align: middle;
}

.widget-blog-09 .side-right .blog-item-box.small .blog-item-box-image img {
    width: 100%;
    height: 100%;
}

.widget-blog-09 .side-right {
    background-color: #fff;
    padding: 0 10px;
    box-shadow: 0px 0px 16px 0px rgb(39 48 75 / 14%);
}

.widget-blog-09 .side-left {
    /* box-shadow: 0px 0px 16px 0px rgb(39 48 75 / 14%); */
    background-color: #fff;
    padding: 0;
}

.widget-blog-09 .side-left .blog-item-box {
}

.widget-blog-09 .side-left .blog-item-box .blog-item-box-image {}

.widget-blog-09 .side-right .blog-item-box.small .blog-item-box-content h3 {
    font-size: 16px;
    font-weight: bold;
}

.widget-blog-09 .side-right .blog-item-box.small .blog-item-box-content h6 {
    font-size: 12px;
    line-height: 15px;
}

.widget-blog-09 .side-right .blog-item-box.small .blog-item-box-content h3, .widget-blog-09 .side-right .blog-item-box.small .blog-item-box-content h6 {
    margin-top: 0;
    margin-bottom: 10px;
}

.widget-blog-09 .side-right .blog-item-box.small:last-child {
    border-bottom: 0;
}

.widget-blog-09 .side-left .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 200px;
}

.widget-blog-09 .side-left .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
}

.widget-blog-09 .side-left .blog-item-box .blog-item-box-content {
    width: 100%;
    text-align: left;
    max-height: 87px;
    height: 87px;
    padding: 10px;
    text-align: center;
}

.widget-blog-09 .side-left .blog-item-box .blog-item-box-content h3 {
    font-weight: bold;
    font-size: 24px;
}

.widget-blog-09 .side-left .blog-item-box .blog-item-box-content h3, .widget-blog-09 .side-left .blog-item-box .blog-item-box-content h6 {
    margin-top: 0;
    margin-bottom: 10px;
}
.widget-blog-10 .blog-item-box {
    width: 100%;
    height: 100%;
    position: relative;
}

.widget-blog-10 .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 370px;
}

.widget-blog-10 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
    box-shadow: 0px 0px 16px 0px rgb(39 48 75 / 14%);
}

.widget-blog-10 .blog-item-box .blog-item-box-content {
    padding: 10px;
    text-align: center;
    background-color: #f9fbfc;
}

.widget-blog-10 .blog-item-box .blog-item-box-content h3, .widget-blog-10 .blog-item-box .blog-item-box-content h6, .widget-blog-10 .blog-item-box .blog-item-box-content p {
    margin-top: 0;
    margin-bottom: 10px;
}

.widget-blog-10 .blog-item-box .blog-item-box-content h3 {
    font-size: 24px;
    font-weight: bold;
}

.widget-blog-10 .blog-item-box .blog-item-box-content h6 {
    font-weight: 600;
}

.widget-blog-10 .blog-item-box .blog-item-box-content p {
    font-size: 14px;
    line-height: 25px;
}

.widget-blog-10 [class*="col-"]:nth-child(1) .blog-item-box .blog-item-box-image,
.widget-blog-10 [class*="col-"]:nth-child(3) .blog-item-box .blog-item-box-image {
    height: 180px;
}

.widget-blog-10 [class*="col-"]:nth-child(1) .blog-item-box,
.widget-blog-10 [class*="col-"]:nth-child(3) .blog-item-box {
    margin-bottom: 15px;
}

.widget-blog-10 [class*="col-"]:nth-child(1) .blog-item-box .blog-item-box-content {}

.widget-blog-10 [class*="col-"]:nth-child(1) .blog-item-box .blog-item-box-content h3, .widget-blog-10 [class*="col-"]:nth-child(3) .blog-item-box .blog-item-box-content h3 {
    font-size: 18px;
}

.widget-blog-11 .blog-item-box {
    width: 100%;
    height: 100%;
    position: relative;
}
.widget-blog-11 .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 400px;
    position: relative;
}
.widget-blog-11 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
}
.widget-blog-11 .blog-item-box .blog-item-box-content {position: absolute;left: 50%;top: 50%;right: auto;z-index: 3;width: 420px;padding: 40px;border: 1px dashed rgba(22,28,28,.1);text-align: center;transform: translate(-50%, -50%);}
.widget-blog-11 .blog-item-box .blog-item-box-content h3, .widget-blog-11 .blog-item-box .blog-item-box-content h6, .widget-blog-11 .blog-item-box .blog-item-box-content p {
    margin-top: 0;
    margin-bottom: 10px;
}
.widget-blog-11 .blog-item-box .blog-item-box-content h3 {
    font-size: 24px;
    font-weight: bold;
}
.widget-blog-11 .blog-item-box .blog-item-box-content * {
    text-align: center;
}
.widget-blog-11 [class|=col]:nth-child(1) .blog-item-box, .widget-blog-blog-11 [class|=col]:nth-child(2) .blog-item-box {
    margin-bottom: 30px;
}
.widget-blog-11 .blog-item-box .blog-item-box-content .post-category {
    font-size: 16px;
    font-weight: normal;
    margin-bottom: 20px;
    color: #FFFFFF;
    border: 1px solid #fff;
    display: inline-block;
    padding: 7px 20px;
}
.widget-blog-11 [class*=col-] {
    padding-left: 0;
    padding-right: 0;
}
.widget-blog-11 [class*=col-]:nth-child(2) {
    padding-left: 5px;
    padding-right: 5px;
}
.widget-blog-11 .blog-item-box .blog-item-box-image:before {content: '';width: 100%;height: 100%;background-color: rgba(0,0,0,0.5);position: absolute;top: 0;left: 0;}
.widget-blog-11 .blog-item-box .blog-item-box-content * {
    color: #fff;
}
@media (min-width: 768px) and (max-width: 1023px) { 
	.widget-blog-11 .blog-item-box .blog-item-box-image {
    height: 240px;
}

.widget-blog-11 .blog-item-box .blog-item-box-content {
    width: 100%;
    padding: 0 10px;
}

.widget-blog-11 .blog-item-box .blog-item-box-contenth3 {}

.widget-blog-11 .blog-item-box .blog-item-box-content .post-category {
    font-size: 14px;
    padding: 2px 10px;
}

.widget-blog-11 .blog-item-box .blog-item-box-content  h3 {
    font-size: 18px;
}

.widget-blog-11 .blog-item-box .blog-item-box-content h6 {
    font-size: 14px;
    font-weight: normal;
}
}
@media (max-width: 640px) {
.widget-blog-11 [class*=col-]:nth-child(2) {
    padding-left: 0;
    padding-right: 0;
	padding-top: 5px;
    padding-bottom: 5px;
}
.widget-blog-11 [class|=col]:nth-child(1) .blog-item-box, .widget-blog-blog-11 [class|=col]:nth-child(2) .blog-item-box {
    margin-bottom: 0;
}
.widget-blog-11 .blog-item-box .blog-item-box-image {
    height: 200px;
}
.widget-blog-11 .blog-item-box .blog-item-box-content {
    width: 100%;
}
.widget-blog-11 .blog-item-box .blog-item-box-content .post-category {
    padding: 1px 10px;
    font-size: 12px;
}
.widget-blog-11 .blog-item-box .blog-item-box-content h3 {
    font-size: 16px;
}
.widget-blog-11 .blog-item-box .blog-item-box-content h6 {
    font-size: 14px;
    font-weight: normal;
}
}
/*.widget-blog-12 .blog-item-box {
    width: 100%;
    height: 100%;
    position: relative;
    border-radius: 10px;
}

.widget-blog-12 .blog-item-box .blog-item-box-image {
    width: 100%;
    height: 400px;
    position: relative;
}

.widget-blog-12 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
    border-radius: 10px;
}

.widget-blog-12 .blog-item-box .blog-item-box-content {position: relative;left: 0;top: auto;right: auto;bottom: 0;z-index: 3;width: 420px;margin-top: -132px;padding: 40px;border: 1px dashed rgba(22,28,28,.1);background-color: #fff;}

.widget-blog-12 .blog-item-box .blog-item-box-content h3, .widget-blog-12 .blog-item-box .blog-item-box-content h6, .widget-blog-04 .blog-item-box .blog-item-box-content p {
    margin-top: 0;
    margin-bottom: 10px;
}

.widget-blog-12 .blog-item-box .blog-item-box-content h3 {
    font-size: 24px;
    font-weight: bold;
}

.widget-blog-12 [class|=col]:nth-child(1) .blog-item-box, .widget-blog-12 [class|=col]:nth-child(2) .blog-item-box {
    margin-bottom: 30px;
}

.widget-blog-12 .blog-item-box .blog-item-box-content .post-category {
    font-size: 16px;
    font-weight: normal;
    margin-bottom: 20px;
    color: #fd9a4d;
}
.widget-blog-12 .blog-item-box .blog-item-box-content {
    top: 50%;
    position: absolute;
    margin: 0;
    bottom: auto;
    transform: translateY(-50%);
    background-color: transparent;
    border: 0;
}

.widget-blog-12 .blog-item-box .blog-item-box-image:before {content: '';width: 100%;height: 100%;background-color: #060606;position: absolute;opacity: 0.5;border-radius: 10px;}

.widget-blog-12 .blog-item-box .blog-item-box-content * {
    color: #fff;

}*/
.widget-blog-12  .blog-item-box {
    width: 100%;
    height: 100%;
    position: relative;
    border-radius: 10px;
	margin-bottom:30px;
}
.widget-blog-12  .blog-item-box  .blog-item-box-content {
    position: static;
    padding: 0 15px 15px 15px;
    top: 0;
    transform: translateY(0);
    width: 100%;
    margin: 0;
    -webkit-box-shadow: 0px 2px 2px 0px rgb(0 0 0 / 13%);
    -moz-box-shadow: 0px 2px 2px 0px rgba(0,0,0,0.125);
    box-shadow: 0px 2px 2px 0px rgb(0 0 0 / 13%);
    position: relative;
}

.widget-blog-12  .blog-item-box  .blog-item-box-content * {
    color: #000;
}

.widget-blog-12  .blog-item-box  .blog-item-box-image {
    height: 270px;
}
.widget-blog-12  .blog-item-box  .blog-item-box-image img {
    border-radius: 10px 10px 0 0;
	width:100%;
	height:100%;
}
.widget-blog-12  .blog-item-box  .blog-item-box-image:before {
    content: '';
    display: none;
}

.widget-blog-12  .blog-item-box  .blog-item-box-content h6 {
    font-size: 14px;
    margin: 0;
    font-weight: normal;
    font-family: 'Open Sans', sans-serif;
    border-top: 1px solid #eee;
    padding: 10px 0 0 0;
}



.widget-blog-12  .blog-item-box  .blog-item-box-content .post-category {
    background-color: #fff;
    display: inline-block;
    padding: 5px 30px;
    color: #000;
    border-radius: 3px;
    top: -20px;
    position: relative;
    margin: 0;
}

.widget-blog-12  .blog-item-box  .blog-item-box-content h3 {
    font-size: 20px;
}

.widget-blog-12  .blog-item-box  .blog-item-box-content p {
    font-size: 14px;
}

.widget-blog-12  .blog-item-box  .blog-item-box-content h6 span {
    font-weight: 600;
}
@media (min-width: 768px) and (max-width: 1023px) {
.widget-blog-12  .blog-item-box  .blog-item-box-image {
    height: 200px;
}
.widget-blog-12  .blog-item-box  .blog-item-box-content h3 {
    font-size: 18px;
}
}
widget-blog-13 .blog-item-box {
    width: 100%;
    height: 100%;
    float: left;
}

widget-blog-13 .blog-item-box .blog-item-box-image {}

.widget-blog-13 .blog-item-box {
    display: table;
    table-layout: fixed;
    background-color: #fff;
    box-shadow: 0px 9px 29px 0px #e4e8ea;
    margin-bottom: 30px;
}

.widget-blog-13 .blog-item-box .blog-item-box-image, .widget-blog-13 .blog-item-box .blog-item-box-content {
    display: table-cell;
    vertical-align: top;
}

.widget-blog-13 .blog-item-box .blog-item-box-image {
    width: 200px;
    height: 270px;
}

.widget-blog-13 .blog-item-box .blog-item-box-image img {
    width: 100%;
    height: 100%;
}

.widget-blog-13 .blog-item-box .blog-item-box-content {
    padding: 40px 15px;
}


.widget-blog-13 .blog-item-box .blog-item-box-content h6 {
    font-size: 14px;
    margin-bottom: 0;
}

.widget-blog-13 .blog-item-box .blog-item-box-content p {
    font-size: 14px;
}

.widget-blog-13 .blog-item-box .blog-item-box-content h3 {
    font-size: 20px;
}
.widget-blog-13 .blog-item-box .blog-item-box-content * {
	text-align:left;
}
@media (min-width: 1024px) and (max-width: 1199px) {
.widget-blog-13 .blog-item-box .blog-item-box-content {
    padding: 15px 20px;
}
}
@media (max-width: 1023px) {
.widget-blog-13 .blog-item-box .blog-item-box-image, .widget-blog-13 .blog-item-box .blog-item-box-content {
    width: 100%;
    display: block;
}
.widget-blog-13 .blog-item-box .blog-item-box-content {
    padding: 30px 10px;
	text-align:left;
}
}
@media (min-width: 320px) and (max-width: 640px) {
.widget-blog-13 .blog-item-box .blog-item-box-image, .widget-blog-13 .blog-item-box .blog-item-box-content {
    width: 100%;
    display: block;
}
.widget-blog-13 .blog-item-box .blog-item-box-content {
    padding: 30px 10px;
}
}



/* section.slider{overflow: hidden;
  perspective: 4000px;}*/
  
  /*section.slider .imageWidget {
  transform-style: preserve-3d;
}*/
/*section.slider .imageWidget img:first-child {
  transform: translateZ(50px);
}*/
/*section.slider .imageWidget img:nth-child(2) {
  transform: translateZ(290px);
}*/
 
/* section.slider{overflow: hidden;
  perspective: 4000px;}*/
  
  /*section.slider .imageWidget {
  transform-style: preserve-3d;
}   */
    
/*section.slider .imageWidget img:first-child {
  transform: translateZ(50px);
}*/
 
/*section.slider .imageWidget img:nth-child(2) {
  transform: translateZ(290px);
}*/
 
/*section.slider .imageWidget img:nth-child(3) {
  transform: translateZ(400px);
} */   
.navbar-right .dropdown-menu {
	left: 0;
}
.glyphicon {
	margin-right: 5px;
}
.thumbnail {
	margin-bottom: 20px;
	/*padding: 0px;
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;*/
}
.item.list-group-item {
	float: none;
	width: 100%;
	background-color: #fff;
	margin-bottom: 10px;
}
.item.list-group-item:nth-of-type(odd):hover, .item.list-group-item:hover {
 background: #000;
}
.item.list-group-item .list-group-image {
	margin-right: 10px;
}
.item.list-group-item .thumbnail {
	margin-bottom: 0px;
}
.list-group-item {
	padding: 1px 1px!important;
}
.item.list-group-item .caption {
	padding: 9px 9px 0px 9px;
}
.item.list-group-item:nth-of-type(odd) {
	background: #eeeeee;
}
.item.list-group-item:before, .item.list-group-item:after {
	display: table;
	content: " ";
}
.item.list-group-item img {
	float: left;
}
.item.list-group-item:after {
	clear: both;
}
.list-group-item-text {
	margin: 0 0 11px;
}
.minicart-details-price {
	margin-top: -15px!important;
}
.minicart-closer {
	color: black!important;
}
.selectedProductColor {
	border: 2px solid #ccc;
}
.minicart-showing #PPMiniCart {
	z-index: 99999999999999
}
.ecommerceWidget {
}
.ecommerceWidget h3, .ecommerceWidget p {
	text-align: left;
}
.ecommerceWidget .caption h3 {    
    text-overflow: ellipsis;
    -o-text-overflow: ellipsis;    
    -ms-text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    font-size: 24px;
    font-weight: 600;    
}

.ecommerce-image img {
	width: 100% !important;
	height: 220px;
	object-fit: contain;
}
.add-to-cart-btn {
	border-radius: 4px;
}
.add-option-btn {
	border: 1px solid #f2b754!important;
	color: #fff;
	display: inline-block;
	font-size: 14px;
	text-decoration: none;
	cursor: pointer;
	margin-top: 5px;
	line-height: normal;
	padding: 8px 15px;
	background: #f2b754;
}
.add-option-btn:hover, .add-option-btn:focus {
	background: transparent;
	border: 1px solid #f2b754!important;
	color: #f2b754;
}
.price-tag {
	color: green;
}
ul#productOptions {
	list-style-type: none;
}
ul#productOptions li .fa-close {
	margin-top: 0px;
	float: left;
	padding: 12px 11px;
	background: #e74c3c;
	color: #fff;
}
.cart-caption select option {
	background: transparent!important;
}
.dropdown-menu {
	border-radius: 0;
	border: 0;
	padding: 0;
}
.dropdown-menu li {
	width: 100%;
	list-style: none;
	margin-bottom: 0;
	font-size: 14px;
}
.dropdown-submenu:hover > .dropdown-menu {
	display: block;
}
ul.dropdown-menu.sub-menu {
	left: 100%;
	top: 47%;
}
/******** ================== Header Customization ================ ********/
.wb-header .logo a img {
 
    padding: 0 10px;
}
/* .logo_left .logo.logoTextSettingClass {	left: 0px; } */

.logo_left .logo {
	float: left;
	text-align: left;

}
.logo_left .navbar-default {
	float: right;
	margin-top: 1%;
}

 /* .logo_right .logo.logoTextSettingClass { 	right: 0px; } */

.logo_right .logo {
	float: right;
	text-align: right;
}
.logo_right .navbar-default {
	float: left;
	margin-top: 1%;
}
.logo_center .logo {	
	text-align: center;
	left: 0px;
	right: 0px;
	/*position: absolute; */
	top:auto !important; 
	transform: auto; 
	margin-top: 1.5%; 
}

.logo_center .logo {
	float: none !important;
	text-align:center;
}
.logo_center .logo img {
	max-width: 100%;
	text-align: center;
	display: block;
	margin: 0 auto !important;
	width: auto;
}

.logo-text-left span { float: left;}
.logo-text-right span { text-align: right;}
.logo-text-center {text-align:center !important;}
.logo-text-center span { display:block;}

.logo_center .container {
	width: 100%;
	padding: 0px;
}
/*.logo_center .navbar .nav.navbar-nav {
	float: none !important;
	display: inline-block;
	margin-top:30px;
}*/

.logo_center .navbar .nav.navbar-nav {
    float: none !important;
    display: inline-block;
    margin-top: 15px;
}


.logo_center .navbar .navbar-collapse {
	text-align: center;
}

.logo_center .logo-text-left a {display: inline-block;}

.logo_center .logo-text-left img{display: inline-block;}

.logo_center .logo-text-left span{display: inline-block; float:left;}


.logo_center .logo-text-right img{display: inline-block;}

.logo_center .logo-text-right span{display: inline-block; float:none;}

@media (max-width: 991px) {
.logo_right .logo {
    float: left;
    text-align: left;
}
.logo_right .navbar-default {
    float: right;
}
}

/*******
.box-layout{    width: 1200px; margin: 0px auto;}
header.overlap  {    background: transparent; position: absolute; box-shadow:none;}
header.overlap_fixed  {    position: fixed; }********/
/******** ================== Header Customization End ================ ********/


/*=======Testimonial Ends======*/

/*=======FORM-1======*/

.cart-caption {
}
.cart-caption h3 {
	border-bottom: 1px solid #ccc !important;
	padding-bottom: 10px !important;
}
.full-width {
	width: 100%;
}
.currency-select select option {
	background: transparent;
}
.add-top-2x {
	margin-top: 15px
}
.cart-caption label {
	display: block;
	font-size: 12px;
	color: #000 !important;
	margin-bottom: 0px;
	font-weight: 100;
	font-family: Arial, Helvetica, sans-serif;
}
.cart-caption input, .cart-caption select {
	width: 110px !important;
	border: 1px solid #ddd !important;
	background-color: #fff !important;
	color: black !important;
}
.cart-caption input:focus, .cart-caption select:focus {
	width: 110px !important;
	border: 1px solid #ddd !important;
	background-color: #fff !important;
	color: black !important;
}
ul#productOptions {
	padding-left: 0px;
}
::-webkit-input-placeholder {
 color: black;
}
.testimonialStyle1 {
	background: #f4f4f4;
	padding: 20px;
	margin: 10px;
	float: left;
}
.testimonialStyle1 .image-box {
	float: left;
}
.testimonialStyle1 .image-box img {
	width: 82px;
	height: 82px;
}
.add-top {
	margin-top: 20px;
}
.add-top-xl {
	margin-top: 50px;
}
.testimonialStyle2 {
	background: #f4f4f4;
	margin: 20px 0;
	padding: 10px;
}
.testimonialStyle2 img {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	display: block;
}
.testimonialStyle2 span.fa {
	margin-right: 10px;
}
.testimonialStyle3 {
}
.testimonialStyle3 .image-box {
	/*float: left;*/
	padding: 0;
	/*background: #f4f4f4;*/
}
.testimonialStyle3 .content-box {
	padding: 0;
}
.testimonialStyle3 .image-box img {
	width: 100%;
	height: 100%;
	border-radius: 0;
}
.testimonialStyle4 img {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	display: block;
}
.testimonialStyle5 {
	background: #f4f4f4;
	padding: 10px;
	position: relative;
	width: 85%;
	margin: 0px auto 20px auto;
}
.testimonialStyle5 img {
	width: 80px;
	height: 80px;
	margin: 0;
	display: block;
	padding: 0;
}
.testimonialStyle5 .image-box {
	position: absolute;
	left: -5%;
	margin-top: -50px;
	top: 50%;
	background: #A0A0A0;
	width: 100px;
	padding: 10px;
	height: 100px;
}
.testimonialStyle5 .content-box {
	padding-left: 70px;
	width: 100%;
	padding-right: 70px;
}
.faqs {
	margin: 0;
	padding: 0;
}
.faqs h1 {
	font-size: 36px;
}
.faqs h1 {
	font-size: 36px;
}
/******** ========================== Navigation Effects =========================== ********/
/* Effect 1: Brackets */
.cl-effect-1 a::before, .cl-effect-1 a::after {
	display: inline-block;
	opacity: 0;
	-webkit-transition: -webkit-transform 0.3s, opacity 0.2s;
	-moz-transition: -moz-transform 0.3s, opacity 0.2s;
	transition: transform 0.3s, opacity 0.2s;
 	color:#000;
}
.cl-effect-1 a::before {
	margin-right: 10px;
	content: '[';
	-webkit-transform: translateX(20px);
	-moz-transform: translateX(20px);
	transform: translateX(20px);
}
.cl-effect-1 a::after {
	margin-left: 10px;
	content: ']';
	-webkit-transform: translateX(-20px);
	-moz-transform: translateX(-20px);
	transform: translateX(-20px);
}
.cl-effect-1 a:hover::before, .cl-effect-1 a:hover::after, .cl-effect-1 a:focus::before, .cl-effect-1 a:focus::after {
	opacity: 1;
	-webkit-transform: translateX(0px);
	-moz-transform: translateX(0px);
	transform: translateX(0px);
}
/* Effect 3: bottom line slides/fades in */
.cl-effect-3 a {
	padding: 15px!important
}
.cl-effect-3 a::after {
	position: absolute;
	top: 100%;
	left: 0;
	width: 100%;
	height: 4px;
 	background: #000;
	content: '';
	opacity: 0;
	-webkit-transition: opacity 0.3s, -webkit-transform 0.3s;
	-moz-transition: opacity 0.3s, -moz-transform 0.3s;
	transition: opacity 0.3s, transform 0.3s;
	-webkit-transform: translateY(10px);
	-moz-transform: translateY(10px);
	transform: translateY(10px);
}
.cl-effect-3 a:hover::after, .cl-effect-3 a:focus::after {
	opacity: 1;
	-webkit-transform: translateY(0px);
	-moz-transform: translateY(0px);
	transform: translateY(0px);
}
/* Effect 4: bottom border enlarge */
.cl-effect-4 a {
	padding: 10px !important
}
.cl-effect-4 a::after {
	position: absolute;
	top: 100%;
	left: 0;
	width: 100%;
	height: 1px;
    background: #000;
	content: '';
	opacity: 0;
	-webkit-transition: height 0.3s, opacity 0.3s, -webkit-transform 0.3s;
	-moz-transition: height 0.3s, opacity 0.3s, -moz-transform 0.3s;
	transition: height 0.3s, opacity 0.3s, transform 0.3s;
	-webkit-transform: translateY(-10px);
	-moz-transform: translateY(-10px);
	transform: translateY(-10px);
}
.cl-effect-4 a:hover::after, .cl-effect-4 a:focus::after {
	height: 5px;
	opacity: 1;
	-webkit-transform: translateY(0px);
	-moz-transform: translateY(0px);
	transform: translateY(0px);
}
/* Effect 5: same word slide in and border bottom */
.cl-effect-6 a {
	margin: 0 10px;
	padding: 15px !important;
}
.cl-effect-6 a::before {
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 2px;
	background: #000;
	content: '';
	-webkit-transition: top 0.3s;
	-moz-transition: top 0.3s;
	transition: top 0.3s;
}
.cl-effect-6 a::after {
	position: absolute;
	top: 0;
	left: 0;
	width: 2px;
	height: 2px;
 	background: #000;
	content: '';
	-webkit-transition: height 0.3s;
	-moz-transition: height 0.3s;
	transition: height 0.3s;
}
.cl-effect-6 a:hover::before {
	top: 100%;
	opacity: 1;
}
.cl-effect-6 a:hover::after {
	height: 100%;
}
/* Effect 7: second border slides up */
.cl-effect-7 a {
	padding: 12px 10px 10px!important;
	text-shadow: none;
}
.cl-effect-7 a::before, .cl-effect-7 a::after {
	position: absolute;
	top: 100%;
	left: 0;
	width: 100%;
	height: 3px;
 	background: #000;
	content: '';
	-webkit-transition: -webkit-transform 0.3s;
	-moz-transition: -moz-transform 0.3s;
	transition: transform 0.3s;
	-webkit-transform: scale(0.85);
	-moz-transform: scale(0.85);
	transform: scale(0.85);
}
.cl-effect-7 a::after {
	opacity: 0;
	-webkit-transition: top 0.3s, opacity 0.3s, -webkit-transform 0.3s;
	-moz-transition: top 0.3s, opacity 0.3s, -moz-transform 0.3s;
	transition: top 0.3s, opacity 0.3s, transform 0.3s;
}
.cl-effect-7 a:hover::before, .cl-effect-7 a:hover::after, .cl-effect-7 a:focus::before, .cl-effect-7 a:focus::after {
	-webkit-transform: scale(1);
	-moz-transform: scale(1);
	transform: scale(1);
}
.cl-effect-7 a:hover::after, .cl-effect-7 a:focus::after {
	top: 0%;
	opacity: 1;
}
/* Effect 8: border slight translate */
.cl-effect-8 a {
	padding: 10px 20px!important;
}
.cl-effect-8 a::before, .cl-effect-8 a::after {
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
 	border: 3px solid #000;
	content: '';
	-webkit-transition: -webkit-transform 0.3s, opacity 0.3s;
	-moz-transition: -moz-transform 0.3s, opacity 0.3s;
	transition: transform 0.3s, opacity 0.3s;
}
.cl-effect-8 a::after {
 	border-color: #000;
	opacity: 0;
	-webkit-transform: translateY(-7px) translateX(6px);
	-moz-transform: translateY(-7px) translateX(6px);
	transform: translateY(-7px) translateX(6px);
}
.cl-effect-8 a:hover::before, .cl-effect-8 a:focus::before {
	opacity: 0;
	-webkit-transform: translateY(5px) translateX(-5px);
	-moz-transform: translateY(5px) translateX(-5px);
	transform: translateY(5px) translateX(-5px);
}
.cl-effect-8 a:hover::after, .cl-effect-8 a:focus::after {
	opacity: 1;
	-webkit-transform: translateY(0px) translateX(0px);
	-moz-transform: translateY(0px) translateX(0px);
	transform: translateY(0px) translateX(0px);
}
.cl-effect-12 a {
	padding-top: 15px!important;
	padding-bottom: 15px!important;
}
/* Effect 12: circle */
.cl-effect-12 a::before, .cl-effect-12 a::after {
	position: absolute;
	top: 50%;
	left: 50%;
	width: 100px;
	height: 100px;
 	border: 2px solid #000;
	border-radius: 50%;
	content: '';
	opacity: 0;
	-webkit-transition: -webkit-transform 0.3s, opacity 0.3s;
	-moz-transition: -moz-transform 0.3s, opacity 0.3s;
	transition: transform 0.3s, opacity 0.3s;
	-webkit-transform: translateX(-50%) translateY(-50%) scale(0.2);
	-moz-transform: translateX(-50%) translateY(-50%) scale(0.2);
	transform: translateX(-50%) translateY(-50%) scale(0.2);
}
.cl-effect-12 a::after {
	width: 90px;
	height: 90px;
	border-width: 6px;
	-webkit-transform: translateX(-50%) translateY(-50%) scale(0.8);
	-moz-transform: translateX(-50%) translateY(-50%) scale(0.8);
	transform: translateX(-50%) translateY(-50%) scale(0.8);
}
.cl-effect-12 a:hover::before, .cl-effect-12 a:hover::after, .cl-effect-12 a:focus::before, .cl-effect-12 a:focus::after {
	opacity: 1;
	-webkit-transform: translateX(-50%) translateY(-50%) scale(1);
	-moz-transform: translateX(-50%) translateY(-50%) scale(1);
	transform: translateX(-50%) translateY(-50%) scale(1);
}
/* Effect 13: three circles */
.cl-effect-13 a {
	-webkit-transition: color 0.3s;
	-moz-transition: color 0.3s;
	transition: color 0.3s;
}
.cl-effect-13 a::before {
	position: absolute;
	top: 100%;
	left: 50%;
	color: transparent;
	content: "\2022";
	text-shadow: 0 0 transparent;
	font-size: 1.2em;
	-webkit-transition: text-shadow 0.3s, color 0.3s;
	-moz-transition: text-shadow 0.3s, color 0.3s;
	transition: text-shadow 0.3s, color 0.3s;
	-webkit-transform: translateX(-50%);
	-moz-transform: translateX(-50%);
	transform: translateX(-50%);
	pointer-events: none;
}
.cl-effect-13 a:hover::before, .cl-effect-13 a:focus::before {
 color: #000;
 text-shadow: 10px 0 #000, -10px 0 #000;
}
.cl-effect-13 a:hover, .cl-effect-13 a:focus {
}
/* Effect 14: border switch */
.cl-effect-14 a {
	padding: 0 20px!important;
	height: 45px;
	line-height: 45px!important;
}
.cl-effect-14 a::before, .cl-effect-14 a::after {
	position: absolute;
	width: 45px;
	height: 2px;
    background: #000;
	content: '';
	opacity: 0.2;
	-webkit-transition: all 0.3s;
	-moz-transition: all 0.3s;
	transition: all 0.3s;
	pointer-events: none;
}
.cl-effect-14 a::before {
	top: 0;
	left: 0;
	-webkit-transform: rotate(90deg);
	-moz-transform: rotate(90deg);
	transform: rotate(90deg);
	-webkit-transform-origin: 0 0;
	-moz-transform-origin: 0 0;
	transform-origin: 0 0;
}
.cl-effect-14 a::after {
	right: 0;
	bottom: 0;
	-webkit-transform: rotate(90deg);
	-moz-transform: rotate(90deg);
	transform: rotate(90deg);
	-webkit-transform-origin: 100% 0;
	-moz-transform-origin: 100% 0;
	transform-origin: 100% 0;
}
.cl-effect-14 a:hover::before, .cl-effect-14 a:hover::after, .cl-effect-14 a:focus::before, .cl-effect-14 a:focus::after {
	opacity: 1;
}
.cl-effect-14 a:hover::before, .cl-effect-14 a:focus::before {
	left: 50%;
	-webkit-transform: rotate(0deg) translateX(-50%);
	-moz-transform: rotate(0deg) translateX(-50%);
	transform: rotate(0deg) translateX(-50%);
}
.cl-effect-14 a:hover::after, .cl-effect-14 a:focus::after {
	right: 50%;
	-webkit-transform: rotate(0deg) translateX(50%);
	-moz-transform: rotate(0deg) translateX(50%);
	transform: rotate(0deg) translateX(50%);
}
/* Effect 21: borders slight translate */
.cl-effect-21 a {
	padding: 12px!important;
	text-shadow: none;
	-webkit-transition: color 0.3s;
	-moz-transition: color 0.3s;
	transition: color 0.3s;
}
.cl-effect-21 a::before, .cl-effect-21 a::after {
	position: absolute;
	left: 0;
	width: 100%;
	height: 2px;
    background: #000;
	content: '';
	opacity: 0;
	-webkit-transition: opacity 0.3s, -webkit-transform 0.3s;
	-moz-transition: opacity 0.3s, -moz-transform 0.3s;
	transition: opacity 0.3s, transform 0.3s;
	-webkit-transform: translateY(-10px);
	-moz-transform: translateY(-10px);
	transform: translateY(-10px);
}
.cl-effect-21 a::before {
	top: 0;
	-webkit-transform: translateY(-10px);
	-moz-transform: translateY(-10px);
	transform: translateY(-10px);
}
.cl-effect-21 a::after {
	bottom: 0;
	-webkit-transform: translateY(10px);
	-moz-transform: translateY(10px);
	transform: translateY(10px);
}
.cl-effect-21 a:hover, .cl-effect-21 a:focus {
}
.cl-effect-21 a:hover::before, .cl-effect-21 a:focus::before, .cl-effect-21 a:hover::after, .cl-effect-21 a:focus::after {
	opacity: 1;
	-webkit-transform: translateY(0px);
	-moz-transform: translateY(0px);
	transform: translateY(0px);
}
.cl-effect-22 a {
	padding: 12px!important;
}
.cl-effect-22 a:before {
	content: '';
	display: block;
	position: absolute;
	height: 3px;
	background-color:#000;
	bottom: 6px;
	left: 0;
	width: 100%;
	-webkit-transform: scaleX(0);
	-ms-transform: scaleX(0);
	transform: scaleX(0);
	-webkit-transition: all .3s ease;
	transition: all .3s ease;
}
.cl-effect-22 a:hover:before {
	-webkit-transform: scaleX(1);
	-ms-transform: scaleX(1);
	transform: scaleX(1);
}
.cl-effect-23 a {
}
.cl-effect-23 a:hover {
	transform: scale(1.4);
}
.cl-effect-custom-1 a::after {
	display: block;
	position: absolute;
	left: 0;
	bottom: 5px;
	width: 0;
	height: 2px;
	background-color: #000;
	content: "";
	-webkit-transition: all 0.2s;
	-moz-transition: all 0.2s;
	-o-transition: all 0.2s;
	transition: all 0.2s;
}
.cl-effect-100 a {
	height: 100%;
}
.cl-effect-100 a:after {
	content: '';
	position: absolute;
	top: 0%;
	left: 0;
	background: transparent;
	border: 3px double transparent;
	width: 100%;
	padding: 11px;
	transition: all 0.5s ease;
}
.cl-effect-100 a:hover:after, .cl-effect-custom-2 a:focus:after {
	content: '';
	position: absolute;
	top: 0%;
	left: 0;
	background: transparent;
	border:3px double #000;
	width: 100%;
	padding: 11px;
	transition: all 0.5s ease;
}
/******** ========================== Navigation Effects =========================== ********/

/******** ========================== Blog Effects =========================== ********/

.blog-post-container {
	border-bottom: 1px solid #ededed;
	margin-bottom: 3.9em;
	padding-bottom: 1.9em;
	float: left;
	width: 100%;
}
.post-image {
	float: left;
	width: 100%;
}
.post-image img {
	background: #41352e none repeat scroll 0 0;
	border: 9px solid #ededed;
	cursor: pointer;
	float: left;
	height: auto;
	max-height: 100%;
	min-width: 100%;
	overflow: hidden;
	text-align: center;
}
.post-image > img {
	backface-visibility: hidden;
	display: block;
	min-height: 100%;
	opacity: 1;
	transition: opacity 1s ease 0s, transform 1s ease 0s;
}
.post-image img:hover {
	opacity: 0.48;
	transform: scale3d(1.02, 1.02, 1.02);
}
.post-image img, .post-image > img {
	max-width: 100%;
	position: relative;
	width: 100%;
}
.sidebar-catagory {
}
.sidebar-catagory h1, .sidebar-catagory h2, .sidebar-catagory h3, .sidebar-catagory h4, .sidebar-catagory h5, .sidebar-catagory h6 {
	margin-bottom: 15px;
	border-bottom: 1px solid #ededed;
	padding-bottom: 15px;
	font-weight: 400;
	color: #41352e;
}
.sidebar-catagory ul {
	margin: 0;
	padding: 0;
}
.sidebar-catagory ul li {
	list-style: none;
	display: block;
}
.sidebar-catagory p {
	font-weight: normal;
	margin-bottom: 15px;
}
.tag-widget a {
	background-color: #fff;
	border: 1px solid #d7d7d7;
	border-radius: 2px;
	line-height: 1;
	display: inline-block;
	padding: 7px 13px;
	margin: 0 7px 7px 0;
}
/******** ========================== Blog Effects End =========================== ********/


.faqs h2 {
	font-size: 30px;
}
.faqs h3 {
	font-size: 24px;
}
.faqs h4 {
	font-size: 18px;
}
.faqs h5 {
	font-size: 14px;
}
.faqs h6 {
	font-size: 12px;
}
.widgetBg {
	background: #000;
	padding: 100px 0;
}
.widgetBg h3 {
	color: #fff;
	text-align: left;
}
.widgetBg p {
	font-size: 14px;
	text-align: left;
	margin-bottom: 0;
	font-weight: normal;
	font-family: 'Open Sans', sans-serif;
}
.text-center {
	text-align: center !important;
}
.caption-image {
}
.caption-image img {
	width: 100%;
	height: 100%;
}
.caption-text {
	color: #000;
	text-align: center;
}
.caption-text h1 {
	font-size: 24px;
	color: #000;
	margin-top: 0;
	margin-bottom: 0;
}
.caption-text h1, .caption-text h2, .caption-text h3, .caption-text h4, .caption-text h5, .caption-text h6, .caption-text p {
	color: #000;
	text-align: center;
}
.caption-text p {
	padding-bottom: 15px;
	text-align: center;
}
.team-member {
	padding: 0!important;
}
.team-member img {
	width: 100%;
}
.widgetBlock1.slider {
	width: 100%;
	position: relative;
	padding: 0;
}
.widgetBlock1.slider h1 {
	font-size: 45px;
	text-shadow: 1px 2px 3px rgba(0, 0, 0, 0.31);
	-webkit-text-shadow: 1px 2px 3px rgba(0, 0, 0, 0.31);
	-moz-text-shadow: 1px 2px 3px rgba(0, 0, 0, 0.31);
	-o-text-shadow: 1px 2px 3px rgba(0, 0, 0, 0.31);
}
.widgetBlock1.slider h5 {
	font-size: 20px;
	text-align: center;
}
.widgetBlock1 .heroHeading1 {
	position: absolute;
	width: 100%;
	top: 30%;
	padding: 20px;
	right: 0%;
	background-color: rgba(0,0,0,0.7);
}
.widgetBlock1.slider img {
	width: 100%;
	float: left;
}
.widgetBg1 h2, .widgetBg1 h3 {
	color: #fff !important;
}
;
.single-slider {
	width: 100%;

	position: relative;
	padding: 0;
	margin-top: -1px;
}
.single-slider .heroHeading h1 {
	font-size: 100px !important;
	color: #fff !important;
	text-align: center !important;
	display: block !important;
	font-weight: bold;
	margin-bottom: 30px;
	margin-top: 30px;
}
.single-slider .heroHeading h2 {
	font-size: 30px !important;
	text-align: center !important;
	color: #fff !important;
	text-transform: uppercase;
}
.single-slider .heroHeading p {
	color: #fff !important;
	line-height: 30px;
	font-size: 18px !important;
	text-align: center !important;
	margin-top: 10px;
}
.single-slider .heroHeading {
	position: absolute;
	width: 100% !important;
	top: 18% !important;
	left: 0 !important;
}
.single-slider img {
	width: 100%;
	float: left;
}
.widgetBg1 h2, .widgetBg1 h3 {
	color: #fff !important;
}
ul.client-logo-gallery {
	margin: 20px auto 0 auto;
	display: block;
	text-align: center;
	width: 100%;
	padding: 0;
}
ul.client-logo-gallery li {
	display: inline-block;
	margin-right: 60px;
	margin-bottom: 20px;
	text-align: center;
	float: none !important;
}
input[type="submit"]:hover, input[type="reset"]:hover, input[type="button"]:hover {
	border: 1px solid 000!important;
}
.selectMenuStyle:hover {
background-color: #fff;
}
.productImage {
	max-height: 300px !important;
}
.VideoWidget>iframe, .VideoWidget>img {
	margin: auto;
	display: block;
}
.col-80-offset-dm {
	margin: 0 auto;
	width: 80%;
}
/******** =========================    Gallery Styles Start  ==================== ********/
/********==========================    UPDATE GALLERY STYLE  ==================== ********/

figure.effect-lily img {
	width: -webkit-calc(100% + 50px) !important;
    width: calc(100% + 50px) !important;
	height:360px;
}
figure.effect-sadie img {
	height:360px;
}
figure.effect-sadie figcaption::before {
	background: -webkit-linear-gradient(top,rgba(51,51,51,.2) 0,rgba(0,0,0,.4) 75%);
    background: linear-gradient(to bottom,rgba(51,51,51,.2) 0,rgba(0,0,0,.4) 75%);
}
figure.effect-honey img {
	height:360px;
}
figure.effect-honey p{text-align:left;}
figure.effect-layla img {
	height: 390px;
}
figure.effect-layla p, figure.effect-ruby p, figure.effect-bubba p, figure.effect-chico p, figure.effect-moses p, figure.effect-jazz p {
	font-size:12px !important;
}
figure.effect-oscar img {
	height: 360px;
}
figure.effect-oscar figcaption {
    background-color:transparent;
}
figure.effect-oscar:hover figcaption {
   /* background-color: rgba(0,0,0,0.7);*/
}
figure.effect-marley img {
    height: 360px;
}
figure.effect-ruby img {
	height: 414px;
}
figure.effect-roxy img {
	height: 360px;
	width: -webkit-calc(100% + 60px) !important;
    width: calc(100% + 60px) !important;
}
figure.effect-bubba img {
	height: 360px;
}
figure.effect-dexter img {
	height: 360px;
}
figure.effect-sarah img {
	height: 360px;
    width: -webkit-calc(100% + 20px)!important;
    width: calc(100% + 20px) !important;
}
figure.effect-chico img {
	height: 360px;
}
figure.effect-chico p {
	margin: 0 auto !important;
}
figure.effect-milo img {
	height: 360px;
    width: -webkit-calc(100% + 60px) !important;
    width: calc(100% + 60px) !important;
}
figure.effect-julia img {
	height: 400px;
}
.fullwidthGallery figure.effect-julia p {
	-webkit-transform: translate3d(-400px,0,0);
    transform: translate3d(-400px,0,0);
}
.fullwidthGallery figure.effect-julia:hover p {
    -webkit-transform: translate3d(0,0,0);
    transform: translate3d(0,0,0);
}
figure.effect-julia p{color:#000 !important;}
figure.effect-goliath img {
	height:360px;
}
figure.effect-selena img {
	height:360px;
}

figure.effect-apollo img {
	height: 360px;
}
figure.effect-apollo p {margin:30px !important;}
figure.effect-steve img {
	height:360px;
}
figure.effect-steve p {
	margin: 20px 0 0 0 !important;
    padding: 5px;
    font-size: 12px !important;
}
figure.effect-moses img {
	height: 360px;
}
figure.effect-jazz img {
	height: 360px;
}
figure.effect-ming img {
	height: 360px;
}
figure.effect-duke img {
	height: 360px;
}
figure.effect-duke p {
	margin:20px !important;
}
.grid .fullwidthGallery figure {margin:0;}
.grid figure img{}
figure.effect-steve h2, figure.effect-julia p{color: #000;}
figure.effect-steve h2, figure.effect-steve p {
    color: #000 !important;
}
.grid figure h2, .grid figure p {
	margin:0;
}
.grid figure h2 {
	font-weight: 600;
    color: #fff;
    font-size: 28px;
    line-height: normal;
    text-transform: capitalize;
}
.grid figure p {
	font-size: 14px;
    color: #fff;
    line-height: 1.5;
    text-transform: capitalize;
    font-weight: normal;
}
figure.effect-lily h2, figure.effect-lily p, figure.effect-roxy h2, figure.effect-roxy p, figure.effect-sarah h2, figure.effect-sarah p, figure.effect-goliath h2, figure.effect-goliath p, figure.effect-honey h2, figure.effect-honey p  {
	text-align:left !important;
}
figure.effect-sadie h2, figure.effect-sadie p, figure.effect-layla h2, figure.effect-layla p, figure.effect-oscar h2, figure.effect-oscar p, figure.effect-ruby h2, figure.effect-ruby p, figure.effect-bubba h2, figure.effect-bubba p, figure.effect-chico h2, figure.effect-chico p, figure.effect-selena h2, figure.effect-selena p, figure.effect-jazz h2, figure.effect-jazz p, figure.effect-ming h2, figure.effect-ming p, figure.effect-duke h2, figure.effect-duke p {
	text-align:center !important;
}
figure.effect-marley h2, figure.effect-marley p {
	text-align:right !important;
}
figure.effect-ruby p{margin-top:20px;padding:15px;}
/********==========================    UPDATE GALLERY STYLE  ==================== ********/
figure.effect-ming img {
	/*height: 240px;*/
}
figure.effect-ming:hover img, figure.effect-layla:hover img, figure.effect-milo:hover img, figure.effect-zoe:hover img, figure.effect-sarah:hover img, figure.effect-jazz:hover img, figure.effect-oscar:hover img, figure.effect-marley:hover img, figure.effect-apollo:hover img, figure.effect-selena:hover img, figure.effect-goliath:hover img, figure.effect-dexter:hover img, figure.effect-bubba:hover img, figure.effect-steve:hover img, figure.effect-moses:hover img, figure.effect-duke:hover img, figure.effect-sadie:hover img, figure.effect-honey:hover img, figure.effect-chico:hover img, figure.effect-lexi:hover img, figure.effect-lily:hover img, figure.effect-ruby:hover img, figure.effect-ruby:hover img, figure.effect-roxy:hover img {
	opacity: .5!important;
}
figure.effect-layla img, figure.effect-milo img {
	/*height: 270px;*/
}
figure.effect-zoe {
	/*height: 266px;*/
}
figure.effect-sarah img {
	/*height: 228.8px;*/
}
figure.effect-jazz img {
	/*height: 227px;*/
}
figure.effect-oscar img {
	/*height: 380px;*/
}
figure.effect-marley img {
	/*height: 300px;*/
}
figure.effect-apollo img {
	/*height: 259px;*/
}
figure.effect-selena img {/*height: 206px;*/}
figure.effect-goliath img {/*height: 227.14px;*/}
figure.effect-dexter img, figure.effect-bubba img, figure.effect-steve img, figure.effect-moses img, figure.effect-duke img, figure.effect-sadie img, figure.effect-honey img {/*height: 360px;*/}
figure.effect-chico img {/*height: 403.2px;*/}
figure.effect-lexi img {/*height: 267.5px;*/}
figure.effect-lily img {/*height: 397.5px;width: -webkit-calc(100% + 50px) !important;
width: calc(100% + 50px) !important;*/}
figure.effect-ruby img {/*height: 414px;*/}
figure.effect-roxy img {/*height: 405px;*/}
.grid figure {background: #000 !important;}
ul.imgs-gallery {float: none;margin: 20px auto 0;width: 1170px;padding: 0;display: table;}
/*ul.imgs-gallery li {display: inline-block;float: left;margin-right: 10px;width: 380px;}*/
.grid {float: none !important;}
.grid:before, .grid:after {display: table;content: " "}
.grid:after {clear: both;}
ul.imgs-gallery li {
    display: inline-block;
    width: 380px;
    margin: 5px !important;
    float: none;
}
/******** =========================  Gallery Styles End ==================== ********/

/*=======Image Gallery======*/
ul.imageListsWidget li figure figcaption p:empty {
	display: none !important;
}
/*=======Image Gallery======*/

@media only screen and (min-width:1024px) {
    
ul.imgs-gallery li {
    width: 31%;
    margin: 5px !important;
    float: none;
    display: inline-block;
}

ul.imgs-gallery {
    width: 100%;
    padding: 0;
	display:block;

}

}
@media only screen and (min-width: 768px) and (max-width: 1023px) {
    
ul.imgs-gallery li {
	width: 48%;
}
ul.imgs-gallery {
	width: 100%;
	padding: 0;
}
    
}
@media only screen and (max-width:640px) {
 
 	ul.imgs-gallery, ul.imgs-gallery li {
	width: 100%;
}
 
 }
 @media only screen and (max-width: 480px) {
     
    ul.imgs-gallery li {
	width:100%;
}
	ul.imgs-gallery {
	width: 100%;
}

}
@media only screen and (max-width:403px) {
    
    ul.imgs-gallery li{width:100%;}
	ul.imgs-gallery {width: 100%;}

}@media only screen and (max-width:1040px) {
/******** ========================= Tempalte Slider_heroHeading CSS Start ==================== ********/
/*
section.slider .heroHeading h1 {font-size: 36px;}
section.slider .heroHeading h2 {font-size: 30px;}
section.slider .heroHeading h3 {font-size: 24px;}
section.slider .heroHeading h4 {font-size: 20px;}
section.slider .heroHeading h5 {font-size: 18px;}
section.slider .heroHeading h6 {font-size: 16px;}
section.slider .heroHeading p {font-size: 14px;}
section.slider .heroHeading .theme-button, section.slider .heroHeading .theme-button-second {padding: 14px 28px;
font-size: 14px;margin-top: 0;}
*/
/******** ========================= Tempalte Slider_heroHeading CSS End ==================== ********/
 .embed-container {
 padding-bottom: 23.25%;
}
.carousel-inner > .item > img {
	height: 500px;
	width: 100%;
}
.carousel .item {
	height: 500px;
}
.carousel {
	height: 500px;
}
.carousel-caption h1 {
	font-size: 30px;
	line-height: 30px;
}
.carousel-caption p {
	font-size: 14px;
	line-height: normal;
}
.carousel-caption {
	bottom: 150px;
}
}
@media only screen and (min-width: 768px) and (max-width: 1023px) {
/******** ========================= Tempalte Slider_heroHeading CSS Start ==================== ********/

/*section.slider .heroHeading h1 {font-size: 30px;}
section.slider .heroHeading h2 {font-size: 24px;}
section.slider .heroHeading h3 {font-size: 20px;}
section.slider .heroHeading h4 {font-size: 18px;}
section.slider .heroHeading h5 {font-size: 16px;}
section.slider .heroHeading h6 {font-size: 14px;}
section.slider .heroHeading p {font-size: 14px;}
section.slider .heroHeading .theme-button, section.slider .heroHeading .theme-button-second {padding: 10px 20px;
font-size: 14px;margin-top: 0;}*/

/******** ========================= Tempalte Slider_heroHeading CSS End ==================== ********/
.testimonialStyle5 .image-box {
	left: 50%;
	margin-left: -35px;
	margin-top: 0;
	top: -50px;
	width: 100px;
	height: 100px;
}
.testimonialStyle5 img {
	width: 80px;
	height: 80px;
}
.testimonialStyle5 .content-box {
	padding-left: 0px;
	padding-right: 0px;
	padding-top: 50px;
}
.testimonialStyle5 .content-box p {
	text-align: center;
}
.carousel-inner > .item > img {
	height: 400px;
}
.carousel .item {
	height: 400px;
}
.carousel {
	height: 400px;
}
.carousel-caption h1 {
	font-size: 30px;
	line-height: 30px;
}
.carousel-caption p {
	font-size: 14px;
	line-height: normal;
}
.carousel-caption {
	bottom: 100px;
}
}

@media only screen and (max-width:960px) {
.embed-container {
	padding-bottom: 30.25%;
}
}

@media only screen and (max-width:640px) {
 .embed-container {
    padding-bottom: 50.25%;
  }
  .carousel-inner > .item > img {
	height: 300px;
	width: 100%;
}
.carousel .item {
	height: 300px;
}
.carousel {
	height: 300px;
}
.carousel-caption h1 {
	font-size: 20px;
	line-height: 20px;
}
.carousel-caption p {
	font-size: 12px;
	line-height: normal;
	text-shadow: none;
}
.carousel-caption {
    bottom: 60px;
}
}

/*@media only screen and (max-width: 480px) {


.testimonialStyle5 .image-box {
	left: 50%;
	top: 0;
	width: 100px;
	height: 100px;
	margin-left: -40px;
}
.carousel {
	height: 300px;
}
.carousel-caption h1 {
	font-size: 20px;
	line-height: 20px;
}
.carousel-caption p {
	font-size: 12px;
	line-height: normal;
	text-shadow: none;
}
.carousel-caption {
	bottom: 60px;
}

}
*/
@media only screen and (max-width: 480px) {
/******** ========================= Tempalte Slider_heroHeading CSS Start ==================== ********/
/*
section.slider .heroHeading h1 {font-size: 24px;}
section.slider .heroHeading h2 {font-size: 20px;}
section.slider .heroHeading h3 {font-size: 18px;}
section.slider .heroHeading h4 {font-size: 16px;}
section.slider .heroHeading h5 {font-size: 14px;}
section.slider .heroHeading h6 {font-size: 12px;}
section.slider .heroHeading p {font-size: 12px;}
section.slider .heroHeading .theme-button, section.slider .heroHeading .theme-button-second {
	font-size: 8px;
	margin-top: 0;
    padding: 7px 10px;
}*/
/******** ========================= Tempalte Slider_heroHeading CSS End ==================== ********/
.testimonialStyle5 .image-box {
	left: 50%;
    top: 0;
    width: 100px;
    height: 100px;
    margin-left: -40px;
}
.testimonialStyle5 img {
	width:80px;
	height:80px;
}
.testimonialStyle5 .content-box {
	padding:50px 0 0 0;
}
.testimonialStyle5 .content-box p{
	text-align:center;
}
.testimonialStyle3 .image-box {
	margin: 0px auto;
	float: none;
	width: 200px;
}
.carousel-inner > .item > img {
	height: 200px;
}
.carousel .item {
	height: 200px;
}
.carousel {
	height: 200px;
}
.carousel-caption h1 {
	font-size: 20px;
	line-height: 20px;
}
.carousel-caption p {
	font-size: 12px;
	line-height: normal;
	text-shadow: none;
}
.carousel-caption {
	bottom: 0;
	padding-bottom: 30px;
}
}
@media only screen and (max-width:403px) {
/******** ========================= Tempalte Slider_heroHeading CSS Start ==================== ********/

section.heroSlider {
	min-height: auto;
}
section.heroSlider .heroHeading h1, section.heroSlider .heroHeading h2, section.heroSlider .heroHeading h3, section.heroSlider .heroHeading h4, section.heroSlider .heroHeading h5, section.heroSlider .heroHeading h6, section.heroSlider .heroHeading p {
	margin: 5px 0;
	padding: 0;
	line-height: normal;
}
/*
section.slider .heroHeading h1 {font-size: 20px;}
section.slider .heroHeading h2 {font-size: 18px;}
section.slider .heroHeading h3 {font-size: 18px;}
section.slider .heroHeading h4 {font-size: 16px;}
section.slider .heroHeading h5 {font-size: 16px;}
section.slider .heroHeading h6 {font-size: 12px;}
section.slider .heroHeading p {font-size: 12px;}
*/
/*
section.slider .heroHeading .theme-button, section.slider .heroHeading .theme-button-second {
	font-size: 8px;
	margin-top: 0;
    padding: 7px 10px;
}*/

.carousel {
	height: 200px;
}
.carousel-caption h1 {
	font-size: 20px;
	line-height: 20px;
}
.carousel-caption p {
	font-size: 12px;
	line-height: normal;
	text-shadow: none;
}
.carousel-caption {
	bottom: 0;
	padding-bottom: 30px;
}
}

@media only screen and (max-width:403px) {
  .embed-container {
    padding-bottom: 80.25%;
  }
}


::-moz-placeholder {
    color: #a9a9a9 !important;
}
::-webkit-input-placeholder{
    color: #a9a9a9 !important;
}
:-moz-placeholder {
    color: #a9a9a9 !important;
}
:-ms-input-placeholder{
    color: #a9a9a9 !important;
}

.widget-section-17-1 ::-moz-placeholder, .widget-section-12-1 ::-moz-placeholder{
    color: white !important;
}
.widget-section-17-1 ::-webkit-input-placeholder, .widget-section-12-1 ::-webkit-input-placeholder {
    color: white !important;
}
.widget-section-17-1 :-moz-placeholder, .widget-section-12-1 :-moz-placeholder{
    color: white !important;
}
.widget-section-17-1 :-ms-input-placeholder, .widget-section-12-1 :-ms-input-placeholder{
    color: white !important;
}

.widget-section-17-1 ::-moz-placeholder ,.widget-section-12-1 ::-moz-placeholder,
.widget-section-17-1 ::-webkit-input-placeholder ,.widget-section-12-1 ::-webkit-input-placeholder,
.widget-section-17-1 :-moz-placeholder ,.widget-section-12-1 :-moz-placeholder,
.widget-section-17-1 :-ms-input-placeholder ,.widget-section-12-1 :-ms-input-placeholder{
    color: white !important;
}
/*-------------------------------------------------------------------------
SHAPES END
-------------------------------------------------------------------------*/

.CalenderWidget {
	text-align: center;
}
/* PRODUCT-DETAIL */
.widget-modal-dialog h4 {
	text-align: left;
}
.widget-modal-dialog label {
	display: inline-block;
	margin: 0 !important;
}
.widget-modal-dialog .modal-productImage {
	max-width: 200px;
	margin-left: auto;
	margin-right: auto;
}
.widget-modal-dialog .modal-product-detail-quantity {
	margin-bottom: 5px !important;
	font-weight: 700 !important;
	text-transform: uppercase;
}
.widget-modal-dialog input[type="text"].modal-product-quantity-input:focus, .widget-modal-dialog input[type="text"].modal-product-quantity-input {
	width: 35px!important;
	padding: 0 !important;
	text-align: center !important;
	display: inline-block;
	margin-left: 10px !important;
}
.widget-modal-dialog .modal-header {
	background-color: transparent !important;
}
.widget-modal-dialog .modal-header .close span {
	color: #333 !important;
}
/*lightbox caption background color*/
.lb-dataContainer {
	background: #646060;
}
html {
	height: 100%;
}
body {
	/*position: relative;*/
	min-height: 100%;
}
/* this should be a class*/
/*.dm-sticky-footer {
	position: absolute;
	right: 0;
	bottom: 0;
	left: 0;
}*/

.ecommerceWidget{
    margin-top:40px;
}
img.scale-with-grid {
    max-width: 100%;
    height: auto;
    /* width:auto; */
}



/*.header-image-text {
    position:absolute;
    top: 550px;
}*/

header.fixedHeader .header-image-text {
    display:none
}

.header-image-text {
    max-width:760px;
    width:100%;
    position: relative;
    left: auto;
    right: auto;
    top:auto;
    bottom: auto;
    margin: 0px auto;
}

.header-image-text .carousel-caption {
    position: inherit !important;
    top: auto;
    left: auto;
    bottom: auto;
    right: auto;
}
/*** headerImage Style CSS Start ***/
.header-image-text.headerStyle1 {
    border: 3px double rgba(255,255,255,0.3);
    top: 10%;
    max-width: 600px;
}

.header-image-text.headerStyle2 {position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);bottom: auto;text-align: center;}

.header-image-text.headerStyle2 * {
    color: #fff;
}

.header-image-text.headerStyle2 h4 {
    font-size: 20px;
    font-weight: 100;
    color: #fff;
    line-height: 1.5;
    margin-top: 0;
    margin-bottom: 10px;
}

.header-image-text.headerStyle2 h1 {
    font-size: 60px;
    line-height: 1.1;
    color: #fff;
    margin-top: 0;
    margin-bottom: 10px;
}

.header-image-text.headerStyle2  ul {
    list-style: none;
    padding: 0;
    margin: 0 auto;
    text-align: center;
    display: inline-block;
}

.header-image-text.headerStyle2 ul li {
    display: block;
    float: left;
    position: relative;
    margin-right: 30px;
    font-size: 20px;
    color: #ffffff;
    font-family: 'Poppins', sans-serif;
    font-weight: 600;
}

.header-image-text.headerStyle2 ul li:after {
    content: '';
    width: 10px;
    height: 10px;
    background-color: #000;
    border-radius: 100px;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    margin-left: 10px;
}

.header-image-text.headerStyle2 .theme-button {
    margin-right: 15px;
}

/*** headerImage Style CSS End ***/
.ContactFormWidget input[type="text"], .ContactFormWidget input[type="password"], .ContactFormWidget input[type="email"], .ContactFormWidget  textarea, .ContactFormWidget  select {	
	font-family: FontAwesome , 'Raleway', "Helvetica Neue", Helvetica, Arial, sans-serif !important;
}

.svgLayerClass{
	fill:#000;
}
/*
.logoWidget {    position: absolute;
	top: 50%;
	transform: translateY(-50%);
}*/


.boxWidget { position: relative;}

/*.wb-header .logoTextSettingClass {position: absolute;	top: 50%;	transform: translateY(-50%); } */

.logoWidget span{  font-size: 40px;  color: #000;margin-top: 1%; }

header {position: relative;}

/* Custome Classes */
.wb-page .centered-row {
	text-align: center;
}
.wb-page .centered-col {
	display: inline-block;
	float: none;
}
footer{position: relative;}
footer.footer-widgets{font-size: 13px;margin: 0;padding: 0;width: 100%;float: left;}
footer.footer-widgets .footer-list-style, footer.footer-widgets .footer-contact-us, footer.footer-widgets .footer-content{margin:0;padding:0;}
footer.footer-widgets ul{margin: 0;padding: 0;}
footer.footer-widgets ul li{list-style: none;color:#666;}
footer.footer-widgets h1, footer.footer-widgets h2, footer.footer-widgets h3,
footer.footer-widgets h4, footer.footer-widgets h5, footer.footer-widgets h6 {text-align:left;}
footer.footer-widgets h1, footer.footer-widgets h2, footer.footer-widgets h3,
footer.footer-widgets h4, footer.footer-widgets h5, footer.footer-widgets h6,
footer.footer-widgets p {margin-top:0;margin-bottom:10px;color:#666;}
footer.footer-widgets h1 {font-size:26px;}
footer.footer-widgets h2 {font-size:24px;}
footer.footer-widgets h3 {font-size: 22px;}
footer.footer-widgets h4 {font-size: 20px;}
footer.footer-widgets h5 {font-size: 18px;}
footer.footer-widgets h6 {font-size: 16px;font-weight: 600;text-transform: uppercase;}
footer.footer-widgets p {line-height:1.5;}
footer.footer-widgets a{color:#666;}
footer.footer-widgets .footer-nav p {font-weight: 600;text-transform: uppercase;}
footer.footer-widgets li {padding-bottom:5px;}
footer.footer-widgets .row {padding: 0;}
footer.footer-widgets [class*="footer-list-style"] li:last-child{margin-right:0;}
footer.footer-widgets [class*="footer-social-style"] span.fa {
	-webkit-transform: translateY(-50%);
	-ms-transform: translateY(-50%);
	transform: translateY(-50%);
	position: relative;
	top: 50%;
	display:block;
	text-align:center;
}
footer.footer-widgets .footer-button{
	background: transparent;
	color: #666;
	border: 1px solid #666;
	border-radius: 1000px;
	font-size: 11px;
	min-width: 115px;
	padding-top: 7px;
	padding-bottom: 7px;
}
footer.footer-widgets[class*=footer-light] a.footer-button{background:#333;color:#fff;border: 1px solid #333;}
footer.footer-widgets[class*=footer-dark] a.footer-button{background:#fff;color:#333;border:transparent;}

/***** footer-list-style *****/
footer.footer-widgets [class*="footer-list-style"] li:before {font-size:10px;}

footer.footer-widgets .footer-list-style1 li:before {
    font-family: 'FontAwesome';
    content: '\f105';
    margin-right: 8px;
}
footer.footer-widgets .footer-list-style2 li:before {
    font-family: 'FontAwesome';
    content: '\f0da';
    margin-right: 8px;
}
footer.footer-widgets .footer-list-style3 li:before {
    font-family: 'FontAwesome';
    content: '\f22d';
    margin-right: 8px;
}
footer.footer-widgets .footer-list-style4 li:before {
    font-family: 'FontAwesome';
    content: '\f138';
    margin-right: 8px;
}
footer.footer-widgets .footer-list-style5 li:before {
    font-family: 'FontAwesome';
    content: '\f192';
    margin-right: 8px;
}
footer.footer-widgets .footer-list-style6 li:before {
    font-family: 'FontAwesome';
    content: '\f068';
    margin-right: 8px;
}
footer.footer-widgets .footer-list-style7 li:before {
    font-family: 'FontAwesome';
    content: '\f101';
    margin-right: 8px;
}
footer.footer-widgets .footer-list-style8 li:before {
    font-family: 'FontAwesome';
    content: '\f18e';
    margin-right: 8px;
}
footer.footer-widgets .footer-list-style9 li:before {
    font-family: 'FontAwesome';
    content: '\f07e';
    margin-right: 8px;
}
footer.footer-widgets .footer-list-style10 li:before {
    font-family: 'FontAwesome';
    content: '\f111';
    margin-right: 8px;
}
footer.footer-widgets .footer-list-style11 li:before {
    font-family: 'FontAwesome';
    content: '\f110';
    margin-right: 8px;
}
footer.footer-widgets .footer-list-style12 li:before {
    font-family: 'FontAwesome';
    content: '\f058';
    margin-right: 8px;
}
/***** footer-list-style *****/

/***** footer-social-style *****/

/***** footer-social-style-(1) *****/
footer.footer-widgets .footer-social-style1 ul{text-align:left;}
footer.footer-widgets .footer-social-style1 li{ 
	display: inline-block;
    margin-right: 10px;
    padding-bottom: 0;
}
footer.footer-widgets .footer-social-style1 li a{ 
	display: inline-block;
    width: 40px;
    height: 40px;
    background: #666;
    text-align: center;
}
footer.footer-widgets .footer-social-style1 li span.fa {color: #fff;font-size: 18px;}
/***** footer-social-style-(1) *****/

/***** footer-social-style-(2) *****/
footer.footer-widgets .footer-social-style2 ul{text-align:left;}
footer.footer-widgets .footer-social-style2 li {display: inline-block;margin-right: 10px;}
footer.footer-widgets .footer-social-style2 li a {
	display: inline-block;
    width: 40px;
    height: 40px;
    text-align: center;
}
footer.footer-widgets .footer-social-style2 li span.fa {font-size: 18px;color: #666;}
/***** footer-social-style-(2) *****/

/***** footer-social-style-(3) *****/
footer.footer-widgets .footer-social-style3 ul{text-align:left;}
footer.footer-widgets .footer-social-style3 li {display: inline-block;margin-right: 10px;padding-bottom: 0;}
footer.footer-widgets .footer-social-style3 li a {
	width: 40px;
    height: 40px;
    border: 1px solid #666;
    display: inline-block;
    text-align: center;
    border-radius: 50px;
}
footer.footer-widgets .footer-social-style3 li span.fa {color: #666;font-size: 18px;margin-right: 0;}
/***** footer-social-style-(3) *****/

/***** footer-social-style-(4) *****/
footer.footer-widgets .footer-social-style4 ul{text-align:center;}
footer.footer-widgets .footer-social-style4 li {display: inline-block;margin-right: 20px;padding-bottom: 0;}
footer.footer-widgets .footer-social-style4 li a {
	display: inline-block;
    background: #666;
    width: 40px;
    height: 40px;
    border-radius: 50px;
}
footer.footer-widgets .footer-social-style4 li span.fa {color: #fff;font-size:18px;}
/***** footer-social-style-(4) *****/

/***** footer-social-style-(5) *****/
footer.footer-widgets .footer-social-style5 ul{text-align:center;}
footer.footer-widgets .footer-social-style5 li {margin-right: 10px;display: inline-block;}
footer.footer-widgets .footer-social-style5 li a {
	width: 40px;
    height: 40px;
    background: #666;
    display: inline-block;
    border-radius: 5px;
}
footer.footer-widgets .footer-social-style5 li span.fa {color: #fff;font-size: 18px;}
/***** footer-social-style-(5) *****/

footer.footer-widgets.footer-widgets-01-1 [class*="footer-social-style"] ul, footer.footer-widgets.footer-widgets-02-1 [class*="footer-social-style"] ul, footer.footer-widgets.footer-widgets-04-1 [class*="footer-social-style"] ul  {
    text-align: left;
}

footer.footer-widgets.footer-widgets-07-1 [class*="footer-social-style"] ul, footer.footer-widgets.footer-widgets-06-1 [class*="footer-social-style"] ul {
    text-align: center;
}



/***** footer-social-style *****/


/***** footer-widgets-01-1 *****/
footer.footer-widgets.footer-widgets-01-1 .footer-widgets-wrapper { padding: 50px 0 20px 0;}
/*footer.footer-widgets.footer-widgets-01-1 {padding: 50px 0 20px 0;}*/
/*footer.footer-widgets.footer-widgets-01-1 .footer-social-icons li span.fa {color: #fff;font-size: 20px;}
footer.footer-widgets.footer-widgets-01-1 .footer-social-icons li {display: inline-block;margin-right: 10px;padding-bottom: 0;}
footer.footer-widgets.footer-widgets-01-1 .footer-social-icons li a {
    display: inline-block;
    width: 50px;
    height: 50px;
    background: #666;
    text-align: center;
}*/
footer.footer-widgets.footer-widgets-01-1 .footer-copyright {margin-top: 80px;float: left;width: 100%;padding:0;}
/***** footer-widgets-01-1 *****/

/***** footer-widgets-02-1 *****/
footer.footer-widgets.footer-widgets-02-1 .footer-widgets-wrapper { padding:80px 0;}
/*footer.footer-widgets.footer-widgets-02-1 {padding:80px 0;}*/
/*footer.footer-widgets.footer-widgets-02-1 .footer-social-icons {}
footer.footer-widgets-02-1 .footer-social-icons ul {text-align: left;}
footer.footer-widgets.footer-widgets-02-1 .footer-social-icons ul li {display:inline-block;margin-right:10px;}
footer.footer-widgets.footer-widgets-02-1 .footer-social-icons ul li a {
    display: inline-block;
    width: 50px;
    height: 50px;
    text-align: center;
    border: 1px solid #666;
}
footer.footer-widgets.footer-widgets-02-1 .footer-social-icons ul li i {font-size: 20PX;color: #666;}*/
footer.footer-widgets.footer-widgets-02-1 .footer-nav {margin: 0;padding: 0;width: 100%;}
footer.footer-widgets.footer-widgets-02-1 .footer-nav p {
    display: inline-block;
    margin-right: 10px;
    text-align: left;
    font-size: 14px;
    margin-bottom: 0;
    /*border-right: 1px solid #666;*/
    padding-right: 10px;
}
footer.footer-widgets.footer-widgets-02-1 .footer-nav p:last-child {border-right:none;padding-right:0;}
footer.footer-widgets.footer-widgets-02-1 .footer-contact {margin: 10px 0;padding: 0;}
footer.footer-widgets.footer-widgets-02-1 .footer-copyright p {margin-bottom: 0;}
/***** footer-widgets-02-1 *****/

/***** footer-widgets-03-1 *****/
footer.footer-widgets.footer-widgets-03-1 .footer-widgets-wrapper { padding: 50px 0;}
/*footer.footer-widgets.footer-widgets-03-1 {padding: 50px 0;}*/
footer.footer-widgets.footer-widgets-03-1 p span.fa {font-size: 16px;margin-right: 10px;}

/***** footer-widgets-03-1 *****/

/***** footer-widgets-04-1 *****/
footer.footer-widgets.footer-widgets-04-1 .footer-widgets-wrapper { padding: 60px 0;}
/*footer.footer-widgets.footer-widgets-04-1 {padding: 60px 0;}*/
footer.footer-widgets.footer-widgets-04-1 .footer-logo {margin: 0;padding: 0 0 10px 0;text-align: left;}
footer.footer-widgets.footer-widgets-04-1 .footer-logo img {max-height: 60px;text-align: left;}
/*footer.footer-widgets.footer-widgets-04-1 .footer-social-icons {margin: 0;padding: 0;}
footer.footer-widgets.footer-widgets-04-1 .footer-social-icons li {
    display: inline-block;
    margin-right: 10px;
    padding-bottom: 0;
}
footer.footer-widgets.footer-widgets-04-1 .footer-social-icons a {
    width: 30px;
    height: 30px;
    border: 1px solid #666;
    display: inline-block;
    text-align: center;
    border-radius: 50px;
}
footer.footer-widgets.footer-widgets-04-1 .footer-social-icons a span.fa {color: #666;font-size: 12px;margin-right: 0;}*/
/*footer.footer-widgets.footer-widgets-04-1 li {list-style-type: circle;list-style-position: inside;}*/
footer.footer-widgets.footer-widgets-04-1 .footer-gallery {
    margin: 0;
    padding: 0;
    width: 100%;
    float: left;
}
footer.footer-widgets.footer-widgets-04-1 .footer-gallery li {
    float: left;
    width: 80px;
    margin-right: 5px;
    position: relative;
    padding: 0;
    margin-bottom: 5px;
}
footer.footer-widgets.footer-widgets-04-1 .footer-gallery li figure {
    position: static;
    float: none;
    overflow: auto;
    width: 100%;
    background: transparent !important;
    text-align: left;
    cursor: pointer;
    margin: 0;
}
footer.footer-widgets.footer-widgets-04-1 .footer-gallery figure img {
    min-height: 80px;
    opacity: 1;
}
footer.footer-widgets.footer-widgets-04-1 .footer-gallery li figure figcaption {
    display: none;
}
footer.footer-widgets.footer-widgets-04-1 .footer-gallery img {width: 100%;}
/***** footer-widgets-04-1 *****/
 
 /***** footer-widgets-05-1 *****/
footer.footer-widgets.footer-widgets-05-1 .footer-widgets-wrapper {padding: 80px 0;}
/*footer.footer-widgets.footer-widgets-05-1 {padding: 80px 0;}*/
footer.footer-widgets.footer-widgets-05-1 h6 {border-bottom: 1px solid #777;padding-bottom: 10px;}
/***** footer-widgets-05-1 *****/

/***** footer-widgets-06-1 *****/
footer.footer-widgets.footer-widgets-06-1 .footer-widgets-wrapper {padding: 60px 0;}
/*footer.footer-widgets.footer-widgets-06-1 {padding: 60px 0;}*/
footer.footer-widgets.footer-widgets-06-1 .footer-logo {text-align: center;margin-bottom: 50px;}
footer.footer-widgets.footer-widgets-06-1 .footer-logo img {max-height:80px;}
footer.footer-widgets.footer-widgets-06-1 .footer-contact, footer.footer-widgets.footer-widgets-06-1 .footer-copyright p {text-align: center;}
footer.footer-widgets.footer-widgets-06-1 .footer-contact {margin-bottom: 50px;}
footer.footer-widgets.footer-widgets-06-1 .footer-contact li {padding-bottom: 10px;}
/*footer.footer-widgets.footer-widgets-06-1 .footer-social-icons ul li {display:inline-block;margin-right: 20px;}
footer.footer-widgets.footer-widgets-06-1 .footer-social-icons ul li a {
    display: inline-block;
    background: #666;
    width: 40px;
    height: 40px;
    border-radius: 50px;
}
footer.footer-widgets.footer-widgets-06-1 .footer-social-icons ul li i {color: #fff;}*/
footer.footer-widgets.footer-widgets-06-1 .footer-copyright {margin-top: 20px;}
/***** footer-widgets-06-1 *****/

/***** footer-widgets-07-1 *****/
footer.footer-widgets.footer-widgets-07-1 .footer-widgets-wrapper {padding: 60px 0 0 0;}
/*footer.footer-widgets.footer-widgets-07-1 {padding: 60px 0 0 0;}*/
footer.footer-widgets.footer-widgets-07-1 .footer-nav {padding: 0;text-align: center;}
footer.footer-widgets.footer-widgets-07-1 .footer-nav
{margin-top:0;margin-bottom:50px;}
footer.footer-widgets.footer-widgets-07-1 .footer-nav p { display: inline-block;font-size: 16px;margin-right: 15px;margin-bottom: 0;}
/*footer.footer-widgets.footer-widgets-07-1 .footer-social-icons {text-align: center;}
footer.footer-widgets.footer-widgets-07-1 .footer-social-icons li {margin-right:10px;display:inline-block;}
footer.footer-widgets.footer-widgets-07-1 .footer-social-icons li a {
	width: 40px;
	height: 40px;
	background: #666;
	display:inline-block;
	border-radius: 5px;
}*/
footer.footer-widgets.footer-widgets-07-1 [class*="footer-social-style"] {margin-top:0;margin-bottom:50px;}
/*footer.footer-widgets.footer-widgets-07-1 .footer-social-icons li i {color: #fff;font-size:16px;}*/
footer.footer-widgets.footer-widgets-07-1 .footer-contact {text-align: center;}
footer.footer-widgets.footer-widgets-07-1 .footer-contact p {/*color: #666;*/}
footer.footer-widgets.footer-widgets-07-1 .footer-copyright {margin-top: 50px;text-align: center;border-top: 1px solid #666;padding: 10px 0;}
footer.footer-widgets.footer-widgets-07-1 .footer-copyright p{/*color:#666;*/margin-bottom:0;}
/***** footer-widgets-07-1 *****/


/***** footer form *****/
footer.footer-widgets .footer-form input[type="text"],
footer.footer-widgets .footer-form input[type="email"],
footer.footer-widgets .footer-form textarea {
    width: 100%;
    font-size: 13px;
    font-family: FontAwesome, 'Open Sans', sans-serif;
    padding: 6px 10px;
    margin-bottom: 10px;
    border: 1px solid #666;
	border-radius:4px;
    outline: none;
}
footer.footer-widgets .footer-form-btn .button {
    background: transparent;
    outline: none;
    border: 1px solid #666;
    padding: 5px 20px;
	border-radius:4px;
	
}
footer.footer-widgets .footer-form label {
    font-size: 13px;
    text-transform: lowercase;
}
footer.footer-widgets .footer-form button {
    margin: 0;
    background: transparent;
    outline: none;
    border: 1px solid #fff;
    padding: 5px 20px;
    border-radius: 4px;
    color: #fff;
    font-size: 12px;
}

footer.footer-widgets .footer-form ::-webkit-input-placeholder { /* Chrome */ color: #666; }
footer.footer-widgets .footer-form :-ms-input-placeholder { /* IE 10+ */ color: #666; }
footer.footer-widgets .footer-form ::-moz-placeholder { /* Firefox 19+ */ color: #666; opacity: 1; }
footer.footer-widgets .footer-form :-moz-placeholder { /* Firefox 4 - 18 */ color: #666; opacity: 1; }

footer.footer-widgets[class*="footer-light"] .footer-form input[type="text"],
footer.footer-widgets[class*="footer-light"] .footer-form input[type="email"],
footer.footer-widgets[class*="footer-light"] .footer-form textarea
{border:1px solid #333;color:#333;background:transparent;}
footer.footer-widgets[class*="footer-light"] .footer-form ::-webkit-input-placeholder { /* Chrome */ color: #333; }
footer.footer-widgets[class*="footer-light"] .footer-form :-ms-input-placeholder { /* IE 10+ */ color: #666; }
footer.footer-widgets[class*="footer-light"] .footer-form ::-moz-placeholder { /* Firefox 19+ */ color: #666; opacity: 1; }
footer.footer-widgets[class*="footer-light"] .footer-form :-moz-placeholder { /* Firefox 4 - 18 */ color: #666; opacity: 1; }
footer.footer-widgets[class*="footer-light"] .footer-form-btn .button {border: 1px solid #333;color:#333;}
footer.footer-widgets[class*="footer-dark"] .footer-form input[type="text"],
footer.footer-widgets[class*="footer-dark"] .footer-form input[type="email"],
footer.footer-widgets[class*="footer-dark"] .footer-form textarea
{border:1px solid #fff;color:#fff;background:transparent;}
footer.footer-widgets[class*="footer-dark"] .footer-form ::-webkit-input-placeholder { /* Chrome */ color: #fff; }
footer.footer-widgets[class*="footer-dark"] .footer-form :-ms-input-placeholder { /* IE 10+ */ color: #fff; }
footer.footer-widgets[class*="footer-dark"] .footer-form ::-moz-placeholder { /* Firefox 19+ */ color: #fff; opacity: 1; }
footer.footer-widgets[class*="footer-dark"] .footer-form :-moz-placeholder { /* Firefox 4 - 18 */ color: #fff; opacity: 1; }
footer.footer-widgets[class*="footer-dark"] .footer-form-btn .button {border: 1px solid #fff;color:#fff;}

/***** footer form *****/

/*==== Footer Light ====*/
.footer-light-1 { background-color: #fde3a7;}
.footer-light-2 { background-color: #8effc1;}
.footer-light-3 { background-color: #f9ebff;}
.footer-light-4 { background-color: #5efaf7;}
.footer-light-5 { background-color: #bceafd;}
.footer-light-6 { background-color: #fbffdc;}
.footer-light-7 { background-color: #F5D76E;}
.footer-light-8 { background-color: #ecf0f1;}
.footer-light-9 { background-color: #c6c7c9;}
.footer-light-10 { background-color:#FFBCD8;}



footer.footer-widgets [class*="footer-light"] li,
footer.footer-widgets [class*="footer-light"] label,
footer.footer-widgets [class*="footer-light"] span,
footer.footer-widgets [class*="footer-light"] strong,
footer.footer-widgets [class*="footer-light"] a,
footer.footer-widgets [class*="footer-light"] p,
footer.footer-widgets [class*="footer-light"],
footer.footer-widgets [class*="footer-light"] h1,
footer.footer-widgets [class*="footer-light"] h2,
footer.footer-widgets [class*="footer-light"] h3,
footer.footer-widgets [class*="footer-light"] h4,
footer.footer-widgets [class*="footer-light"] h5,
footer.footer-widgets [class*="footer-light"] h6,
footer.footer-widgets[class*="footer-light"] li,
footer.footer-widgets[class*="footer-light"] label,
footer.footer-widgets[class*="footer-light"] span,
footer.footer-widgets[class*="footer-light"] strong,
footer.footer-widgets[class*="footer-light"] a,
footer.footer-widgets[class*="footer-light"] p,
footer.footer-widgets[class*="footer-light"],
footer.footer-widgets[class*="footer-light"] h1,
footer.footer-widgets[class*="footer-light"] h2,
footer.footer-widgets[class*="footer-light"] h3,
footer.footer-widgets[class*="footer-light"] h4,
footer.footer-widgets[class*="footer-light"] h5,
footer.footer-widgets[class*="footer-light"] h6{
  color: #333;
}
footer.footer-widgets[class*="footer-light"] .footer-social-icons li a, footer.footer-widgets[class*="footer-light"].footer-widgets-06-1  .footer-social-icons li a{background:#333;border-color:#333;}
footer.footer-widgets[class*="footer-light"] .footer-social-icons li span.fa{color:#fff;}

footer.footer-widgets[class*="footer-light"].footer-widgets-04-1 .footer-social-icons li a{background: transparent;}
footer.footer-widgets[class*="footer-light"].footer-widgets-04-1 .footer-social-icons li span.fa{color:#333;}


footer.footer-widgets[class*="footer-dark"] .footer-social-icons li a, footer.footer-widgets[class*="dark"].footer-widgets-06-1  .footer-social-icons li a{background:#fff;border-color:#fff;}
footer.footer-widgets[class*="footer-dark"].footer-widgets-04-1 .footer-social-icons li a{background: transparent;}
footer.footer-widgets[class*="footer-dark"].footer-widgets-04-1 .footer-social-icons li span.fa{color:#fff;}
footer.footer-widgets[class*="footer-dark"] .footer-social-icons li span.fa{color:#333;}



footer.footer-widgets[class*="footer-dark"] [class*="footer-social-style"] li a {background:#fff;border-color:#fff;}
footer.footer-widgets[class*="footer-dark"] [class*="footer-social-style"] li span.fa{color:#333;}

footer.footer-widgets[class*="footer-light"] [class*="footer-social-style"] li a {background:#333;border-color:#333;}
footer.footer-widgets[class*="footer-light"] [class*="footer-social-style"] li span.fa{color:#fff;}


/*==== Footer Light ====*/

/*==== Footer Dark ====*/
.footer-dark-1 { background-color: #154360;}
.footer-dark-2 { background-color: #CF3A24;}
.footer-dark-3 { background-color: #22A7F0;}
.footer-dark-4 { background-color: #606060;}
.footer-dark-5 { background-color: #633974;}
.footer-dark-6 { background-color: #262932;}
.footer-dark-7 { background-color: #0EAC51;}
.footer-dark-8 { background-color: #8A0028;}
.footer-dark-9 { background-color: #413e3c;}
.footer-dark-10 { background-color:#F1892D;}
.footer-dark-custom { background-color:#000 }
footer.footer-widgets [class*="footer-dark"] li,
footer.footer-widgets [class*="footer-dark"] label,
footer.footer-widgets [class*="footer-dark"] span,
footer.footer-widgets [class*="footer-dark"] strong,
footer.footer-widgets [class*="footer-dark"] a,
footer.footer-widgets [class*="footer-dark"] p,
footer.footer-widgets [class*="footer-dark"],
footer.footer-widgets [class*="footer-dark"] h1,
footer.footer-widgets [class*="footer-dark"] h2,
footer.footer-widgets [class*="footer-dark"] h3,
footer.footer-widgets [class*="footer-dark"] h4,
footer.footer-widgets [class*="footer-dark"] h5,
footer.footer-widgets [class*="footer-dark"] h6,
footer.footer-widgets[class*="footer-dark"] li,
footer.footer-widgets[class*="footer-dark"] label,
footer.footer-widgets[class*="footer-dark"] span,
footer.footer-widgets[class*="footer-dark"] strong,
footer.footer-widgets[class*="footer-dark"] a,
footer.footer-widgets[class*="footer-dark"] p,
footer.footer-widgets[class*="footer-dark"],
footer.footer-widgets[class*="footer-dark"] h1,
footer.footer-widgets[class*="footer-dark"] h2,
footer.footer-widgets[class*="footer-dark"] h3,
footer.footer-widgets[class*="footer-dark"] h4,
footer.footer-widgets[class*="footer-dark"] h5,
footer.footer-widgets[class*="footer-dark"] h6{
  color: #fff;
}
footer.footer-widgets a:hover{text-decoration:none;}

/*==== Footer Dark ====*/


/*1-FOOTER-FORM-VARITIONS
2-FOOTER-LI-VARITIONS
3-FOOTER-SOCIAL-ICONS
4-FOOTER-HEADINGS
5-FOOTER-CONTACT-VARITIONS
6-FOOTER-BACKGROUNDS
7-FOOTER-PATTERNS
*/
/*
@media only screen and (min-width:992px) {}
@media only screen and (max-width: 600px) {}
@media only screen and (min-width:) and (max-width:) {}
*/
.margin-tb{margin:20px 0;}

@media only screen and (min-device-width : 768px) and (max-device-width : 1024px) {
	
/*===== footer-widgets-01-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-01-1 .footer-social-icons li a {width: 40px;height: 40px;}
footer.footer-widgets.footer-widgets-01-1 .footer-social-icons li {margin-right: 5px;}
/*===== footer-widgets-01-1 (Responisve-End) =====*/	

/*===== footer-widgets-02-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-02-1 .footer-social-icons ul li a {width: 40px;height: 40px;}
footer.footer-widgets.footer-widgets-02-1 .footer-social-icons ul li {margin-right: 5px;}
footer.footer-widgets.footer-widgets-02-1 .footer-nav p{padding-right: 5px;margin-right: 5px;font-size:14px;}
/*===== footer-widgets-02-1 (Responisve-End) =====*/	


/*===== footer-widgets-03-1 (Responisve-Start) =====*/

/*===== footer-widgets-03-1 (Responisve-End) =====*/


/*===== footer-widgets-04-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-04-1 .footer-gallery li{max-width: 60px;}
footer.footer-widgets.footer-widgets-04-1 .footer-social-icons a {width: 30px;height: 30px;}
footer.footer-widgets.footer-widgets-04-1 .footer-social-icons li {margin-right: 5px;}
footer.footer-widgets.footer-widgets-04-1 .footer-social-icons a span.fa {font-size: 12px;}
/*===== footer-widgets-04-1 (Responisve-End) =====*/	

/*===== footer-widgets-05-1 (Responisve-Start) =====*/

/*===== footer-widgets-05-1 (Responisve-End) =====*/		

/*===== footer-widgets-06-1 (Responisve-Start) =====*/

/*===== footer-widgets-06-1 (Responisve-End) =====*/		
	
/*===== footer-widgets-07-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-07-1 { padding: 40px 0px;}
/*===== footer-widgets-07-1 (Responisve-End) =====*/			
}

@media only screen and (max-width: 768px) {
footer.footer-widgets [class*="footer-social-style"] li {margin-right:5px;}	
footer.footer-widgets [class*="footer-social-style"] li a{width: 36px;height: 36px;}
/*===== footer-widgets-01-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-01-1 .footer-social-icons li {margin-right: 5px;}
footer.footer-widgets.footer-widgets-01-1 .footer-social-icons li a {width: 36px;height: 36px;}
footer.footer-widgets.footer-widgets-01-1 .footer-social-icons li span.fa {font-size:16px;}
footer.footer-widgets.footer-widgets-01-1 .footer-copyright {margin-top: 40px;}
/*===== footer-widgets-01-1 (Responisve-End) =====*/		
footer.footer-widgets.footer-widgets-04-1 .footer-gallery li{max-width: 70px;}
/*===== footer-widgets-02-1 (Responisve-Start) =====*/	
footer.footer-widgets.footer-widgets-02-1 .footer-social-icons ul li a {width: 40px;height: 40px;}
footer.footer-widgets.footer-widgets-02-1 .footer-social-icons ul li i {font-size: 16px;}
footer.footer-widgets.footer-widgets-02-1 .footer-nav p{display: block;margin-right: 5px;padding-right:5px;
font-size: 14px;font-weight: 600;border-right:0;}	
/*===== footer-widgets-02-1 (Responisve-End) =====*/	

/*===== footer-widgets-03-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-03-1 {padding: 50px 0;}
footer.footer-widgets.footer-widgets-03-1 h6 {margin-bottom: 15px;}
footer.footer-widgets.footer-widgets-03-1 .footer-content {margin-bottom:50px;}
/*footer.footer-widgets.footer-widgets-03-1 .footer-list-style {margin-top: 20px;}
footer.footer-widgets.footer-widgets-03-1 .footer-contact-detail {margin-top: 20px;}
footer.footer-widgets.footer-widgets-03-1 .footer-form {margin-top: 20px;}*/
/*===== footer-widgets-03-1 (Responisve-End) =====*/

/*===== footer-widgets-04-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-04-1 .footer-content, footer.footer-widgets.footer-widgets-04-1 .footer-list-style {margin-bottom:30px;}
footer.footer-widgets.footer-widgets-04-1 h6 {margin-bottom: 15px;}
footer.footer-widgets.footer-widgets-04-1 .footer-social-icons li {margin-right:5px;}
footer.footer-widgets.footer-widgets-04-1 .footer-social-icons a {width: 30px;height: 30px;}
footer.footer-widgets.footer-widgets-04-1 .footer-social-icons a span.fa {font-size: 14px;}
/*===== footer-widgets-04-1 (Responisve-End) =====*/	

/*===== footer-widgets-05-1 (Responisve-Start) =====*/

/*===== footer-widgets-05-1 (Responisve-End) =====*/		

/*===== footer-widgets-06-1 (Responisve-Start) =====*/

/*===== footer-widgets-06-1 (Responisve-End) =====*/		
	
/*===== footer-widgets-07-1 (Responisve-Start) =====*/

/*===== footer-widgets-07-1 (Responisve-End) =====*/	
	
}

@media only screen and (max-width:640px) {

/*===== footer-widgets-01-1 (Responisve-Start) =====*/

/*===== footer-widgets-01-1 (Responisve-End) =====*/	

/*===== footer-widgets-02-1 (Responisve-Start) =====*/

/*===== footer-widgets-02-1 (Responisve-End) =====*/	

/*===== footer-widgets-03-1 (Responisve-Start) =====*/

/*===== footer-widgets-03-1 (Responisve-End) =====*/

/*===== footer-widgets-04-1 (Responisve-Start) =====*/

/*===== footer-widgets-04-1 (Responisve-End) =====*/	

/*===== footer-widgets-05-1 (Responisve-Start) =====*/

/*===== footer-widgets-05-1 (Responisve-End) =====*/		

/*===== footer-widgets-06-1 (Responisve-Start) =====*/

/*===== footer-widgets-06-1 (Responisve-End) =====*/		
	
/*===== footer-widgets-07-1 (Responisve-Start) =====*/

/*===== footer-widgets-07-1 (Responisve-End) =====*/	
}

@media only screen and (min-device-width : 320px) and (max-device-width : 480px) {
	
footer.footer-widgets [class*="footer-social-style"]{margin-bottom:30px;}
footer.footer-widgets [class*="footer-social-style"] li {margin-right:5px;}	
footer.footer-widgets [class*="footer-social-style"] li a{width: 40px;height: 40px;}
/*===== footer-widgets-01-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-01-1 [class*="footer-list-style"]{margin-bottom:30px;}
footer.footer-widgets.footer-widgets-01-1 .footer-content {margin-bottom:30px;}
footer.footer-widgets.footer-widgets-01-1 .footer-copyright{margin:0;}
/*footer.footer-widgets.footer-widgets-01-1 .footer-social-style1 li {margin-right:5px;}
footer.footer-widgets.footer-widgets-01-1 .footer-social-style1 li a{width: 40px;height: 40px;}*/
/*===== footer-widgets-01-1 (Responisve-End) =====*/	

/*===== footer-widgets-02-1 (Responisve-Start) =====*/	
footer.footer-widgets.footer-widgets-02-1 {padding: 40px 0;}
footer.footer-widgets.footer-widgets-02-1 .footer-social-icons, footer.footer-widgets.footer-widgets-02-1 .footer-nav, footer.footer-widgets.footer-widgets-02-1 .footer-contact {margin-bottom: 30px;}
footer.footer-widgets.footer-widgets-02-1 .footer-contact{margin-top:0;}
/*===== footer-widgets-02-1 (Responisve-End) =====*/	

/*===== footer-widgets-03-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-03-1 {padding: 40px 0;}
footer.footer-widgets.footer-widgets-03-1 .footer-content, footer.footer-widgets.footer-widgets-03-1 .footer-contact{margin-bottom:30px;}
footer.footer-widgets.footer-widgets-03-1 [class*="footer-list-style"]{margin-bottom:30px;}
/*===== footer-widgets-03-1 (Responisve-End) =====*/

/*===== footer-widgets-04-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-04-1 {padding: 40px 0;}
footer.footer-widgets.footer-widgets-04-1 .footer-content, 
footer.footer-widgets.footer-widgets-04-1 .footer-gallery{margin-top:0;margin-bottom:30px;}
footer.footer-widgets.footer-widgets-04-1 .footer-gallery li{max-width: 60px;margin-right: 10px;margin-bottom: 10px;}
footer.footer-widgets.footer-widgets-04-1 [class*="footer-list-style"]{margin-bottom:30px;margin-top:0;}
/*===== footer-widgets-04-1 (Responisve-End) =====*/	

/*===== footer-widgets-05-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-05-1 {padding: 40px 0;}
footer.footer-widgets.footer-widgets-05-1 [class*="footer-list-style"]{margin-bottom:30px;}
/*===== footer-widgets-05-1 (Responisve-End) =====*/	

/*===== footer-widgets-06-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-06-1 {padding: 40px 0;}
footer.footer-widgets.footer-widgets-06-1 .footer-contact,
footer.footer-widgets.footer-widgets-06-1 .footer-social-icons {margin-bottom: 30px;}
footer.footer-widgets.footer-widgets-06-1 .footer-social-icons ul li {margin-right:10px;}
footer.footer-widgets.footer-widgets-06-1 .footer-copyright {margin-top: 0;}
/*===== footer-widgets-06-1 (Responisve-End) =====*/	

/*===== footer-widgets-07-1 (Responisve-Start) =====*/
footer.footer-widgets.footer-widgets-07-1 {padding: 40px 0 20px 0;}
footer.footer-widgets.footer-widgets-07-1 .footer-nav p {display: block;margin-right: 0;margin-bottom: 10px;}
/*===== footer-widgets-07-1 (Responisve-End) =====*/	
}










/* Common Style */
[id*="accordion-"].AccordionWidgetPopup .panel-title,
[id*="accordion-"].AccordionWidget  .panel-title {
  text-align: left;
  font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
  text-transform: none;
}

[id*="accordion-"].AccordionWidgetPopup  .panel-body,
[id*="accordion-"].AccordionWidget .panel-body {
  border-top:0 !important;
}

/*  */
[id*="accordion-"].accordion-style1 .panel{
    border: none;
    box-shadow: none;
    border-radius: 3px;
    margin-bottom: 10px;
    position: relative;
}
[id*="accordion-"].accordion-style1 .panel:after{
    content: "";
    width: 2px;
    height: 100%;
    background: #a2a2a2;
    position: absolute;
    top: 25px;
    left: 25px;
}
[id*="accordion-"].accordion-style1 .panel:last-child:after{
    display: none;
}
[id*="accordion-"].accordion-style1 .panel-heading{
    padding: 0;
    border: none;
    background: #fff;
}
[id*="accordion-"].accordion-style1 .panel-title a{
    display: block;
    padding: 15px 20px 20px 70px !important;
    font-size: 16px;
    font-weight: 600;
    color: #4160a0;
    position: relative;
}
[id*="accordion-"].accordion-style1 .panel-title a:before{
    content: "";
    width: 50px;
    height: 1px;
    background: #a2a2a2;
    position: absolute;
    bottom: 0;
    left: 70px;
}
[id*="accordion-"].accordion-style1 .panel-title a:after{
    content: "\f0c1";
    font-family: 'FontAwesome';
    width: 50px;
    height: 50px;
    line-height: 50px;
    background: #4160a0;
    border: 2px solid #4160a0;
    border-radius: 50%;
    font-size: 18px;
    font-weight: normal;
    color: #fff;
    text-align: center;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
}
[id*="accordion-"].accordion-style1 .panel-title a.collapsed{
    color: #a2a2a2;
}
[id*="accordion-"].accordion-style1 .panel-title a.collapsed:after{
    background: #fff;
    border: 2px solid #a2a2a2;
    color: #a2a2a2;
}
[id*="accordion-"].accordion-style1 .panel-body{
    padding: 10px 20px 10px 70px;
    border: none;
    font-size: 14px;
    color: #888;
    line-height: 25px;
}



[id*="accordion-"].accordion-style2 .panel{
    border-radius:0;
    margin-bottom:15px[id*="accordion-"];
}
.accordion-style2 .panel-heading{
    padding:0;
}
[id*="accordion-"].accordion-style2 .panel-title{
    position: relative;
}
[id*="accordion-"].accordion-style2 .panel-title:before{
    content: "";
    border-bottom: 25px solid rgba(0, 0, 0, 0);
    border-left: 15px solid #eee;
    border-top: 23px solid rgba(0, 0, 0, 0);
    width: 0;
    height: 0;
    position: absolute;
    top: 0;
    left: 32px;
}
[id*="accordion-"].accordion-style2 .panel-title a{
    color:#fff !important;
    background:#4160a0;
    display: block;
    font-size: 12px;
    line-height: 21px;
    font-weight:bold;    
    padding: 13px 10px 13px 65px !important;
}
[id*="accordion-"].accordion-style2 .panel-title a.collapsed{
    color: #a2a2a2 !important;
    background:#fff;
}
[id*="accordion-"].accordion-style2 .panel-title a:before,
[id*="accordion-"].accordion-style2 .panel-title a.collapsed:before{
    content: "\f068";
    font-family: 'FontAwesome';
    position: absolute;
    top:0;
    left:0px;
    padding:14px 10px;
    color:#4160a0;
    background:#eee;
}
[id*="accordion-"].accordion-style2 .panel-title a.collapsed:before{
    content: "\f067";
}
[id*="accordion-"].accordion-style2 .panel-body{
    color: #828282;
    font-size: 14px;
    line-height: 26px;
}



[id*="accordion-"].accordion-style3 .panel{
    border: none;
    box-shadow: none;
    border-radius: 0;
    margin-bottom: 6px;
}
[id*="accordion-"].accordion-style3 .panel-heading{
    padding: 0;
}
[id*="accordion-"].accordion-style3 .panel-title a{
    display: block;
    padding: 20px 25px !important;
    background: #fff;
    font-size: 16px;
    font-weight: bold;
    color: #4160a0;    
    border: 1px solid #a2a2a2;
    border-left: 3px solid #4160a0;
    position: relative;
    transition: all 0.3s ease 0s;
}
[id*="accordion-"].accordion-style3 .panel-title a.collapsed{
    color: #a2a2a2;
}
[id*="accordion-"].accordion-style3 .panel-title a:before,
[id*="accordion-"].accordion-style3 .panel-title a.collapsed:before{
    content: "\f107";
    font-family: FontAwesome;
    font-size: 14px;
    color: #a2a2a2;
    line-height: 24px;
    position: absolute;
    top: 15px;
    right: 25px;
}
[id*="accordion-"].accordion-style3 .panel-title a.collapsed:before{
    content: "\f106";
}
[id*="accordion-"].accordion-style3 .panel-title a:hover,
[id*="accordion-"].accordion-style3 .panel-title a.collapsed:hover,
[id*="accordion-"].accordion-style3 .panel-title a:before,
[id*="accordion-"].accordion-style3 .panel-title a:hover:before{
    color: #4160a0;
}
[id*="accordion-"].accordion-style3 .panel-body{
    padding: 15px 27px;
    font-size: 14px;
    color: #808080;
    line-height: 23px;
    border: 1px solid #a2a2a2;
    border-top: none;
    border-left: 3px solid #a2a2a2;
}
[id*="accordion-"].accordion-style3 .panel-body p{
    margin-bottom: 0;
}

[id*="accordion-"].accordion-style4 .panel{
    border: none;
    border-radius: 0;
    box-shadow: none;
    margin: 0 0 15px 50px;
}
[id*="accordion-"].accordion-style4 .panel-heading{
    padding: 0;
    background: #fff;
    border: none;
    position: relative;
}
[id*="accordion-"].accordion-style4 .panel-title a{
    display: block;
    padding: 10px 20px 10px 60px !important;
    background: #4160a0;
    border-radius: 30px;
    border: 2px solid #4160a0;
    font-size: 16px;
    font-weight:600;
    color: #fff !important;
    position: relative;
}
[id*="accordion-"].accordion-style4 .panel-title a.collapsed{
    border: 2px solid #a2a2a2;
    background: #fff;
    color: #a2a2a2 !important;
}
[id*="accordion-"].accordion-style4 .panel-title a:before,
[id*="accordion-"].accordion-style4 .panel-title a.collapsed:before{
    content: "\f068";
    font-family: fontawesome;
    width: 60px;
    height: 60px;
    line-height: 60px;
    border-radius: 50%;
    background: #4160a0;
    font-size: 18px;
    color: #fff;
    text-align: center;
    border-right: 3px solid #fff;
    position: absolute;
    top: -4px;
    left: -30px;
    z-index: 1;
    transition: all 0.3s ease 0s;
}
[id*="accordion-"].accordion-style4 .panel-title a.collapsed:before{
    content: "\f067";
    background: #a2a2a2;
    border: none;
}
[id*="accordion-"].accordion-style4 .panel-body{
    padding: 15px 20px 0;
    margin: 0 0 0 30px;
    border: none;
    font-size: 14px;
    color: #a2a2a2;
    line-height: 28px;
    position: relative;
}
[id*="accordion-"].accordion-style4 .panel-body:before{
    content: "";
    display: block;
    width: 5px;
    height: 99%;
    background: #4160a0;
    position: absolute;
    top: 0;
    left: -30px;
}
[id*="accordion-"].accordion-style4 .panel-body:after{
    content: "";
    border-top: 20px solid #4160a0;
    border-left: 20px solid transparent;
    border-right: 20px solid transparent;
    position: absolute;
    bottom: 0;
    left: -48px;
}


[id*="accordion-"].accordion-style5 .panel{
    border: none;
    border-bottom: 1px solid #fff;
    box-shadow: none;
    border-radius: 0;
    margin-bottom: -5px;
}
[id*="accordion-"].accordion-style5 .panel:last-child{ border-bottom: none; }
[id*="accordion-"].accordion-style5 .panel-heading{
    padding: 0;
    border-radius: 0;
}
[id*="accordion-"].accordion-style5 .panel-title a{
    display: block;
    padding: 15px 20px 15px 30px !important;
    background: #4160a0;
    font-size: 16px;
    font-weight: 600;
    color: #fff !important;
    border: none;
    transition: all 1s ease 0s;
}

[id*="accordion-"].accordion-style5 .panel-body{
    padding: 25px 20px 15px 40px;
    font-size: 14px;
    color: #a2a2a2;
    line-height: 28px;
    background: #fff;
    border: none;
    position: relative;
}
[id*="accordion-"].accordion-style5 .panel-body:before{
    content: "";
    border-top: 15px solid #4160a0;
    border-left: 15px solid transparent;
    border-right: 15px solid transparent;
    position: absolute;
    top: 0;
    left: 30px;
}
[id*="accordion-"].accordion-style5 .panel-body:after{
    content: "";
    width: 8px;
    height: 60px;
    background: #4160a0;
    position: absolute;
    top: 25%;
    left: 0;}

[id*="accordion-"].accordion-style6 .panel{
    border: none;
    box-shadow: none;
    position: relative;
}
[id*="accordion-"].accordion-style6 .panel-heading{
    padding: 0;
    position: relative;
}
[id*="accordion-"].accordion-style6 .panel-heading:before{
    content: "";
    width: 1px;
    height: 100%;
    background: #fff;
    position: absolute;
    top: 0;
    right: 60px;
    z-index: 1;
}
[id*="accordion-"].accordion-style6 .panel-heading:after{
    content: "";
    border-left: 15px solid #a2a2a2;
    border-top: 15px solid #fff;
    border-right: 15px solid #fff;
    position: absolute;
    top: 0;
    right: -15px;
}
[id*="accordion-"].accordion-style6 .panel-title a{
    font-weight: 700;
    display: block;
    padding: 15px 20px !important;
    background: #4160a0;
    border: none;
    font-size: 16px;
    color: #fff !important;
    letter-spacing: 1px;
    text-align: left;
    position: relative;
}
[id*="accordion-"].accordion-style6 .panel-title a:before,
[id*="accordion-"].accordion-style6 .panel-title a.collapsed:before{
    content: "\f068";
    font-family: fontawesome;
    width: 30px;
    height: 30px;
    line-height: 30px;
    border-radius: 50%;
    background: #a2a2a2;
    font-size: 15px;
    color: #fff;
    position: absolute;
    top: 13px;
    right: 17px;
    text-align: center;
    transition: all 0.5s ease 0s;
}
[id*="accordion-"].accordion-style6 .panel-title a.collapsed:before{ content: "\f067"; }
[id*="accordion-"].accordion-style6 .panel-body{
    padding: 10px 20px;
    border: none;
    background: #fff;
    font-size: 15px;
    color: #a2a2a2;
    line-height: 28px;
}




[id*="accordion-"].accordion-style7 .panel{
    border: none;
    box-shadow: none;
    border-radius: 30px;
    margin-bottom: 15px;
}
[id*="accordion-"].accordion-style7 .panel-heading{
    padding: 0;
    border-radius: 30px;
}
[id*="accordion-"].accordion-style7 .panel-title a{
    display: block;
    padding: 17px 20px 17px 70px !important;
    background: #f3f3f3;
    font-size: 16px;
    font-weight: 600;
    color: #4160a0;
    border: none;
    border-radius: 30px;
    position: relative;
    transition: all 0.3s ease 0s;
}
[id*="accordion-"].accordion-style7 .panel-title a.collapsed{ color: #7d7d7d; }
[id*="accordion-"].accordion-style7 .panel-title a:after,
[id*="accordion-"].accordion-style7 .panel-title a.collapsed:after{
    content: "\f107";
    font-family: fontawesome;
    width: 55px;
    height: 55px;
    line-height: 55px;
    border-radius: 50%;
    background: #4160a0;
    font-size: 25px;
    color: #fff;
    text-align: center;
    position: absolute;
    top: 0;
    left: 0;
    transition: all 0.3s ease 0s;
}
[id*="accordion-"].accordion-style7 .panel-title a.collapsed:after{ content: "\f105"; }
[id*="accordion-"].accordion-style7 .panel-body{
    padding: 10px 20px;
    font-size: 14px;
    color: #171616;
    line-height: 25px;
    border-top: none;
    position: relative;
}
/* [id*="accordion-"].accordion-style7 .panel-body p{
    padding: 10px 20px 10px;
    margin: 0;
    background: #f3f3f3;
    border-radius: 15px;
} */



[id*="accordion-"].accordion-style8 .panel{
    border: 1px solid #4160a0;
    border-radius: 0;
    box-shadow: none;
    margin-left: 50px;
    margin-bottom: 12px;
}

[id*="accordion-"].accordion-style8 .panel-heading{
    padding: 0;
    background: #fff;
    position: relative;
}
[id*="accordion-"].accordion-style8 .panel-heading:before,
[id*="accordion-"].accordion-style8 .panel-heading:after{
    content: "";
    border-right: 8px solid #4160a0;
    border-bottom: 8px solid transparent;
    border-top: 8px solid transparent;
    position: absolute;
    top: 12px;
    left: -9px;
}
[id*="accordion-"].accordion-style8 .panel-heading:after{
    border-right: 7px solid #fff;
    border-bottom: 7px solid transparent;
    border-top: 7px solid transparent;
    position: absolute;
    top: 13px;
    left: -8px;
}
[id*="accordion-"].accordion-style8 .panel-title a{
    display: block;
    padding: 10px 20px !important;
    border: none;
    font-size: 16px;
    font-weight: 600;
    color: #4160a0;
    position: relative;
}
[id*="accordion-"].accordion-style8 .panel-title a:before,
[id*="accordion-"].accordion-style8 .panel-title a.collapsed:before{
    content: "\f068";
    font-family: fontawesome;
    width: 35px;
    height: 35px;
    line-height: 35px;
    font-size: 15px;
    color: #4160a0;
    text-align: center;
    border: 1px solid #4160a0;
    position: absolute;
    top: 0;
    left: -50px;
    transition: all 0.5s ease 0s;
}
[id*="accordion-"].accordion-style8 .panel-title a.collapsed:before{ content: "\f067"; }
[id*="accordion-"].accordion-style8 .panel-body{
    padding: 0 15px 15px;
    border: none;
    font-size: 14px;
    color: #a2a2a2;
    line-height: 28px;
}
[id*="accordion-"].accordion-style8 .panel-body p{ margin-bottom: 0; }

[id*="accordion-"].accordion-style9 .panel{
    border-radius: 0;
    box-shadow: none;
}
[id*="accordion-"].accordion-style9 .panel-heading{
    padding: 0;
    border-radius: 0;
    background: #fff;
}
[id*="accordion-"].accordion-style9 .panel-title a{
    display: block;
    font-size: 16px;
    font-weight: bold;
    color: #4160a0;
    border: 1px solid #4160a0;
    text-transform: capitalize;
    padding: 16px 20px 16px 70px !important;
    position: relative;
    overflow: hidden;
    transition: all 0.3s linear 0s;
}
[id*="accordion-"].accordion-style9 .panel-title a.collapsed{
    color: #a2a2a2;
    border: 1px solid #a2a2a2;
}
[id*="accordion-"].accordion-style9 .panel-title a.collapsed:hover{
    color: #4160a0;
}
[id*="accordion-"].accordion-style9 .panel-title a:before,
[id*="accordion-"].accordion-style9 .panel-title a.collapsed:before{
    content: "\f0a7";
    font-family: FontAwesome;
    position: absolute;
    top: 0;
    left: 0;
    font-size: 16px;
    color: #fff;
    padding: 20px;
    text-align: center;
    background: #A4A1A0;
    transition: all 0.30s ease-in-out 0s;
}

[id*="accordion-"].accordion-style9 .panel-body{
    font-size: 14px;
    color: #a2a2a2;
    border-top: 0 none;
}
[id*="accordion-"].accordion-style10 .panel{
    border: none;
    box-shadow: none;
    border-radius: 0;
    margin-bottom: 15px;
}
[id*="accordion-"].accordion-style10 .panel-heading{
    padding: 0;
}
[id*="accordion-"].accordion-style10 .panel-title a{
    display: block;
    font-size: 16px;
    font-weight: bold;
    line-height: 24px;
    color: #fff !important;
    background: #4160a0;
    border: 2px solid #4160a0;
    padding: 15px 20px 15px 47px !important;
    position: relative;
    transition: all 0.5s ease 0s;
}
[id*="accordion-"].accordion-style10 .panel-title a.collapsed{
    background: #fff;
    border-color: #a2a2a2;
    color: #888 !important;
}
[id*="accordion-"].accordion-style10 .panel-title a:before{
    content: "\f106";
    font-family: 'FontAwesome';
    font-size: 18px;
    position: absolute;
    top: 30%;
    left: 20px;
    transition: all 0.3s ease 0s;
}
[id*="accordion-"].accordion-style10 .panel-title a.collapsed:before{
    content: "\f107";
}
[id*="accordion-"].accordion-style10 .panel-body{
    font-size: 14px;
    color: #a2a2a2;
    line-height: 25px;
    border: 2px solid #4160a0;
    border-top: none;
    padding: 14px 20px;
}



[id*="accordion-"] {
    position: relative;
}
[id*="accordion-"] .AddNewAccordionTab {
    font-family: arial;
    font-weight: 700;
    background-color: #292d33 !important;
    border-radius: 3px !important;
        line-height: 1;
    padding: 9px 12px;
     position: absolute;
    left: 50%;
    top:-4px;
    transform: translateX(-50%);
    display: none;
}
[id*="accordion-"] .AddNewAccordionTab:hover {
    background-color: #ed5153 !important;
}



[id*="accordion-"] .AddNewAccordionTab i,
[id*="accordion-"] .AddNewAccordionTab span {
    font-size: 13px;
    line-height: 1;
    vertical-align:middle;
    text-transform: none !important;
    color: #fff !important;
}
[id*="menuTabs-"] {
    position: relative;
}

[id*="menuTabs-"] .AddNewTab {
    position: absolute;
    left: 50%;
    top: -4px;
    transform: translateX(-50%);
    z-index: 9;
    font-size: 13px !important;
    font-family: arial;
    font-weight: 700;
    background: #292d33 !important;
    color: #fff !important;
    line-height: 1;
    padding: 10px 12px;
    height: auto;
    border-radius: 3px;
    text-transform: none !important;
    display: inline-block;
    margin-left: 10px;
    display: none;
}
[id*="menuTabs-"]  .AddNewTab:hover {
    background: #ed5153 !important;
    color: #fff !important;
}

.AccordionWidget:hover .AddNewAccordionTab{
    display:block;
    z-index: 99;
}

.TabWidget:hover .AddNewTab{
    display:block;
    z-index: 99;
}



[id*="menuTabs-"] .nav-tabs li a{
  font-size: 14px;
  text-transform: none;
  font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
}

[id*="menuTabs-"].tab-style1 .nav-tabs{
    position: relative;
    border-bottom: 0 none;
    background: #fff;
}

[id*="menuTabs-"].tab-style1 .nav-tabs li{
    text-align: center;
    margin-right: 0;
}
[id*="menuTabs-"].tab-style1 .nav-tabs li a{
    font-size: 15px;
    font-weight: 600;
    color: #999;
    padding: 15px 30px;
    background: #fff;
    margin-right: 0;
    border-radius: 0;
    border: 1px solid #ddd;
    border-right: none;
    border-bottom: 2px solid #ddd;
    position: relative;
    transition: all 0.5s ease 0s;
}
[id*="menuTabs-"].tab-style1 .nav-tabs li:last-child a,
[id*="menuTabs-"].tab-style1 .nav-tabs li:last-child.active a,
[id*="menuTabs-"].tab-style1 .nav-tabs li:last-child a:hover{
    border-right: 1px solid #ddd;
}
[id*="menuTabs-"].tab-style1 .nav-tabs li a:hover,
[id*="menuTabs-"].tab-style1 .nav-tabs li.active a{
    color: #4160a0;
    border-bottom: 2px solid #4160a0;
    border-right: none;
}
[id*="menuTabs-"].tab-style1 .tab-content{
    font-size: 14px;
    color: #6f6c6c;
    line-height: 26px;
    padding: 15px 20px;
}
[id*="menuTabs-"].tab-style1 .tab-content h3{
    font-size: 24px;
    color: #6f6c6c;
    margin-top: 0;
}
@media only screen and (max-width: 480px){
    [id*="menuTabs-"].tab-style1 .nav-tabs li{
        width: 100%;
        border-right: 1px solid #ddd;
        margin-bottom: 8px;
    }
}


[id*="menuTabs-"].tab-style2 .nav-tabs{
    display: inline-block;
    background: #f1efef;
    border-radius: 50px;
    border: none;
    padding: 6px;
}
[id*="menuTabs-"].tab-style2 .nav-tabs li{
    float: none;
    display: inline-block;
    position: relative;
}
[id*="menuTabs-"].tab-style2 .nav-tabs li a{
    font-size: 16px;
    font-weight: 700;
    background: none;
    color: #999;
    border: none;
    padding: 10px 15px;
    border-radius: 50px;
    transition: all 0.5s ease 0s;
}
[id*="menuTabs-"].tab-style2 .nav-tabs li a:hover{
    background: #4160a0;
    color: #fff !important;
    border: none;
}
[id*="menuTabs-"].tab-style2 .nav-tabs li.active a,
[id*="menuTabs-"].tab-style2 .nav-tabs li.active a:focus,
[id*="menuTabs-"].tab-style2 .nav-tabs li.active a:hover{
    border: none;
    background: #4160a0;
    color: #fff !important;
}
[id*="menuTabs-"].tab-style2 .tab-content{
    font-size: 14px;
    color: #686868;
    line-height: 25px;
    text-align: left;
    padding: 15px 20px;
}
[id*="menuTabs-"].tab-style2 .tab-content h3{
    font-size: 22px;
    color: #5b5a5a;
}
@media only screen and (max-width: 480px){
    [id*="menuTabs-"].tab-style2 .nav-tabs{
        border-radius: 10px;
    }
    [id*="menuTabs-"].tab-style2 .nav-tabs li{
        width: 100%;
        text-align: center;
        margin-bottom: 5px;
    }
}

[id*="menuTabs-"].tab-style3 .nav-tabs{
    position: relative;
    border-bottom: 0 none;
}
[id*="menuTabs-"].tab-style3 .nav-tabs li{
    text-align: center;
}

[id*="menuTabs-"].tab-style3 .nav-tabs li a{
    display: block;
    height: 70px;
    line-height: 65px;
    background: linear-gradient(165deg, transparent 29%, #4160a0 30%);
    font-size: 15px;
    font-weight: 600;
    color: #fff !important;
    margin-right: 0;
    border-radius: 0;
    border: none;
    position: relative;
    transition: all 0.5s ease 0s;
}

[id*="menuTabs-"].tab-style3 .nav-tabs li.active a,
[id*="menuTabs-"].tab-style3 .nav-tabs li a:hover{
    background: linear-gradient(165deg, transparent 29%, #eee 30%);
    border: none;
    color: #4160a0 !important;

}

[id*="menuTabs-"].tab-style3 .nav-tabs li a:before{
    content: "";
    height: 70px;
    line-height: 90px;
    border-bottom: 70px solid rgba(0, 0, 0, 0.1);
    border-right: 10px solid transparent;
    position: absolute;
    top: 0;
    left: 100%;
    z-index: 1;
}
[id*="menuTabs-"].tab-style3 .nav-tabs li:last-child a:before{
    border: none;
}
[id*="menuTabs-"].tab-style3 .tab-content{
    font-size: 14px;
    color: #6f6c6c;
    line-height: 26px;
    background: #eee;
    padding: 15px 20px;
}
[id*="menuTabs-"].tab-style3 .tab-content h3{
    font-size: 24px;
    color: #6f6c6c;
    margin-top: 0;
}
[id*="menuTabs-"].tab-style3 .tab-content p{
    margin-bottom: 0;
}
@media only screen and (max-width: 480px){
    [id*="menuTabs-"].tab-style3 .nav-tabs li{
        width: 100%;
        margin-bottom: 8px;
    }
    [id*="menuTabs-"].tab-style3 .nav-tabs li:last-child{
        margin-bottom: 0;
    }
    [id*="menuTabs-"].tab-style3 .nav-tabs li a:before{
        border: none;
    }
}

[id*="menuTabs-"].tab-style4 .nav-tabs{
    border:none;
    padding: 0 0 1px;
}
[id*="menuTabs-"].tab-style4 .nav-tabs li {
  margin-right: 0;
}
[id*="menuTabs-"].tab-style4 .nav-tabs li a{
    padding:15px 30px;
    background:#fff;
    color:#808080;
    position: relative;
    border:1px solid transparent;
    z-index: 1;
    transition: all 0.3s ease 0s;
    font-weight: 700;
}
[id*="menuTabs-"].tab-style4 .nav-tabs li a:hover{
    color:#fff !important;
}
[id*="menuTabs-"].tab-style4 .nav-tabs li a:before{
    content: "";
    width: 100%;
    height: 100%;
    border-radius: 4px 4px 0 0;
    position: absolute;
    top:0;
    left:0;
    opacity: 0;
    z-index: -1;
    transform: scale(0,0);
    transition:all 0.5s ease 0s;
}
[id*="menuTabs-"].tab-style4 .nav-tabs li a:hover:before{
    background: #4160a0;
    opacity: 1;
    transform: scale(1,1);
}
[id*="menuTabs-"].tab-style4 .nav-tabs li a i{
    display: block;
    font-size: 15px;
    text-align:center;
    margin-bottom:5px;
}
[id*="menuTabs-"].tab-style4 .nav-tabs li.active a,
[id*="menuTabs-"].tab-style4 .nav-tabs li.active a:focus,
[id*="menuTabs-"].tab-style4 .nav-tabs li.active a:hover{
    color:#fff !important;
    background: #4160a0;
    border-bottom:1px solid #fff;
}
[id*="menuTabs-"].tab-style4 .nav-tabs li.active a:hover:before{
    background: none;
}
[id*="menuTabs-"].tab-style4 .tab-content{
    padding: 15px 20px;
    background: #4160a0;
    color: #fff;
}
[id*="menuTabs-"].tab-style4 .tab-content h3{
    margin:0 0 10px 0;
    color:#fff;
    font-weight: bold;
    color: #fff;
}
[id*="menuTabs-"].tab-style4 .tab-content p{
    color:#fff;
    font-size: 14px;
}
@media only screen and (max-width: 600px){
    [id*="menuTabs-"].tab-style4 .nav-tabs li{
        width:100%;
        margin-bottom:0;
        text-align:center;
    }
}


[id*="menuTabs-"].tab-style5 .nav-tabs li a{
    background: transparent;
    border-radius: 0;
    font-size: 16px;
    border: none;
    color: #333;
    padding: 12px 22px;
}
[id*="menuTabs-"].tab-style5 .nav-tabs li a i{
    margin-right:10px;
    color:#4160a0;
}
[id*="menuTabs-"].tab-style5 .nav-tabs li:first-child a{
    border-bottom-left-radius:20px;
}
[id*="menuTabs-"].tab-style5 .nav-tabs li.active a,
[id*="menuTabs-"].tab-style5 .nav-tabs li.active a i{
    border: 0 none;
    background:#4160a0;
    color:#fff !important;
}
[id*="menuTabs-"].tab-style5 .nav-tabs li.active a:after{
    content: "";
    position: absolute;
    left: 45%;
    bottom: -14px;
    border: 7px solid transparent;
    border-top: 7px solid #4160a0;
}
[id*="menuTabs-"].tab-style5 .tab-content{
    padding: 15px 20px;
    color:#5a5c5d;
    font-size: 14px;
    line-height:24px;
    border-bottom:3px solid #4160a0;
}
@media only screen and (max-width: 480px) {
    [id*="menuTabs-"].tab-style5 .nav-tabs,
    [id*="menuTabs-"].tab-style5 .nav-tabs li{
        width:100%;
        background:transparent;
    }
    [id*="menuTabs-"].tab-style5 .nav-tabs li.active a{
        border-radius:10px 10px 0 0;
    }
    [id*="menuTabs-"].tab-style5 .nav-tabs li:first-child a{
        border-bottom-left-radius:0;
    }
    [id*="menuTabs-"].tab-style5 .nav-tabs li a{
        margin-bottom:10px;
        border:1px solid lightgray;
    }
    [id*="menuTabs-"].tab-style5 .nav-tabs li.active a:after{
        border:none;
    }
}

[id*="menuTabs-"].tab-style6 .nav-tabs li{
    border-right:1px solid #ddd;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li:last-child{
    border-right:0px solid #ddd;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li:first-child a{
    border-left:1px solid #ddd;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li a {
    color: #868686;
    background:#fff;
    border-radius:0;
    font-size:16px;
    margin-right:-15px;
    padding: 5.5px 30px;
    border-top:1px solid #d3d3d3;
    border-bottom: 1px solid #d3d3d3;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li:first-child a{
    border-radius: 5px 0 0 5px;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li:last-child a{
    border-radius: 0 5px 5px 0;
    border-right:1px solid #d3d3d3;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li a:hover{
    background:#eee;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li a:hover:before{
    border-left: 15px solid #eee;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li.active a:after,
[id*="menuTabs-"].tab-style6 .nav-tabs li a:after{
    content:"";
    border-left: 17px solid #4160a0;
    border-top: 17px solid transparent;
    border-bottom: 17px solid transparent;
    position: absolute;
    top: 0px;
    right: -15px;
    z-index:1;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li a:after{
    border-left: 17px solid #d3d3d3;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li.active a:before{
    border-left: 17px solid #4160a0;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li a:before{
    border-bottom: 15px solid rgba(0, 0, 0, 0);
    border-left: 15px solid #fff;
    border-top: 15px solid rgba(0, 0, 0, 0);
    content: "";
    position: absolute;
    right: -13px;
    top: 2px;
    z-index: 2;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li.active > a,
[id*="menuTabs-"].tab-style6 .nav-tabs > li.active > a:focus,
[id*="menuTabs-"].tab-style6 .nav-tabs > li.active > a:hover {
    border: none;
    color:#fff !important;
    background:#4160a0;
    border-top:1px solid #d3d3d3;
    border-bottom: 1px solid #d3d3d3;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li:last-child.active a:after,
[id*="menuTabs-"].tab-style6 .nav-tabs li:last-child a:after{
    border: none;
}
[id*="menuTabs-"].tab-style6 .nav-tabs li:last-child a:after,
[id*="menuTabs-"].tab-style6 .nav-tabs li:last-child a:hover:before,
[id*="menuTabs-"].tab-style6 .nav-tabs li:last-child.active a:before,
[id*="menuTabs-"].tab-style6 .nav-tabs li:last-child a:before{
    border-left: none;
}
[id*="menuTabs-"].tab-style6 .tab-content{
    padding: 15px 20px;
    color:#5a5c5d;
    font-size: 14px;
    border: 1px solid #fff;
}

[id*="menuTabs-"].tab-style7 .nav-tabs{
    padding-left: 15px;
    border-bottom: 4px solid #4160a0;
}
[id*="menuTabs-"].tab-style7 .nav-tabs li a{
    color: #fff !important;
    padding: 10px 20px;
    margin-right: 10px;
    background: #4160a0;
    text-shadow: 1px 1px 2px #000;
    border: none;
    border-radius: 0;
    opacity: 0.5;
    position: relative;
    transition: all 0.3s ease 0s;
}
[id*="menuTabs-"].tab-style7 .nav-tabs li a:hover{
    background: #4160a0;
    opacity: 0.8;
}
[id*="menuTabs-"].tab-style7 .nav-tabs li.active a{
    opacity: 1;
}
[id*="menuTabs-"].tab-style7 .nav-tabs li.active a,
[id*="menuTabs-"].tab-style7 .nav-tabs li.active a:hover,
[id*="menuTabs-"].tab-style7 .nav-tabs li.active a:focus{
    color: #fff !important;
    background: #4160a0;
    border: none;
    border-radius: 0;
}
[id*="menuTabs-"].tab-style7 .nav-tabs li a:before,
[id*="menuTabs-"].tab-style7 .nav-tabs li a:after{
    content: "";
    border-top: 42px solid transparent;
    position: absolute;
    top: -2px;
}
[id*="menuTabs-"].tab-style7 .nav-tabs li a:before{
    border-right: 15px solid #4160a0;
    left: -15px;
}
[id*="menuTabs-"].tab-style7 .nav-tabs li a:after{
    border-left: 15px solid #4160a0;
    right: -15px;
}
[id*="menuTabs-"].tab-style7 .nav-tabs li a i,
[id*="menuTabs-"].tab-style7 .nav-tabs li.active a i{
    display: inline-block;
    padding-right: 5px;
    font-size: 15px;
    text-shadow: none;
}
[id*="menuTabs-"].tab-style7 .nav-tabs li a span{
    display: inline-block;
    font-size: 14px;
    letter-spacing: -9px;
    opacity: 0;
    transition: all 0.3s ease 0s;
}
[id*="menuTabs-"].tab-style7 .nav-tabs li a:hover span,
[id*="menuTabs-"].tab-style7 .nav-tabs li.active a span{
    letter-spacing: 1px;
    opacity: 1;
    transition: all 0.3s ease 0s;
}
[id*="menuTabs-"].tab-style7 .tab-content{
    padding: 15px 20px;
    background: #fff;
    font-size: 16px;
    color: #6c6c6c;
    line-height: 25px;
}
[id*="menuTabs-"].tab-style7 .tab-content h3{
    font-size: 24px;
    margin-top: 0;
}
@media only screen and (max-width: 479px){
    [id*="menuTabs-"].tab-style7 .nav-tabs li{
        width: 100%;
        margin-bottom: 5px;
        text-align: center;
    }
    [id*="menuTabs-"].tab-style7 .nav-tabs li a span{
        letter-spacing: 1px;
        opacity: 1;
    }
}

[id*="menuTabs-"].tab-style8 .nav-tabs{
    border-bottom: none;
    position: relative;
}
[id*="menuTabs-"].tab-style8 .nav-tabs li{
    margin-right: 10px;
    z-index: 1;
}
[id*="menuTabs-"].tab-style8 .nav-tabs li:after{
    content: "";
    width: 100%;
    border: 1px solid #ccc6c6;
    position: absolute;
    top: 50%;
    right: -60%;
    z-index: -1;
}
[id*="menuTabs-"].tab-style8 .nav-tabs li:last-child:after{
    border: none;
}
[id*="menuTabs-"].tab-style8 .nav-tabs li a{
    display: block;
    padding: 10px 20px;
    background: #fff;
    font-size: 15px;
    font-weight: 600;
    color: #4160a0;
    border-radius: 0;
    margin-right: 0;
    border: 2px solid #4160a0;
    position: relative;
    overflow: hidden;
    z-index: 1;
    transition: all 0.3s ease 0s;
}
[id*="menuTabs-"].tab-style8 .nav-tabs li.active a,
[id*="menuTabs-"].tab-style8 .nav-tabs li a:hover{
    color: #fff !important;
    border: 2px solid #4160a0;
}
[id*="menuTabs-"].tab-style8 .nav-tabs li a:after{
    content: "";
    display: block;
    width: 100%;
    height: 0;
    position: absolute;
    top: 0;
    left: 0;
    z-index: -1;
    transition: all 0.3s ease 0s;
}
[id*="menuTabs-"].tab-style8 .nav-tabs li.active a:after,
[id*="menuTabs-"].tab-style8 .nav-tabs li a:hover:after{
    height: 100%;
    background: #4160a0;
}
[id*="menuTabs-"].tab-style8 .tab-content{
    padding: 15px 20px;
    margin-top: 0;
    font-size: 14px;
    color: #999;
    line-height: 26px;
}
[id*="menuTabs-"].tab-style8 .tab-content h3{
    font-size: 24px;
    margin-top: 0;
}
@media only screen and (max-width: 767px){
    [id*="menuTabs-"].tab-style8 .nav-tabs li{ margin: 0 25px 0 0; }
}
@media only screen and (max-width: 479px){
    [id*="menuTabs-"].tab-style8 .nav-tabs li{
        width: 100%;
        text-align: center;
        margin: 0 0 10px 0;
    }
    [id*="menuTabs-"].tab-style8 .nav-tabs li:after{
        width: 0;
        height: 100%;
        top: auto;
        bottom: -60%;
        right: 50%;
    }
}

[id*="menuTabs-"].tab-style9{
    text-align: left;
    position: relative;
    z-index: 1;
}
[id*="menuTabs-"].tab-style9:before{
    content: "";
    width: 100%;
    height: 1px;
    background: #cdcdcd;
    position: absolute;
    top: 22px;
    left: 0;
    z-index: -1;
}
[id*="menuTabs-"].tab-style9 .nav-tabs{
    display: inline-block;
    border: 1px solid #cdcdcd;
    background: #f9f9f9;
    border-radius: 50px;
    text-align: center;
    padding: 0 20px;
}
[id*="menuTabs-"].tab-style9 .nav-tabs li{
    float: none;
    display: inline-block;
    position: relative;
}
[id*="menuTabs-"].tab-style9 .nav-tabs li:after{
    content: "";
    width: 1px;
    height: 30px;
    background: #c4c4c4;
    position: absolute;
    top: 50%;
    right: 0;
    font-size: 20px;
    transform: rotate(15deg) translateY(-50%);
}
[id*="menuTabs-"].tab-style9 .nav-tabs li:last-child:after{
    width: 0;
    height: 0;
}
[id*="menuTabs-"].tab-style9 .nav-tabs li a{
    font-size: 16px;
    font-weight: 700;
    color: #999;
    border: none;
    background-color: transparent;
}
[id*="menuTabs-"].tab-style9 .nav-tabs li a:hover{
    background: transparent;
    color: #4160a0;
    border: none;
}
[id*="menuTabs-"].tab-style9 .nav-tabs li.active a,
[id*="menuTabs-"].tab-style9 .nav-tabs li.active a:focus,
[id*="menuTabs-"].tab-style9 .nav-tabs li.active a:hover{
    border: none;
    background: none;
    color: #4160a0 !important;
}
[id*="menuTabs-"].tab-style9 .tab-content{
    font-size: 14px;
    color: #686868;
    text-align: left;
    padding: 15px 20px;
}
[id*="menuTabs-"].tab-style9 .tab-content h3{
    font-size: 22px;
    color: #232323;
}
@media only screen and (max-width: 480px){
    [id*="menuTabs-"].tab-style9:before{
        width: 0;
        height: 0;
    }
    [id*="menuTabs-"].tab-style9 .nav-tabs{ padding: 0; }
    [id*="menuTabs-"].tab-style9 .nav-tabs li{
        width: 100%;
        text-align: center;
        border-bottom: 1px solid #e9e9e9;
    }
    [id*="menuTabs-"].tab-style9 .nav-tabs li:last-child{
        border-bottom: none;
    }
    [id*="menuTabs-"].tab-style9 .nav-tabs li:after{
        width: 0;
        height: 0;
    }
}

[id*="menuTabs-"].tab-style10 .nav-tabs{    
    border-bottom: 0 none;
}
[id*="menuTabs-"].tab-style10 .nav-tabs li{
    /*width: 25%;*/
}
[id*="menuTabs-"].tab-style10 .nav-tabs li a{
    display: block;
    font-size: 16px;
    color: #888;
    text-align: center;
    border: none;
    padding: 14px;
    background: #eee;
    border-radius: 0;
    margin: 0;
    position: relative;
    transition: all 0.3s ease 0s;
    font-weight: 700;
}
[id*="menuTabs-"].tab-style10 .nav-tabs li a:hover{
    background: #4160a0;
    color: #fff !important;
}
[id*="menuTabs-"].tab-style10 .nav-tabs li.active a,
[id*="menuTabs-"].tab-style10 .nav-tabs li.active a:focus,
[id*="menuTabs-"].tab-style10 .nav-tabs li.active a:hover{
    border: none;
    background: #4160a0;
    color: #fff !important;
    transition: all 0.20s ease 0s;
}
[id*="menuTabs-"].tab-style10 .nav-tabs li.active a:after{
    content: "";
    position: absolute;
    bottom: -30px;
    left: 50%;
    margin-left: -10px;
    border: 15px solid transparent;
    border-top-color: #4160a0;
}
[id*="menuTabs-"].tab-style10 .tab-content{
    font-size: 14px;
    color: #888;
    background: #eee;
    line-height: 25px;
    padding: 20px;
}
[id*="menuTabs-"].tab-style10 .tab-content h3{
    font-size: 20px;
    color: #4160a0;
}
@media only screen and (max-width: 480px){
    [id*="menuTabs-"].tab-style10 .nav-tabs li{
        width: 100%;
        margin-bottom: 2px;
    }
    [id*="menuTabs-"].tab-style10 .nav-tabs li.active a:after{
        border: none;
    }
}


[id*="menuTabs-popup"].tab-style6 .nav-tabs li {
  margin-right: 0;
}
[id*="menuTabs-popup"].tab-style6 .nav-tabs li a:before {
  right: -15px !important;
  top: 4px !important;
}

[id*="menuTabs-popup"].tab-style6 .nav-tabs li a:after {
  top: 3px !important;
  right: -17px !important;
}

[id*="menuTabs-"] .AddNewTab {
    background-color: #292d33 !important;
    color: #fff !important;

}
[id*="menuTabs-"] .AddNewTab:hover {
    background-color: #ed5153 !important;
}
/* ----------- skill-widget-style-1 ------------------------------------------------------------ */
    .skill-widget.skill-widget-style-1 .skill-widget-heading {
        margin-bottom: 30px;
    }

    .skill-widget.skill-widget-style-1 .skill-text-block {
        position: absolute;
        left: 0;
        top: -30px;
        font-weight: 600;
        letter-spacing: 1px;
    }
    .skill-widget.skill-widget-style-1 .skills-percentage-block {
         font-size: 11px;
        color: #333 !important;
        font-weight: 600;
        position: absolute;
        top: -6px;
        right: -15px;
        font-family: arial;
    }
    .skill-widget.skill-widget-style-1 .progress-bar:before {
        content: '';
        width: 39px;
        height: 20px;
        display: block;
        border-radius: 1000px;
        border:1px solid #fff;
        background-color: inherit;
        box-shadow: 0px 2px 7px #6b6b6b;
        position: absolute;
        right: -22px;
        top: -6px;
        background-color: #fff;
    }

    .skill-widget.skill-widget-style-1 .progress-wrapper {
        position: relative;
        padding-top: 25px;
    }
    .skill-widget.skill-widget-style-1 .progress {
        height: 10px;
        border-radius: 0;
            overflow: visible;
            margin-bottom: 30px
    }
    .skill-widget.skill-widget-style-1 .progress-bar {
        position: relative;
    }


    /* ----------- skill-widget-style-2 ------------------------------------------------------------ */
    .skill-widget.skill-widget-style-2 .skill-widget-heading {
        margin-bottom: 20px;
    }

    .skill-widget.skill-widget-style-2 .skill-text-block {
        text-transform: uppercase;
        color: #797979;
        font-size: 13px;
        position: absolute;
        left: 0;
        top: -0;
        font-weight: 600;
        letter-spacing: 1px;
    }
    .skill-widget.skill-widget-style-2 .skills-percentage-block {
         font-size: 13px;
        color: #333;
        font-weight: 600;
        position: absolute;
        top: 0;
        right: 0;
        font-family: arial;
    }


    .skill-widget.skill-widget-style-2 .progress-wrapper {
        position: relative;
        padding-top: 25px;
    }
    .skill-widget.skill-widget-style-2 .progress {
        background-color: #dcdcdc;
        height: 5px;
        border-radius: 0;
            overflow: visible;
            margin-bottom: 30px
    }

    /* ----------- skill-widget-style-3 ------------------------------------------------------------ */
    .skill-widget.skill-widget-style-3 {
        width: 355px;
        margin-left: auto;
    margin-right: auto;
    }
    .skill-widget.skill-widget-style-3 .skill-widget-heading {
        margin-bottom: 20px;
    }

    .skill-widget.skill-widget-style-3 .skill-text-block {
        text-transform: uppercase;
        color: #797979;
        font-size: 13px;
        position: absolute;
        left: 7px;
        bottom: 0;
        font-weight: 600;
        letter-spacing: 1px;
    }
    .skill-widget.skill-widget-style-3 .skills-percentage-block {
         display: none;
         font-size: 13px;
        color: #333;
        font-weight: 600;
        position: absolute;
        top: 0;
        right: 0;
        font-family: arial;
    }


    .skill-widget.skill-widget-style-3 .progress-wrapper {
        position: relative;
        padding-bottom: 24px;
        margin-bottom: 30px;
    }
    .skill-widget.skill-widget-style-3 .progress {
        background-color: #ffffff;
        height: 14px;
        overflow: visible;
        margin-bottom: 0;
        border-radius: 1000px;
        padding: 2px;
        border: 1px solid #ddd;
    }
    .skill-widget.skill-widget-style-3  .progress-bar {
            border-radius: 1000px;
    }


    /* ----------- skill-widget-style-4 ------------------------------------------------------------ */
    .skill-widget.skill-widget-style-4 {
        max-width: 730px;
        margin-left: auto;
        margin-right: auto;        
        display: -webkit-flex; /* Safari */
        -webkit-flex-wrap: wrap; /* Safari 6.1+ */
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
    }
    .skill-widget.skill-widget-style-4 .skill-widget-heading {
        margin-bottom: 40px;
    }

    .skill-widget.skill-widget-style-4 .skill-text-block {
        text-transform: uppercase;
        color: #333;
        font-size: 14px;
        position: absolute;
        left: 0;
        bottom: 0;
        font-weight: 700;
        letter-spacing: 1px;
    }
    .skill-widget.skill-widget-style-4 .skills-percentage-block {
         font-size: 26px;
         color: #333;
         font-weight: 600;
         position: absolute;
         top: 0;
         left: 0;
         font-family: arial;
    }


    .skill-widget.skill-widget-style-4 .progress-wrapper {
        position: relative;
        padding-bottom: 1px;
        padding-top: 29px;
        margin-bottom: 22px;
        display: inline-block;
        width: 100px;
        margin-right: 25px;
    }
    .skill-widget.skill-widget-style-4 .progress-wrapper:last-child {
        margin-right: 0;
    }
    .skill-widget.skill-widget-style-4 .progress {
        background-color: #dcdcdc;
        height: 5px;
        border-radius: 0;
        overflow: visible;
    }

    /* ----------- skill-widget- light & dark theme ------------------------------------------------------------ */
    .widget-section[class*="theme-light-color"] .skills-percentage-block,
    .widget-section[class*="theme-light-color"] .skill-text-block {
        color: #333;
    }

    .widget-section[class*="theme-dark-color"] .skills-percentage-block,
    .widget-section[class*="theme-dark-color"] .skill-text-block {
        color: #fff;
    }

.pb-alignclass-0 {float:left;}
.pb-alignclass-1 {float:none; margin-left:auto; margin-right:auto;}
.pb-alignclass-2 {float:right;}
.BlogPostWidget .blog-widgets {
	/* padding-top: 100px; */
	padding-bottom: 100px;
	position: relative;
	z-index: 10;
	/* background: #eee; */
}
.BlogPostWidget .blog-widgets.blog-page-bg {
	background-size: cover;
	-webkit-background-size: cover;
	-moz-background-size: cover;
	-o-background-size: cover;
	background-repeat: no-repeat;
	background-position: center center;
	min-height:400px;
}
.BlogPostWidget .blog-widgets.blog-page-bg::before {
	content: "";
	background-color: rgba(0, 0, 0, 0.8);
	width: 100%;
	height: 100%;
	position: absolute;
	top: 0;
	left: 0;
}
.BlogPostWidget .blog-widgets .blog-page-title {
	position: absolute;
	top: 50%;
	width: 100%;
	left: 0;
	z-index: 15;
	-webkit-transform: translate(0%, -50%);
	-moz-transform: translate(0%, -50%);
	-ms-transform: translate(0%, -50%);
	-o-transform: translate(0%, -50%);
	transform: translate(0%, -50%);
}
.BlogPostWidget .blog-widgets .blog-page-title h1 {
	font-size: 50px;
	line-height: 1.5em;
	font-weight: 700;
	margin: 0;
}
.BlogPostWidget .blog-widgets .blog-page-title h1, .blog-page-title h2, .blog-page-title h3, .blog-page-title h4, .blog-page-title h5, .blog-page-title h6, .blog-page-title p {
	color: #fff;
	text-align: center;
}
.blog-post {
}
.blog-image {
	overflow: hidden;
	position: relative;
	z-index: 10;
}
.blog-image img {
	-webkit-transition: all .5s ease;
	transition: all .5s ease;
	z-index: 0;
	-webkit-backface-visibility: hidden;
	width:100%;
}
.blog-post:hover .blog-image img {
	-webkit-transform: scale(1.1);
	transform: scale(1.1);
}
.blog-content {
	padding: 40px;
	background-color: #fff;
	transition: all 0.2s ease;
	border: 1px solid #eeeeee;
}
.blog-content h3 {
	font-size: 16px;
	margin-top: 0;
	margin-bottom: 10px;
	color: #000;
	font-weight: 700;
	line-height:1.3;
}
.blog-content h6 {
	color: #000;
	font-size: 14px;
	margin-top: 0;
}
.blog-content a {
	color: #000;
}
.blog-content a:hover {
	color: #000;
	text-decoration: none;
}
.blog-content p {
	margin-top: 20px;
	color: #bdbdbd;
	font-size: 12px;
}
.blog-content .extras-wrap {
	padding: 0px 14px 0px 0px;
	display: inline-block;
	font-size: 14px;
	color: #9e9e9e;
}
.blog-content .extras-wrap i {
	position: relative;
	top: 1px;
	padding: 0px 5px 0px 0px;
	font-size: 14px;
}
.blog-content a.readmore {
	letter-spacing: 2px;
	color: #212121;
	font-size: 12px;
	text-transform: uppercase;
	font-weight: 700;
}
.blog-content a:hover.readmore {
	color: #000;
}
.blog-content a.readmore > span {
	display: inline-block;
	vertical-align: middle;
}
.blog-content hr {
	border-top: 1px solid #e0e0e0;
	width: 100%;
	height: 1px;
}
/************ BLOG-WIDGET-2 (START) ************/
.BlogPostWidget .blog-widgets.blog-widget-2.blog-page-bg {
    background-size: cover;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
    min-height: 400px;
}
.BlogPostWidget .blog-widgets.blog-widget-2.blog-page-bg::before {
	background-color: rgba(255, 255, 255, 0.5);
}
.BlogPostWidget .blog-widgets.blog-widget-2.blog-page-bg .blog-page-title {
	left: 4%;
	width: 50%;
}
.BlogPostWidget .blog-widgets.blog-widget-2 .blog-page-title h1, .BlogPostWidget .blog-widgets.blog-widget-2  .blog-page-title h2, .BlogPostWidget .blog-widgets.blog-widget-2  .blog-page-title h3, .BlogPostWidget .blog-widgets.blog-widget-2 .blog-page-title h4, .BlogPostWidget .blog-widgets.blog-widget-2  .blog-page-title h5, .BlogPostWidget .blog-widgets.blog-widget-2  .blog-page-title h6, .BlogPostWidget .blog-widgets.blog-widget-2  .blog-page-title p {
    color: #000;
    text-align: left;
}
.BlogPostWidget .blog-widgets.blog-widget-2 {
    background: transparent;
}
 .BlogPostWidget .blog-widgets.blog-widget-2 .blog-content {
    padding: 0;
    background: transparent;
    border: transparent;
    margin: 20px 0 0 0;
}
.BlogPostWidget .blog-widgets.blog-widget-2 .blog-content span.categories {
    margin-bottom: 10px;
    display: block;
}
.BlogPostWidget .blog-widgets.blog-widget-2 .blog-content h3 {
    font-size: 18px;
}
.BlogPostWidget .blog-widgets.blog-widget-2 .blog-content p {
    color: #000;
}
.BlogPostWidget .blog-widgets.blog-widget-2 .blog-content h6 {
    font-size: 12px;
    color: #848484;
}
/************ BLOG-WIDGET-2 (END) ************/

/************ BLOG-WIDGET-3 (StART) ************/
.BlogPostWidget .blog-widgets.blog-widget-3 {
    background: transparent;
}
.BlogPostWidget .blog-widgets.blog-widget-3 .blog-image {
    min-height: 280px;
    height: 380px;
}
.BlogPostWidget .blog-widgets.blog-widget-3 .blog-content {
    margin: 30px 0;
    background: transparent;
    border: 0;
    padding: 0;
}
.BlogPostWidget .blog-widgets.blog-widget-3 .blog-content h3 {
    font-size: 30px;
}
.BlogPostWidget .blog-widgets.blog-widget-3 .blog-content p {
    font-size: 16px;
	color: #000;
}
.BlogPostWidget .blog-widgets.blog-widget-3 .blog-content h6 {
    font-size: 14px;
}
.BlogPostWidget .blog-widgets.blog-widget-3 .blog-content a.readmore {
    background: #000;
    color: #fff;
    display: inline-block;
    padding: 8px 20px;
    margin-top: 10px;
}
.BlogPostWidget .blog-widgets.blog-widget-3 .blog-content span.categories {
    margin-bottom: 10px;
    display: inline-block;
    font-size: 16px;
}

/************ BLOG-WIDGET-3 (END) ************/

/************ BLOG-WIDGET-4 (START) ************/
.BlogPostWidget .blog-widgets.blog-widget-4 .blog-image {
    border: 10px solid #fff;
    border-bottom: none;
}
.BlogPostWidget .blog-widgets.blog-widget-4 .blog-content {
    border: 0;
    padding: 20px;
    text-align: center;
}
/************ BLOG-WIDGET-4 (END) ************/

.BlogPostWidget .blog-widgets.blog-widget-5 .blog-content {
    padding: 60px;
    background-color: #fff;
    transition: all 0.2s ease;
    border: 1px solid #eeeeee;
    height: 380px;
	text-align: center;
}
.BlogPostWidget .blog-widgets.blog-widget-5 .blog-content h3 {
    font-size: 20px;
    margin-top: 0;
    margin-bottom: 10px;
    color: #000;
    font-weight: 700;
    line-height: 1.3;
}
.BlogPostWidget .blog-widgets.blog-widget-5 .blog-content h6 {
    color: #000;
    font-size: 14px;
    margin-top: 0;
}

.BlogPostWidget .blog-widgets.blog-widget-5 .blog-content p {
    margin-top: 20px;
    color: #bdbdbd;
    font-size: 14px;
}
.BlogPostWidget .blog-widgets.blog-widget-5 a.readmore {
    letter-spacing: 2px;
    color: #212121;
    font-size: 12px;
    text-transform: uppercase;
    font-weight: 700;
}
.BlogPostWidget .blog-widgets.blog-widget-5 .pad-0 {
    padding: 0;
}
.row.add-top {
    margin-top: 50px;
}


/********** BLOG DETAIL CSS **********/
.BlogPostWidget .blog-widgets.blog-detail-bg {
    padding: 0;
    min-height: 350px;
    height: 450px;
    background-size: cover;
    background-position: center center;
}
.BlogPostWidget .blog-widgets.blog-detail-bg .blog-detail-title {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
}
.BlogPostWidget .blog-widgets.blog-detail-bg .blog-detail-title h1 {
    font-size: 50px;
    font-weight: bold;
}
.BlogPostWidget .blog-widgets.blog-detail-bg .blog-detail-title h4 {
    margin-left: 4px;
}
.BlogPostWidget .blog-widgets.blog-detail-1 {
    background: transparent;
    padding: 60px 0;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .blog-detail-post {
    margin: 0;
    padding: 0;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .blog-detail-post .blog-detail-content {
    padding: 20px;
    width: 100%;
    float: left;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .blog-detail-post .blog-detail-content h6 {
    font-size: 14px;
    color: #999;
    margin-top: 0;
    font-weight: normal;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .blog-detail-post h1 {
    font-size: 30px;
    text-transform: capitalize;
    font-weight: bold;
    margin-top: 0;
    font-family: 'Open Sans', sans-serif;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .blog-detail-post h5 {
    margin-top: 0;
    font-size: 16px;
    font-weight: 600;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .blog-detail-post .blog-detail-content p {
    margin-top: 0;
    margin-bottom: 10px;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .blog-detail-post .blog-detail-content .block-quote {
}
.BlogPostWidget .blog-widgets.blog-detail-1 .blog-detail-post .blog-detail-content .block-quote p {
    font-size: 16px;
    font-style: italic;
    line-height: 1.5;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .blog-detail-post .blog-detail-content .block-quote p i.fa {
    font-size: 21px;
    padding-right: 5px;
    color: #999;
    font-style: italic;
}
.author-info.clearfix {
    margin: 0;
    padding: 0 0 20px 0;
}
.author-img {
    height: 70px;
    width: 70px;
    margin-right: 10px;
    border: 3px solid #eee;
    border-radius: 50px;
}
.author-img img {
    width: 100%;
	border-radius: 50%;
}
.author-info a {
    font-size: 14px;
    color: #000;
    font-weight: 600;
    display: inline-block;
    padding-top: 22px;
}
.BlogPostWidget blockquote {
    margin: 40px 0;
    background-color: #f6f6f6;
    padding: 30px;
    position: relative;
    border-left-color: #999;
    font-size: inherit;
    line-height: 1.7;
}
.BlogPostWidget blockquote p {
    color: #888;
}
.blog-detail-share {
    width: 100%;
    margin: 0;
    padding: 10px 0;
    border-top: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
    float: left;
}
.blog-detail-share h3 {
    display: inline-block;
    margin: 0;
    font-size: 20px;
    font-weight: 600;
}
.blog-detail-share ul {
    padding: 0;
    margin: 0;
    list-style: none;
    float: right;
}
.blog-detail-share ul li {
    display: inline-block;
    margin-right: 10px;
    width: 30px;
    height: 30px;
    background: #999;
    border-radius: 20px;
}
.blog-detail-share ul li a {
    font-size: 16px;
    text-align: center;
    display: block;
    line-height: 30px;
}
.blog-detail-share ul li a i.fa {
    font-size: 12px;
    color: #fff;
}

/***** popular-post *****/
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget {
    margin: 0;
    padding: 0;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget h2 {
    font-size: 20px;
    font-weight: bold;
    margin-top: 20px;
    margin-bottom: 20px;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post {
    margin: 0;
    padding: 0;
    background-color: #fff;
    border: 1px solid #efefef;
    border-radius: 0;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post:hover {
    box-shadow: 6px 6px 25px rgba(0, 0, 0, 0.15);
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post-image {
    border: 2px solid #fff;
    border-bottom: 0;
    max-height: 230px;
    overflow: hidden;
    height: 100%;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post-image img {
    width: 100%;
    max-height: 230px;
    height: 100%;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post-content {
    margin: 0;
    padding: 20px;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post-content h3 {
    text-align: left;
    margin-top: 0;
    margin-bottom: 10px;
}
.popular-post .popular-post-content h3 a {
    text-decoration: none;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post-content h3 a {
    color: #000;
    font-size: 16px;
    font-weight: bold;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post-content .popular-post-info {
    margin: 0;
    padding: 0;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post-content .popular-post-info span {
    font-size: 12px;
    font-weight: 600;
    color: #999;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post-content .popular-post-info span a {
    color: #000;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post p {
    font-size: 12px;
    color: #000;
    line-height: 1.5;
    text-align: left;
}
.BlogPostWidget .blog-widgets.blog-detail-1 .popular-post-widget .popular-post p a.readmore-btn {
    background: #999;
    color: #fff;
    padding: 4px 10px;
    font-size: 12px;
    font-weight: 600;
    border-radius: 20px;
    display: inline-block;
    margin-top: 5px;
}

.blog-widget-5 .blog-image {    
    max-width: 570px;
    max-height: 380px;
}.bg-img-6  { background-image: url('//static.sitemantic.com/webbuilder/images/bg/img-6.jpg') ;  background-position: center center; }
.bg-img-7  { background-image: url('//static.sitemantic.com/webbuilder/images/bg/img-7.jpg') ;  background-position: center center; }
.bg-img-8  { background-image: url('//static.sitemantic.com/webbuilder/images/bg/img-8.jpg') ;  background-position: center center; }
.bg-img-9  { background-image: url('//static.sitemantic.com/webbuilder/images/bg/img-9.jpg') ;  background-position: center center; }
.bg-img-10 { background-image: url('//static.sitemantic.com/webbuilder/images/bg/img-10.jpg') ;  background-position: center center; }
.bg-img-11 { background-image: url('//static.sitemantic.com/webbuilder/images/bg/img-11.jpg') ;  background-position: center center; }
/* ----------- START social-widget ------------------------------------------------------------ */



.pb-0 { padding-bottom: 0; }

.widget-section.widget-social .section-title p {
    font-size: 14px;
    margin-bottom: 15px;
}


.ifram-social-style-01 {
    border: 20px solid rgba(255, 255, 255, 0.40);
    border-radius: 20px 20px 0 0;
    border-bottom: 0;
    max-width: 390px;
    margin-left: auto;
    margin-right: auto;
}

.widget-section-social-02 {
    padding-top: 125px;
}
.widget-section-social-02 .section-title{
    max-width: 370px;
    margin-top: 15px;
}

.ifram-social-style-02 {
    position: relative;
    box-shadow: 0 5px 20px 0px rgba(0, 0, 0, 0.35);
    max-width: 360px;
    width: 100%;
    margin-left: auto;
    margin-right: auto;
}
.ifram-social-style-02 .bird-img {
    position: absolute;
    bottom: 97%;
    right: 0;
}



.ifram-social-style-03 {
    position: relative;
    border: 20px solid #2fc0f1;
    border-radius: 20px;
    box-shadow: 0 5px 50px 0px rgba(0, 0, 0, 0.35);
    max-width: 360px;
    width: 100%;
}
.ifram-social-style-03:after {
    left: 105%;
    top: 92%;
    border: solid transparent;
    content: " ";
    height: 0;
    width: 0;
    position: absolute;
    pointer-events: none;
    border-color: rgba(136, 183, 213, 0);
    border-left-color: inherit;
    border-width: 30px;
    margin-top: -30px;
}
.widget-section-social-03 {
    overflow: hidden;
}
.widget-section-social-03  .section-title {
    text-align: left;
    max-width: 350px;
    display: inline-block;
}
.ifram-social-style-03  .bird-img {
    display: inline-block;
    position: absolute;
    left: 115%;
    bottom: -120px;
}


.widget-section-social-04 .section-title {
    text-align: left;
    max-width: 350px;
    display: inline-block;
}
.ifram-social-style-04 {
    border: 7px solid #fff;
    border-radius: 20px;
    overflow: hidden;
    background-color: #fff;
    max-width: 340px;

}


.widget-section-social-05 {
    overflow: hidden;
}
.ifram-social-style-05 {
    position: relative;
    background: url("//static.sitemantic.com/webbuilder/images/element/mobile.png") no-repeat 0 0;
    padding: 103px 25px 0 25px;
    max-width: 399px;
    margin-left: auto;
    margin-right: auto;
}
.ifram-social-style-05 .emoji-1 {
    position: absolute;
    right: 105%;
    top: -120px;
}

.ifram-social-style-05 .emoji-2 {
    position: absolute;
    left: 105%;
    top: -120px;
}


.ifram-social-style-06 {
    border: 2px solid #646869;
    display: inline-block;
    border-radius: 10px;
    overflow: hidden;
    max-width: 340px;
    width: 100%;
    background-color: #fff;
}

.ifram-social-style-05 .fb-page {
    max-width: 340px;
    width: 100%;
}
@media (max-width: 767px) {
    .widget-section.widget-social .section-title{
        margin-left: auto;
        margin-right: auto;
        max-width: none;
        text-align: center;
    }
    .ifram-social-style-04,
    .ifram-social-style-03 {
        margin-left: auto;
        margin-right: auto;
    }
}
@media (max-width: 450px) {
    .ifram-social-style-05 {
        padding: 0;
        background-image: none;
    }
}
/* ===== New Templates Widgets Theme Colors Start  =====*/

/*== Theme-Dark == */
.theme-dark-color-17 {background-color: #f9b522;}
.theme-dark-color-18 {background-color: #1e272e;}
.theme-dark-color-19 {background-color: #2b3d4f;}
.theme-dark-color-20 {background-color: #31609f;}
.theme-dark-color-21 {background-color: #151515;}
.theme-dark-color-22 {background-color: #669900;}
.theme-dark-color-23 {background-color: #15082e;}
.theme-dark-color-24 {background-color: #004d40;}
.theme-dark-color-25 {background-color:#056608;}
.theme-dark-color-26 {background-color:#111;}

   

/*== Theme-Light == */
.theme-light-color-10 {background-color: #faf9f6;}
.theme-light-color-11 {background-color: #f8f8f8;}
.theme-light-color-12 {background-color: #fff6fa;}
.theme-light-color-white {background-color: #fff;}

/* ===== New Templates Widgets Theme Colors End  =====*/


/* ===== New Template Widgets Css =====*/

/*===================== Widget_01 (Start) =====================*/ 
/*.widget-intro-01 {
	background-color: transparent !important;
}*/
.widget-intro-01 .widget-intro-content {
	position: relative;
	background: rgba(255, 255, 255, 0.8);
	padding: 60px 0px 60px 0px;
	max-width: 480px;
	z-index: 5;
	text-align: left;
	margin: 37px 0;
	width: 480px;
	overflow-x: hidden;
	overflow: auto;
	height: 400px;
}
.widget-intro-01 .widget-intro-content * {
	text-align: left;
}
.widget-intro-01 .simple-image {
	overflow: hidden;
	display: inline-block;
	height: 475px;
}
.widget-intro-01 .simple-image img, .widget-intro-01 .borderd-image img {
	width: 100%;
	height: 100%;
}
.widget-intro-01 .borderd-image {
	position: absolute !important;
	right: 0;
	bottom: -70px;
	padding: 15px;
	height: 330px;
	width: 255px;
}
.widget-intro-01 .borderd-image:before {
	content: '';
	position: absolute;
	right: 0;
	z-index: -11111;
	border: 1px dashed #000;
	width: 100%;
	height: 100%;
	padding: 0;
	top: 0;
}

@media (max-width: 991px) {
.widget-intro-01 .widget-intro-content {
	max-width: 400px;
	padding: 15px 0;
	margin: 12px 0;
	max-height: 250px;
}
.widget-intro-01 .simple-image {
	height: 300px
}
.widget-intro-01 .simple-image img {
	max-width: 100%;
}
.widget-intro-01 .widget-intro-content h2 {
	font-size: 24px;
}
.widget-intro-01 .widget-intro-content p {
	font-size: 14px;
}
.borderd-image {
	display: none;
}
.widget-intro-01 .p-0, .pricing-block .p-0 {
	padding-right: 15px;
	padding-left: 15px;
}
}

@media (max-width: 640px) {
.widget-intro-01 .widget-intro-content {
	width: 100%;
	background: none;
	padding: 0;
	margin: 0 0 30px 0;
	min-width: auto;
	max-height: 300px;
}
.widget-intro-01 .simple-image img {
	max-width: 100%;
}
}
/*===================== Widget_01 (End) =====================*/ 

/*===================== Widget_02 (Start) =====================*/ 
.widget-service-01 {
	position: relative;
}
.widget-service-01 .item {
	background: #ffffff;
	margin-bottom: 30px;
	padding: 20px 20px;
	text-align: center;
	box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.1);
}
.widget-service-01 .item .icon {
	margin-bottom: 20px;
	display: inline-block;
	position: relative;
	width: 70px;
	height: 70px;
	line-height: 100px;
	transition: all 0.5s;
	text-align: center;
	cursor: pointer;
	margin-top: 20px;
	font-size: 30px;
	color: #000;
	background-color: transparent;
	border: 1px solid #000;
}
.widget-service-01 .item .icon:hover {
	opacity: 1;
}
.widget-service-01 .item .icon i.fa {
	text-align: center;
	display: block;
	transition: all 0.5s;
	position: relative;
	z-index: 999;
	line-height: 70px;
	top: auto;
	transform: translateY(0);
}
.widget-service-01 .item .icon::after {
	content: '';
	position: absolute;
	left: 50%;
	right: 50%;
	top: 50%;
	bottom: 50%;
	background: #000;
	transition: all 0.5s;
}
.widget-service-01[class*="theme-dark-color"] .item .item-content * {
	color: #000;
}
.widget-service-01 .item a {
	font-weight: bold;
	font-size: 14px;
}
.widget-service-01 .item:hover .icon {
	background: #000;
	transform: rotate(45deg);
}
.widget-service-01 .item:hover .icon::after {
	left: 0;
	right: 0;
	top: 0;
	bottom: 0;
}
.widget-service-01 .item:hover .icon i.fa {
	transform: translateY(0) rotate(-45deg);
	color: #fff;
	top: auto;
}
.widget-service-01::before, .widget-service-01::after {
	content: '';
	position: absolute;
	left: 50%;
	-webkit-transform: translate(-50%, -50%);
	-moz-transform: translate(-50%, -50%);
	-ms-transform: translate(-50%, -50%);
	-o-transform: translate(-50%, -50%);
	transform: translate(-50%, -50%);
	z-index: 3;
	width: 0;
	height: 0;
	border-right: 80px solid transparent;
	border-left: 80px solid transparent;
}
.widget-service-01::before {
	bottom: -15px;
	border-bottom: 30px solid #ffffff;
}
.widget-service-01::after {
	top: 15px;
	border-top: 30px solid #ffffff;
}
.widget-service-01 .item h5 {
	font-size: 16px;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-service-01 .item {
	padding: 10px;
}
}

@media (max-width: 640px) {
.widget-service-01 .item {
	margin-bottom: 15px;
}
}
/*===================== Widget_02 (End) =====================*/
 
/*===================== Widget_03 (Start) =====================*/ 
.widget-team-member-01 .team {
	border: 1px solid #f3f3f3;
}
.widget-team-member-01 .imageWidget {
	height: 230px;
}
.widget-team-member-01 .imageWidget img {
	height: 100%;
	width: 100%;
}
.widget-team-member-01 .team-content {
	text-align: center;
	position: relative;
	padding: 0 0 10px 0;
	box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
	background-color: #fff;
}
.widget-team-member-01 .team-content p, .widget-team-member-01 .team-content h6 {
	margin: 0;
}
.widget-team-member-01 .team-social {
	position: relative;
	top: -15px;
}
.widget-team-member-01 .team-social ul {
	padding: 0;
	margin: 0;
}
.widget-team-member-01 .team-social ul li {
	display: inline-block;
	margin: 0 5px 0 0;
}
.widget-team-member-01 .team-social ul li:last-child {
	margin-right: 0;
}
.widget-team-member-01 .team-social ul li a {
	width: 35px;
	height: 35px;
	display: block;
	border-radius: 100%;
	color: #fff;
	background-color: #000;
}
.widget-team-member-01 .team-social ul li a span.fa {
	color: #fff;
	font-size: 14px;
	line-height: 35px;
}
.widget-team-member-01[class*="theme-dark-color"] .team-content *, .widget-team-member-01[class*="theme-light-color"] .team-content * {
	color: #000;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-intro-01 .simple-image {
	height: 300px;
}
.widget-team-member-01 .imageWidget {
	height: 150px;
}
.widget-team-member-01 .team-social ul li a {
	width: 28px;
	height: 28px;
}
.widget-team-member-01 .team-social ul li a i.fa {
	font-size: 13px;
	line-height: 28px;
}
.widget-team-member-01 .team-content h6 {
	font-size: 14px;
	text-overflow: ellipsis;
	overflow: hidden;
	white-space: nowrap;
}
}

@media (max-width: 640px) {
.widget-team-member-01 .team {
	margin-bottom: 30px;
}
}
/*===================== Widget_03 (End) =====================*/ 

/*===================== Widget_04 (Start) =====================*/ 
.widget-pricing-table-01 {
	position: relative;
}
.widget-pricing-table-01 .pricing-table {
	margin-bottom: 0;
}
.widget-pricing-table-01 .pricing-table.table>tbody>tr>td {
	padding: 15px;
	line-height: normal;
	border-top: 0;
	font-size: 14px;
	color: #fff;
}
.widget-pricing-table-01 .pricing-table tbody {
	background-color: rgba(0,0,0,0.4);
}
.widget-pricing-table-01 .pricing-table thead {
	background-color: #ffffff;
}
.widget-pricing-table-01 .pricing-table thead>tr {
}
.widget-pricing-table-01 .pricing-table.table>tbody>tr>td:last-child {
	text-align: right;
}
.widget-pricing-table-01 .pricing-table.table>thead>tr>th:last-child {
	text-align: right;
}
.widget-pricing-table-01 .pricing-table.table>thead>tr>th {
	padding: 15px;
	border: 0;
	text-transform: uppercase;
	font-family: 'Chonburi', cursive;
	font-size: 14px;
	color: #3a393b;
}
.widget-pricing-table-01::before {
	content: '';
	width: 100%;
	height: 100%;
	position: absolute;
	top: 0;
	left: 0;
	background-color: rgba(0,0,0,0.5);
}
.widget-pricing-table-01 .page-heading h2, .widget-pricing-table-01 .page-heading p {
	color: #fff;
}
.widget-pricing-table-01 .pricing-table.table>tbody>tr {
	border-bottom: 1px dashed #ccc;
}
.widget-pricing-table-01 .pricing-table.table>tbody>tr:last-child {
	border-bottom: 0;
}

@media (max-width: 640px) {
.widget-pricing-table-01 .pricing-table.table>thead>tr>th {
	padding: 10px;
}
}
/*===================== Widget_04 (End) =====================*/
 
/*===================== Widget_05 (Start) =====================*/ 
.widget-about-01 {
}
.widget-about-01 .widget-about-image {
	margin-bottom: 50px;
}
.widget-about-01 .widget-about-image img {
	width: 100%;
	object-fit: cover;
	box-shadow: 10px 15px 25px 0 rgba(0,0,0,.2);
	max-height: 450px;
	border: 5px solid #fff;
	border-radius: 7px;
}
.widget-about-01 .widget-about-content {
	width: 100%;
	text-align: left;
}
.widget-about-01 .widget-about-content p {
	margin-bottom: 20px;
}
.widget-about-01 .widget-about-content p:last-child {
	margin-bottom: 0;
}
/*===================== Widget_05 (End) =====================*/ 

/*===================== Widget_06 (Start) =====================*/ 
.widget-service-02 {
	position: relative;
}
.widget-service-02 .item {
	background-color: #fff;
	padding: 30px;
	text-align: center;
	box-shadow: 0 15px 25px -7px rgba(0,0,0,0.09), 0 -12px 10px -10px rgba(0,0,0,0.04);
	border-radius: 10px;
}
.widget-service-02 .item h4 {
	font-size: 24px;
	margin-bottom: 10px;
	line-height: normal;
	font-weight: bold;
}
.widget-service-02 .item p {
	font-size: 16px;
	text-transform: capitalize;
	margin-bottom: 10px;
}
.widget-service-02 .item .icon {
	background-color: #000;
	margin-bottom: 20px;
	display: inline-block;
	position: relative;
	width: 140px;
	height: 110px;
	line-height: 100px;
	transition: all 0.5s;
	text-align: center;
	cursor: pointer;
	margin-top: 20px;
	border-radius: 80px 200px 200px 362px;
	color: #fff;
}
.widget-service-02 .item .icon i.fa {
	text-align: center;
	display: block;
	transition: all 0.5s;
	position: relative;
	z-index: 999;
	line-height: 110px;
	top: auto;
	transform: translateY(0);

}
.widget-service-02[class*="theme-dark-color"] .item h1,
.widget-service-02[class*="theme-light-color"] .item h1,
.widget-service-02[class*="theme-dark-color"] .item h2,
.widget-service-02[class*="theme-light-color"] .item h2,
.widget-service-02[class*="theme-dark-color"] .item h3,
.widget-service-02[class*="theme-light-color"] .item h3,
.widget-service-02[class*="theme-dark-color"] .item h4,
.widget-service-02[class*="theme-light-color"] .item h4,
.widget-service-02[class*="theme-dark-color"] .item h5,
.widget-service-02[class*="theme-light-color"] .item h5,
.widget-service-02[class*="theme-dark-color"] .item h6,
.widget-service-02[class*="theme-light-color"] .item h6,
.widget-service-02[class*="theme-dark-color"] .item p,
.widget-service-02[class*="theme-light-color"] .item p {
	color: #000;
}
.widget-service-02[class*="theme-dark-color"] .item .icon, .widget-service-02[class*="theme-light-color"] .item .icon {
	color: #000;
}
.widget-service-02[class*="theme-dark-color"] .page-heading * {
	color: #fff;
}
.widget-service-02[class*="theme-light-color"] .page-heading * {
	color: #000;
}
.widget-service-02 .item a {
	font-weight: bold;
	font-size: 14px;
}
.widget-service-02 .item h5 {
	font-size: 16px;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-service-02 .item {
	padding: 10px;
}
}
/*===================== Widget_06 (End) =====================*/ 

/*===================== Widget_07 (Start) =====================*/ 
.widget-service-02 {
	position: relative;
}
.widget-service-02 .item {
	background-color: #fff;
	padding: 30px;
	text-align: center;
	box-shadow: 0 15px 25px -7px rgba(0,0,0,0.09), 0 -12px 10px -10px rgba(0,0,0,0.04);
	border-radius: 10px;
}
.widget-service-02 .item h4 {
	font-size: 24px;
	margin-bottom: 10px;
	line-height: normal;
	font-weight: bold;
}
.widget-service-02 .item p {
	font-size: 16px;
	text-transform: capitalize;
	margin-bottom: 10px;
}

.widget-service-02[class*="theme-dark-color"] .item *, .widget-service-02[class*="theme-light-color"] .item * {
	color: #000;
}
.widget-service-02[class*="theme-dark-color"] .page-heading * {
	color: #fff;
}
.widget-service-02[class*="theme-light-color"] .page-heading * {
	color: #000;
}
.widget-service-02 .item a {
	font-weight: bold;
	font-size: 14px;
}
.widget-service-02 .item h5 {
	font-size: 16px;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-service-02 .item {
	padding: 10px;
}
}
/*===================== Widget_07 (End) =====================*/ 

/*===================== Widget_08 (Start) =====================*/ 
.widget-team-member-02[class*="theme-light-color"] .page-heading * {
	color: #000;
}
.widget-team-member-02[class*="theme-dark-color"] .page-heading * {
	color: #fff;
}
.widget-team-member-02[class*="theme-dark-color"] .team-content *, .widget-team-member-02[class*="theme-light-color"] .team-content * {
	color: #000;
}
.widget-team-member-02 .team {
	border-radius: 10px;
	width: 100%;
	float: left;
	box-shadow: 0px 15px 45px -9px rgba(0,0,0,0.25);
	margin-bottom: 30px;
	height: 230px;
	background-color: #fff;
}
.widget-team-member-02 .team-thumb {
	width: 100%;
	height: 230px;
}
.widget-team-member-02 .team-thumb img {
	height: 100%;
	width: 100%;
	border-radius: 10px 0px 0px 10px;
}
.widget-team-member-02 .team-content {
	background-color: #fff;
	width: 100%;
	padding: 30px 30px 0 30px;
	text-align: left;
}
.widget-team-member-02 .team-content h3 {
	font-size: 20px;
	margin-bottom: 6px;
	font-weight: normal;
}
.widget-team-member-02 .team-content h6 {
	font-family: 'Noto Sans', sans-serif;
	font-size: 14px;
	text-transform: capitalize;
}
.widget-team-member-02 .team-content p {
	font-size: 14px;
	margin: 0 0 10px 0;
	color: #222;
}
.widget-team-member-02 .social-icon {
	width: 100%;
	float: left;
}
.widget-team-member-02 .social-icon ul {
	margin: 0;
	padding: 0 35px;
	list-style: none;
}
.widget-team-member-02 .social-icon ul li {
	display: block;
	float: left;
	margin-right: 10px;
	width: 30px;
	height: 30px;
	text-align: center;
	line-height: 30px;
	background-color: #000;
}
.widget-team-member-02 .social-icon ul li a {
	color: #fff;
}
section.widget-team-member-02[class*="theme-dark-color"] .team-content * {
	color: #000;
}

@media (max-width: 1024px) {
.widget-team-member-02 .team-content {
	padding: 15px 15px 0 15px;
}
.widget-team-member-02 .social-icon ul {
	padding: 0 0 0 15px;
}
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-team-member-02 .team-social ul li a {
	width: 28px;
	height: 28px;
}
.widget-team-member-02 .team-social ul li a i.fa {
	font-size: 13px;
	line-height: 28px;
}
.widget-team-member-02 .team-content h6 {
	font-size: 14px;
	text-overflow: ellipsis;
	overflow: hidden;
	white-space: nowrap;
}
.widget-team-member-02 .team-content {
	float: left;
	padding: 40px 20px 0px 20px;
}
.widget-team-member-02 .social-icon ul {
	padding: 0 0 0 20px;
}
}

@media (max-width: 640px) {
.widget-team-member-02 .team-thumb img {
	border-radius: 10px 10px 0px 0px;
}
.widget-team-member-02 .team-content {
	text-align: center;
	padding: 20px 20px 0 20px;
}
.widget-team-member-02 .team-content ul {
	display: inline-block;
	padding: 0;
}
.widget-team-member-02 .team {
	height: auto;
}
.widget-team-member-02 .social-icon ul {
	display: inline-block;
}
}
/*===================== Widget_08 (End) =====================*/ 

/*===================== Widget_09 (Start) =====================*/ 
.widget-item-01 .item-box {
	background-color: #fff;
	padding: 0;
	border: 1px solid #fff;
	border-radius: 10px 10px 0px 0px;
	box-shadow: 0px 0px 10px rgba(61, 65, 84, 0.15);
}
.widget-item-01 .item-box img {
	border-radius: 10px 10px 0 0;
	width: 100%;
}
.widget-item-01 .item-box-content {
	padding: 15px;
}
.widget-item-01 .item-box-content h4 {
	margin-bottom: 8px;
	font-size: 24px;
}
.widget-item-01 .item-box-content h6 {
	color: #000;
	font-size: 14px;
}
.widget-item-01 .item-box-content p {
	margin-bottom: 0;
}
section.widget-item-01[class*="theme-dark-color"] .item-box *, section.widget-item-01[class*="theme-light-color"] .item-box * {
	color: #000;
}

@media (max-width: 768px) {
.widget-item-01 .item-box {
	margin-bottom: 30px;
}
}
/*===================== Widget_09 (End) =====================*/ 

/*===================== Widget_10 (Start) =====================*/ 
.widget-service-02-2 .feature-box {
	position: relative;
	margin-bottom: 50px;
	text-align: left;
}
.widget-service-02-2 .feature-box .icon {
	width: 50px;
	float: left;
	height: 50px;
	text-align: center;
	margin-bottom: 0;
	color: #000;
}
.widget-service-02-2 .feature-box .icon i.fa {
	transform: translate(0);
	top: 0;
}
.widget-service-02-2 .feature-box .feature-content {
	margin-left: 70px;
	display: block;
}
.widget-service-02-2 .feature-content p {
	margin-bottom: 0;
}
section.widget-service-02-2[class*="theme-dark-color"] * {
	color: #fff;
}
section.widget-service-02-2[class*="theme-light-color"] * {
	color: #000;
}
section.widget-service-02-2[class*="theme-light-color"] .feature-box .icon i.fa {
	color: inherit;
}
section.widget-service-02-2[class*="theme-dark-color"] .feature-box .icon i.fa {
	color: inherit;
}
/*===================== Widget_10 (End) =====================*/

/*===================== Widget_11 (Start) =====================*/
.widget-feature-01 {
}
.widget-feature-01 .item {
	width: 100%;
	position: relative;
}
.widget-feature-01 .item .icon {
	background-color: transparent;
	margin-bottom: 0;
	position: absolute !important;
	left: 0;
}
.widget-feature-01 .item:hover .icon {
	animation-duration: 1s;
	animation-iteration-count: 1;
	animation-name: bounce;
	color: #000;
}
.widget-feature-01 .item .icon i.fa {
	top: auto;
	transform: translateY(0);
}
.widget-feature-01 .item .content {
	text-align: left;
	width: 80%;
	margin-left: 90px;
}
.widget-feature-01 .item .content h4 {
	font-size: 20px;
	color: #000;
	font-weight: 900;
	line-height: 1.5;
	margin-bottom: 10px;
}
.widget-feature-01 .item .content a {
	font-size: 14px;
	color: #bdbdbd;
}
.widget-feature-01 .item .content a i.fa {
	font-size: 14px;
	margin-left: 5px;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-feature-01 .item {
	width: 100%;
	padding: 0;
}
.widget-feature-01 .item .content {
	margin-left: 70px;
}
.widget-feature-01 .item .content h4 {
	font-size: 16px;
}
}

@media only screen and (max-width: 640px) {
.widget-feature-01 .item {
	width: 100%;
}
.widget-feature-01 .item .content {
	margin-left: 70px;
}
.widget-feature-01 .item .content h4 {
	font-size: 18px;
}
}
/*===================== Widget_11 (End) =====================*/

/*===================== Widget_12 (Start) =====================*/
.widget-item-03 {
}
.widget-item-03[class*="theme-light-color"] .item-box .content *, .widget-item-03[class*="theme-dark-color"] .item-box .content * {
	color: #000;
}
.widget-item-03[class*="theme-light-color"] .page-heading * {
	color: #000;
}
.widget-item-03[class*="theme-light-color"] a.theme-button {
	color: #fff;
}
.widget-item-03 .item-box {
	background: #fff;
	padding: 15px;
	margin-bottom: 30px;
	-ms-transition: .4s;
	-o-transition: .4s;
	-moz-transition: .4s;
	-webkit-transition: .4s;
	transition: .4s;
}
.widget-item-03 .item-box:hover {
	box-shadow: 0 0 30px 0 rgba(67, 67, 67, 0.15);
	-webkit-transform: translateY(-5px);
	transform: translateY(-5px);
}
.widget-item-03 .item-box .image {
	height: 220px;
}
.widget-item-03 .item-box .image img {
	height: 100%;
	width: 100%;
}
.widget-item-03 .item-box .content {
	text-align: left;
	padding: 20px 0 0 0;
}
.widget-item-03 .item-box .content h4 {
	font-size: 20px;
	margin-bottom: 10px;
}
.widget-item-03 .item-box .content p {
	margin-bottom: 10px;
	font-size: 14px;
}
.widget-item-03 .item-box .content table {
	list-style: none;
	padding: 10px 0;
	margin: 10px 0 0 0;
	display: inline-block;
	border-top: 1px dashed #a7a1a1;
	width: 100%;
	border-bottom: 1px dashed #a7a1a1;
}
.widget-item-03 .item-box .content table td {
	display: inline-block;
	margin-right: 20px;
	font-size: 14px;
}
.widget-item-03 .item-box .content table td:last-child {
	margin-right: 0;
}
.widget-item-03.widget-item-03 .item-box .content table td span.fa {
	margin-right: 10px;
	font-size: 14px;
	color: #000;
}
/*===================== Widget_12 (End) =====================*/

/*===================== Widget_13 (Start) =====================*/
.widget-team-member-03 .team {
	float: left;
	margin-bottom: 30px;
}
.widget-team-member-03 .team-thumb {
	height: 270px;
	width: 100%;
}
.widget-team-member-03 .team-thumb img {
	height: 100%;
	width: 100%;
}
.widget-team-member-03 .team-content {
	width: 100%;
	text-align: center;
	float: left;
	padding: 20px 0;
	background-color: #fff;
	border-radius: 5px;
	box-shadow: 0px 0px 30px 0px rgba(0, 0, 0, 0.1);
}
.widget-team-member-03 .team-content ul {
	list-style: none;
	margin: 0 auto;
	padding: 0;
	display: inline-block;
	text-align: center;
}
.widget-team-member-03 .team-content ul li {
	display: block;
	float: left;
	margin-right: 15px;
	width: 30px;
	height: 30px;
	text-align: center;
	border-radius: 100px;
	background-color: #000;
}
.widget-team-member-03 .team-content ul li a span.fa {
	line-height: 30px;
	line-height: 30px;
	color: #fff;
}
.widget-team-member-03 .team-content ul li:last-child {
	margin-right: 0;
}
.widget-team-member-03 .team-content h4 {
	font-size: 20px;
	margin-bottom: 0;
}
.widget-team-member-03 .team-content p {
	color: #b5b5b5;
	font-size: 14px;
}
/*===================== Widget_13 (End) =====================*/

/*===================== Widget_14 (Start) =====================*/
.widget-about-02 {
}
.widget-about-02 .widget-about-image {
	height: 360px;
}
.widget-about-02 .widget-about-image img {
	height: 100%;
}
.widget-about-02 .widget-about-content {
	padding: 15px;
}

@media (max-width: 1024px) {
.widget-about-02 .widget-about-image {
	margin-bottom: 30px;
}
}
/*===================== Widget_14 (End) =====================*/

/*===================== Widget_15 (Start) =====================*/
.widget-box-01 {
	position: relative;
	background-color: transparent;
}
.widget-box-01 .item {
	background-color: #fff;
	padding: 30px;
	text-align: center;
	box-shadow: 0 15px 25px -7px rgba(0,0,0,0.09), 0 -12px 10px -10px rgba(0,0,0,0.04);
}
.widget-section.widget-box-01 .item h4 {
	line-height: 1.5;
	margin-bottom: 10px;
	font-size: 20px;
	font-weight: bold;
}
.widget-section.widget-box-01 .item p {
	margin-bottom: 10px;
	font-size: 14px;
}
.widget-box-01 .item .icon {
	background-color: transparent;
	text-align: center;
	display: block;
	margin-bottom: 10px;
	font-size: 40px;
	color: #000;
}
.widget-box-01 .item .theme-button-second {
	padding: 10px 20px;
	font-size: 12px;
}
.widget-box-01 .item .icon i.fa {
	transform: translateY(0);
	top: auto;
}

@media (max-width: 640px) {
.widget-box-01.sec-padding-sm {
	padding-top: 40px;
	padding-bottom: 40px;
}
.widget-box-01.top-m100 {
	top: 0;
}
}
/*===================== Widget_15 (End) =====================*/

/*===================== Widget_16 (Start) =====================*/
.widget-intro-03 {
}
.widget-intro-03 .simple-image {
	height: 360px;
	width: 100%;
}
.widget-intro-03 .simple-image img {
	width: 100%;
	height: 100%;
}
.widget-intro-03 .widget-intro-content {
	padding: 30px;
	text-align: left;
	min-height: 360px;
	background-color: #fafafa;
	position: relative;
}
.widget-intro-03 .widget-intro-content .icon {
	background-color: transparent;
	font-size: 40px;
	color: #000;
}
.widget-intro-03 .widget-intro-content .icon i.fa {
	transform: translateY(0);
}
.widget-intro-03 .widget-intro-content h4 {
	font-size: 20px;
}
.widget-section.widget-intro-03 .widget-intro-content p {
	margin-bottom: 10px;
	font-size: 16px;
}
.widget-intro-03 h2 {
	font-size: 32px;
	line-height: 1.5;
	margin-bottom: 10px;
	font-weight: bold;
}
.widget-intro-03 .widget-intro-content a {
	font-weight: bold;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-intro-03 .widget-intro-content {
	margin-top: 30px;
}
}
/*===================== Widget_16 (End) =====================*/

/*===================== Widget_17 (Start) =====================*/
.widget-service-03 {
}
.widget-service-03 .icon {
	border-radius: 50%;
	height: 112px;
	width: 112px;
	border: 1px solid #ccc;
	display: block;
	margin: 0 auto;
	text-align: center;
	font-size: 36px;
	color: #000;
}
.widget-service-03 .item {
	z-index: 1;
	margin-bottom: 33px;
}
.widget-service-03 .item::before, .widget-service-03 .item::after {
	border-top: 1px dashed #ccc;
	content: "";
	height: 1px;
	width: 50%;
	position: absolute;
	top: 55px;
	z-index: -1;
}
.widget-service-03 .item::before {
	left: 0;
}
.widget-service-03 .item::after {
	right: 0;
}
.widget-service-03 .item i, .widget-service-03 .item h5 {
	-webkit-transition: all 1s ease 0s;
	-moz-transition: all 1s ease 0s;
	-o-transition: all 1s ease 0s;
	transition: all 1s ease 0s;
}
.widget-service-03 .item i {
	transform: translateY(0);
	top: auto;
	position: static;
}
.widget-service-03 .item i::before {
	line-height: 112px;
}
.widget-service-03 .item h4 {
	font-size: 20px;
	margin-top: 18px;
	margin-bottom: 3px;
}
.widget-service-03 .item p {
}
.widget-service-03[class*="theme-dark-color"] .item-content * {
    color: #fff;
}
.widget-service-03[class*="theme-light-color"] .item-content * {
    color: #000;
}

@media (min-width: 992px) {
.widget-service-03 .item:nth-child(4n+1) {
	clear: both;
}
.widget-service-03 .item:nth-child(4n+1)::before, .widget-service-03 .item:nth-child(4n)::after {
	display: none;
}
}

@media (max-width: 991px) {
.widget-service-03 .item:nth-child(2n+1)::before, .widget-service-03 .item:nth-child(2n)::after {
	display: none;
}
}

@media (max-width: 479px) {
.widget-service-03 .item {
	width: 100%;
}
.widget-service-03 .item::before, .widget-service-03 .item::after {
	display: none;
}
}
/*===================== Widget_17 (End) =====================*/

/*===================== Widget_18 (Start) =====================*/
.widget-item-02 .item-box {
	text-align: center;
	padding: 15px;
	margin-bottom: 30px;
	border: 1px solid #dddddd;
	min-height: 384px;
}
.widget-item-02 .item-box-image {
	height: 200px;
}
.widget-item-02 .item-box-image img {
	width: 100%;
	height: 100%;
}
.widget-item-02 .item-box-content {
	padding: 20px 0;
}
.widget-item-02 .item-box-content p {
	margin-bottom: 0;
}

@media (max-width: 768px) {
.widget-item-02 .item-box-image {
	height: 120px;
}
.widget-item-02 .item-box-content {
	padding: 10px 0;
}
.widget-item-02 .item-box-content h4 {
	font-size: 16px;
}
.widget-item-02 .item-box-content p {
	font-size: 14px;
}
}
/*===================== Widget_18 (End) =====================*/

/*===================== Widget_19 (Start) =====================*/
.widget-banner-01 {
	position: relative;
}
.widget-banner-01::before {
	content: '';
	width: 100%;
	height: 100%;
	position: absolute;
	left: 0;
	top: 0;
	background-color: rgba(0,0,0,0.8);
}
.widget-banner-01 h2, .widget-banner-01 h4, .widget-banner-01 p {
	color: #fff;
}
.widget-banner-01 p {
	font-size: 14px;
}
.widget-banner-01 .funfact {
	padding: 20px 0 0 0;
}
.widget-banner-01 .funfact .icon {
	background-color: transparent;
	margin-bottom: 10px;
	text-align: left;
	color: #000;
}
.widget-banner-01 .funfact .icon i.fa {
	transform: translateY(0);
	top: 0;
	margin-bottom: 5px;
}
.widget-banner-01 .funfact h4, .widget-banner-01 .funfact p {
	margin-bottom: 0;
}
.widget-banner-01 .bg-form {
	padding: 30px;
	background-color: rgba(0,0,0,0.5);
}
.widget-banner-01 .bg-form input[type="text"], .widget-banner-01 .bg-form input[type="email"], .widget-banner-01 .bg-form textarea {
	background-color: #fff;
	border: 0;
	padding: 10px 10px;
	width: 100%;
}
.widget-banner-01 .bg-form h4 {
	font-size: 20px;
}
/*===================== Widget_19 (End) =====================*/

/*===================== Widget_20 (Start) =====================*/
.widget-pricing-01 .plan {
	background-color: #000;
	position: relative;
	max-width: 300px;
	padding-right: 0;
	padding-left: 0;
	margin: 0 auto;
	box-shadow: 0 0 30px 0 rgba(67, 67, 67, 0.15);
}
.widget-pricing-01 .plan-header {
	padding: 20px 0;
	position: relative;
	text-align: center;
}
.widget-pricing-01 .plan-header h3 {
	font-size: 24px;
	color: #fff;
	font-weight: normal;
	margin-bottom: 10px;
}
.widget-pricing-01 .plan-price {
	padding: 10px 0;
}
.widget-pricing-01 .plan-price p {
	font-size: 40px;
	font-weight: bold;
	color: #fff;
	margin-bottom: 20px;
}
.widget-pricing-01 .plan-price h6 {
	color: #fff;
	font-weight: normal;
	font-size: 14px;
	margin-bottom: 0;
}
.widget-pricing-01 .plan-body {
	text-align: center;
}
.widget-pricing-01 .plan-body ul {
	list-style: none;
	padding: 0;
	margin: 0;
}
.widget-pricing-01 .plan-body ul li {
	color: #000;
	padding: 20px 0;
	cursor: pointer;
	font-size: 14px;
	font-family: 'Raleway', sans-serif;
	font-weight: normal;
	border-bottom: 1px solid #eee;
}
.widget-pricing-01 .plan-list {
	background-color: #fff;
}
.widget-pricing-01 .plan-button {
	padding: 30px 0;
}
.widget-pricing-01 .plan-button a {
	background-color: #fff;
	font-weight: bold;
	font-size: 14px;
	padding: 15px 20px;
	border-radius: 4px;
	color: #000;
	text-transform: capitalize;
}
/*===================== Widget_20 (End) =====================*/

/*===================== Widget_21 (Start) =====================*/
.widget-service-04 {
}
.widget-service-04 .item {
	text-align: center;
	position: relative;
}
.widget-service-04 .item .icon {
	width: 80px;
	height: 80px;
	border-radius: 100px;
	line-height: 80px;
	font-size: 30px;
	font-weight: bold;
    color: #000;
}
.widget-service-04 [class*="col-"]:before, .widget-service-04 [class*="col-"]:after {
	width: calc(50% - 66px);
	position: absolute;
	content: "";
	height: 1px;
	background: #fff;
	top: 33px;
	z-index: 1;
	left: 0;
	margin-left: 0;
}
.widget-service-04 [class*="col-"]:after {
	right: 0;
	left: auto;
	margin-right: 0;
	margin-left: 0;
}
.widget-service-04 [class*="col-"]:first-child:before {
	display: none;
}
.widget-service-04 [class*="col-"]:last-child:after {
	display: none;
}

@media (max-width: 640px) {
.widget-service-04 [class*="col-"]:first-child:before, .widget-service-04 [class*="col-"]:last-child:after {
	display: block;
}
}
/*===================== Widget_21 (End) =====================*/

/*===================== Widget_22 (Start) =====================*/
.widget-team-member-04 {
}
.widget-team-member-04 .team-thumb {
	height: 390px;
	width: 100%;
}
.widget-team-member-04 .team-thumb img {
	height: 100%;
	width: 100%;
}
.widget-team-member-04 .team-content {
	width: 100%;
	margin: 0 auto;
	padding: 30px 15px;
	position: relative;
	-webkit-transition: all 0.4s ease-out 0s;
	-moz-transition: all 0.4s ease-out 0s;
	-ms-transition: all 0.4s ease-out 0s;
	-o-transition: all 0.4s ease-out 0s;
	transition: all 0.4s ease-out 0s;
}
.widget-team-member-04 .team:hover .team-content {
	background-color: #fff;
	margin-top: -60px;
	-webkit-box-shadow: 0px 3px 5px 0px rgb(0, 0, 0, 0.1);
	-moz-box-shadow: 0px 3px 5px 0px rgb(0, 0, 0, 0.1);
	box-shadow: 0px 3px 5px 0px rgb(0, 0, 0, 0.1);
}
.widget-team-member-04 .team-content h4 {
	text-align: center;
	line-height: normal;
	margin-bottom: 0;
}
.widget-team-member-04 .team-content p {
	font-size: 14px;
	text-align: center;
	font-weight: 500;
	margin-bottom: 0;
}
.widget-team-member-04 .team-content ul {
	text-align: center;
	margin-top: -35px;
	opacity: 0;
	-webkit-transition: all 0.4s ease-out 0s;
	-moz-transition: all 0.4s ease-out 0s;
	-ms-transition: all 0.4s ease-out 0s;
	-o-transition: all 0.4s ease-out 0s;
	transition: all 0.4s ease-out 0s;
	padding: 0;
	visibility: hidden;
}
.widget-team-member-04 .team:hover .team-content ul {
	margin-top: 25px;
	opacity: 1;
	visibility: visible;
}
.widget-team-member-04 .team-content ul li {
	display: inline-block;
	margin: 0 7px;
}
.widget-team-member-04 .team-content ul li a {
	font-size: 16px;
	color: #646464;
	width: 30px;
	height: 30px;
	line-height: 30px;
	text-align: center;
	border-radius: 50%;
	background-color: #ededed;
	-webkit-transition: all 0.4s ease-out 0s;
	-moz-transition: all 0.4s ease-out 0s;
	-ms-transition: all 0.4s ease-out 0s;
	display: block;
	-o-transition: all 0.4s ease-out 0s;
	transition: all 0.4s ease-out 0s;
}
.widget-team-member-04 .team-content ul li a:hover {
	color: #fff;
}
.widget-team-member-04[class*="theme-dark-color"] .team:hover .team-content * {
	color: #000 !important;
}
/*===================== Widget_22 (End) =====================*/

/*===================== Widget_23 (Start) =====================*/
.widget-intro-04 {
}
.widget-intro-04 .widget-intro-image {
	width: 100%;
	height: 360px;
}
.widget-intro-04 .widget-intro-image img {
	width: 100%;
	height: 100%;
}
.widget-intro-content {
	text-align: center;
}

@media (max-width: 1023px) and (min-width: 768px) {
.widget-intro-04 .widget-intro-content {
	padding: 60px 0;
}
.widget-intro-04 .widget-intro-image {
	height: 500px;
}
}

@media (max-width: 640px) {
.widget-intro-04 .widget-intro-content {
	padding: 30px 0;
}
}
/*===================== Widget_23 (End) =====================*/

/*===================== Widget_24 (Start) =====================*/
.widget-section.widget-listing-01 {
}
.widget-section.widget-listing-01 .listing-item {
	padding: 10px 0;
	border-bottom: 1px dotted #fff;
}
.widget-section.widget-listing-01 .listing-item:last-child {
	border-bottom: 0;
}
.widget-section.widget-listing-01 .listing-item h5 {
	font-size: 20px;
	line-height: 1.5;
	font-weight: 900;
	margin-bottom: 0;
	font-family: 'Berkshire Swash', cursive;
}
.widget-section.widget-listing-01 .listing-item h6 {
	text-align: center;
	font-family: 'Poppins', sans-serif;
	font-weight: bold;
	font-size: 16px;
	margin: 0;
	line-height: 1.5;
}
.widget-section.widget-listing-01 .listing-item p {
	font-size: 14px;
}
/*===================== Widget_24 (End) =====================*/

/*===================== Widget_25 (Start) =====================*/
.widget-service-05 {
}
.widget-service-05 .item {
	box-shadow: 0 3px 10px 0px rgba(0,0,0,0.1);
	-moz-box-shadow: 0 3px 10px 0px rgba(0,0,0,0.1);
	-webkit-box-shadow: 0 3px 10px 0px rgba(0,0,0,0.1);
	-o-box-shadow: 0 3px 10px 0px rgba(0,0,0,0.1);
	-ms-box-shadow: 0 3px 10px 0px rgba(0,0,0,0.1);
	position: relative;
	padding: 50px 20px 20px 20px;
	text-align: center;
}
.widget-service-05 .item .icon {
	position: absolute !important;
	z-index: 10;
	top: -35px;
	left: calc(50% - 35px);
	width: 70px;
	height: 70px;
	border-radius: 50%;
	overflow: hidden;
	box-shadow: 0 3px 10px 0px rgba(0,0,0,0.1);
	-moz-box-shadow: 0 3px 10px 0px rgba(0,0,0,0.1);
	-webkit-box-shadow: 0 3px 10px 0px rgba(0,0,0,0.1);
	-o-box-shadow: 0 3px 10px 0px rgba(0,0,0,0.1);
	-ms-box-shadow: 0 3px 10px 0px rgba(0,0,0,0.1);
	margin-bottom: 0;
	color: #fff;
	background-color: #000;
}
/*.widget-service-05 .item .icon i.fa {
	color: #fff;
}*/

@media (max-width: 1023px) and (min-width: 768px) {
.widget-section.widget-service-05 .item {
	margin-bottom: 60px;
}
}

@media (max-width: 640px) {
.widget-service-05 .item {
	margin-bottom: 60px;
}
}
/*===================== Widget_25 (End) =====================*/

/*===================== Widget_26 (Start) =====================*/
.widget-form-02 .item {
	margin-bottom: 0;
}
.widget-form-02 .item .icon {
	float: left;
	width: 30px;
	height: 30px;
	margin-right: 10px;
	background-color: transparent;
}
.widget-form-02 .item .content {
	overflow: hidden;
}
.widget-form-02 .item .content p {
	font-size: 14px;
}
.widget-form-02 form input, .widget-form-02 form textarea {
	border-radius: 3px;
	font-size: 12px;
	padding: 15px;
	margin-bottom: 15px;
	width: 100%;
	box-shadow: 0 2px 4px rgba(126,142,177,.12);
}
.widget-form-02 form textarea {
	min-height: 187px;
}
.widget-form-02 .item h6 {
	font-size: 16px;
	font-weight: bold;
	margin-bottom: 10px;
}

@media (max-width: 1023px) {
.widget-form-02 .item {
	text-align: left;
}
}
/*===================== Widget_26 (End) =====================*/

/*===================== Widget_27 (Start) =====================*/
.widget-team-member-05 .team {
	-moz-transition-duration: .3s;
	-webkit-transition-duration: .3s;
	-o-transition-duration: .3s;
	transition-duration: .3s;
	width: 100%;
	float: left;
	position: relative;
}
.widget-team-member-05 .team-thumb {
	height: 390px;
	width: 100%;
	position: relative;
	overflow: hidden;
}
.widget-team-member-05 .team-thumb img {
	width: 100%;
	height: 100%;
	-moz-transition-duration: .5s;
	-webkit-transition-duration: .5s;
	-o-transition-duration: .5s;
	transition-duration: .5s;
}
.widget-team-member-05 .team-content {
	position: absolute;
	transform: translateX(-50%);
	padding: 15px;
	background: rgba(255,255,255,.9);
	border-radius: 6px;
	width: 80%;
	transition-duration: .3s;
	bottom: 15px;
	opacity: 1;
	left: 50%;
}
.widget-team-member-05 .team-content h4, .widget-team-member-05 .team-content p {
	margin-bottom: 0;
}
.widget-team-member-05 .team-content ul {
	margin: 10px 0 0 0;
	padding: 0;
	width: 100%;
	list-style: none;
	float: left;
}
.widget-team-member-05 .team-content ul li {
	display: block;
	float: left;
	margin-right: 15px;
	font-size: 16px;
}
.widget-team-member-05 .team-content ul li a span.fa {
	color: #000;
}
.widget-team-member-05 .team-content ul li:last-child {
	margin-right: 0;
}
.widget-team-member-05 .team:hover .team-thumb img {
	transform: scale(1.2);
	-ms-transform: scale(1.2);
	-moz-transform: scale(1.2);
	-webkit-transform: scale(1.2);
	-o-transform: scale(1.2);
}
.widget-team-member-05 .team:hover .team-content {
	background: #fff;
	width: 100%;
	margin: 0;
	opacity: 1;
	bottom: 0;
	border-radius: 0;
}
section.widget-team-member-05[class*="theme-dark-color"] .team-content * {
	color: #000;
}

@media (max-width: 1024px) {
.widget-team-member-05 .team {
	margin-bottom: 30px;
}
.widget-team-member-05 .team-thumb {
	height: 300px;
}
}

@media (max-width: 768px) {
.widget-team-member-05 .team-thumb {
	height: 390px;
}
}

@media (max-width: 640px) {
.widget-team-member-05 .team {
	margin-bottom: 30px;
}
.widget-team-member-05 .team-content h4, .widget-team-member-05 .team-content p {
	text-align: left;
}
}
/*===================== Widget_27 (End) =====================*/

/*===================== Widget_28 (Start) =====================*/
.widget-intro-05 {
}
.widget-intro-05 h4 {
	color: #232323;
	font-weight: 600;
	line-height: 1.3;
	text-transform: capitalize;
}
.widget-intro-05 p {
	margin: 0;
}
.widget-intro-05 .content-box {
	overflow: hidden;
	padding: 30px 15px;
}
.widget-intro-05 .content-box .center {
	overflow: hidden;
}
.widget-intro-05 .content-box .center .item::after {
	background: #e7e7e7 none repeat scroll 0 0;
	content: "";
	height: 100%;
	position: absolute;
	right: -1px;
	top: 0;
	width: 1px;
}
.widget-intro-05 .content-box .center .item::before {
	background: #e7e7e7 none repeat scroll 0 0;
	content: "";
	height: 1px;
	position: absolute;
	bottom: -1px;
	left: 0;
	width: 100%;
}
.widget-intro-05 .content-box .item {
	padding: 30px 15px;
	max-height: 256px;
}
.widget-intro-05 .content-box .item .icon {
	background-color: transparent;
	margin-bottom: 20px;
	text-align: left;
	color: #000;
	font-size: 60px;
}
.widget-intro-05 .content-box .item .icon i.fa {
	top: 0;
	transform: translateY(0);
	display: inline-block;
}
.widget-intro-05 .content-box .item h5 {
	font-size: 20px;
	line-height: 1.5;
	font-weight: 900;
}
.widget-intro-05 .author .info {
	padding-left: 20px;
}
.widget-intro-05 .author .thumb img {
	height: 100px;
	width: 100px;
	-webkit-border-radius: 50%;
	-moz-border-radius: 50%;
	border-radius: 50%;
}
.widget-intro-05 .author img {
	height: 60px;
	width: auto;
}
.widget-intro-05 .author {
	border-top: 1px solid #e7e7e7;
	margin-top: 25px;
	padding-top: 25px;
}
.widget-intro-05 .author h4 {
	color: #232323;
	letter-spacing: 0;
	margin-bottom: 10px;
}
.widget-intro-05 .author .thumb, .widget-intro-05 .author .info {
	display: table-cell;
	vertical-align: middle;
}
.widget-intro-05 .about-content .thumb {
	padding-left: 15px;
	padding-right: 15px;
	position: relative;
	z-index: 1;
}
/*===================== Widget_28 (End) =====================*/

/*===================== Widget_29 (Start) =====================*/
.widget-service-06 .item {
	background-color: transparent;
	padding: 10px;
}
.widget-service-06 .item .icon {
	width: 50px;
	height: 50px;
	border-radius: 100px;
	position: absolute;
	top: 60px;
	text-align: center;
	left: 50%;
	transform: translateX(-50%);
}
.widget-service-06 .item .icon i.fa {
	transform: translateY(0);
	line-height: 50px;
	font-size: 30px;
}
.widget-service-06 .item.zoom.skew-right, .widget-service-06 .item.zoom.skew-left {
	overflow: hidden;
	padding: 70px 30px 40px;
	position: relative;
	z-index: 1;
}
.widget-service-06 .item.zoom.skew-right::after, .widget-service-06 .item.zoom.skew-left::after {
	background: #fbfbfb none repeat scroll 0 0;
	content: "";
	height: 100%;
	left: 0;
	margin-top: 22px;
	position: absolute;
	top: 0;
	transform: skewY(7deg);
	width: 100%;
	z-index: -1;
}
.widget-service-06 .item {
}
.widget-service-06 .item.zoom.skew-left::after {
	transform: skewY(-7deg);
}
.widget-service-06 .item .content {
	margin-top: 40px;
	text-align: center;
}
.widget-service-06 .item .content h4 {
	font-size: 18px;
}
.widget-service-06 .item .content p {
	font-size: 14px;
	margin-bottom: 0;
}
/*===================== Widget_29 (End) =====================*/

/*===================== Widget_30 (Start) =====================*/
.widget-team-member-06 {
}
.widget-team-member-06 .team {
	position: relative;
}
.widget-team-member-06 .team-thumb {
	height: 390px;
	width: 100%;
}
.widget-team-member-06 .team-thumb img {
	width: 100%;
	height: 100%;
}
.widget-team-member-06 .team-content {
	background: rgba(255,255,255,0.8);
	padding: 10px 0;
	position: absolute;
	top: 66%;
	left: 0;
	text-align: center;
	width: 100%;
	-webkit-transition: all .4s ease;
	transition: all .4s ease;
}
.widget-team-member-06 .team-content ul {
	margin: 0;
	padding: 0;
	list-style: none;
	display: inline-block;
	position: relative;
	top: -100%;
	padding-top: 0px;
	margin-bottom: -30px;
	-webkit-transform: translateY(-100%);
	transform: translateY(-100%);
	opacity: 0;
	-webkit-transition: all .4s ease;
	transition: all .4s ease;
}
.widget-team-member-06 .team-content ul li {
	float: left;
	margin-right: 15px;
	width: 30px;
	height: 30px;
	border-radius: 3px;
	line-height: 30px;
	background-color: #fff;
}
.widget-team-member-06 .team-content ul li a i.fa {
	color: #000;
	font-size: 14px;
}
.widget-team-member-06 .team-content ul li a span.fa {
	color: #000;
	font-size: 14px;
}
.widget-team-member-06 .team-content h4, .widget-team-member-06 .team-content p {
	margin-bottom: 0;
}
.widget-team-member-06 .team-content p {
	font-size: 14px;
}
.widget-team-member-06 .team:hover .team-content {
	background: #000;
}
.widget-team-member-06 .team:hover .team-content ul {
	padding-top: 15px;
	opacity: 1;
	top: 0%;
	margin-bottom: 0px;
	-webkit-transform: translateY(0%);
	transform: translateY(0%);
}
.widget-team-member-06 .team-content h4, .widget-team-member-06 .team-content p {
	color: #000;
}
.widget-team-member-06 .team-content ul li:last-child {
	margin-right: 0;
}
.widget-team-member-06 .team:hover .team-content h4, .widget-team-member-06 .team:hover .team-content p {
	color: #fff;
}
/*===================== Widget_30 (End) =====================*/

/*===================== Widget_31 (Start) =====================*/
.widget-about-03 {
}
.widget-about-03 .about-img {
	height: 490px;
	width: 100%;
}
.widget-about-03 .about-img img {
	width: 100%;
	height: 100%;
}
.widget-about-03 h4 {
	margin-bottom: 0;
	font-weight: normal;
}
.widget-about-03 .about-content {
	padding: 40px 0;
}
.widget-about-03 .funfact {
	padding: 20px;
	background: #000;
	transition: all .4s;
	position: relative;
	border-radius: 5px;
	text-align: center;
}
.widget-about-03 .funfact .icon {
	background-color: #fff;
	margin-bottom: 0;
	position: absolute;
	top: 50%;
	transform: translateY(-50%);
	width: 50px;
	height: 50px;
	border-radius: 0 5px 5px 0;
	left: 0;
	font-size: 30px;
	color: #000;
}
.widget-about-03 .funfact .content {
	overflow: hidden;
	padding: 0 0 0 50px;
}
.widget-about-03 .funfact h4 {
	color: #000;
	font-size: 24px;
	font-weight: bold;
}
.widget-about-03 .funfact p {
	color: #000000;
	text-transform: uppercase;
	font-size: 14px;
}
.widget-about-03 .funfact .content h4, .widget-about-03 .funfact .content p {
	margin-bottom: 0;
}
/*===================== Widget_31 (End) =====================*/

/*===================== Widget_32 (Start) =====================*/
.widget-feature-02 .item {
	-moz-box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	-webkit-box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	-o-box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
	margin-bottom: 30px;
}
.widget-feature-02 .item-thumb {
	width: 100%;
	height: 220px;
}
.widget-feature-02 .item-thumb img {
	width: 100%;
	height: 100%;
}
.widget-feature-02 .item-info {
	background-color: #fff;
	padding: 20px 0;
	text-align: center;
	position: relative;
}
.widget-feature-02 .item-info h4 {
	font-size: 20px;
	font-weight: bold;
	margin-bottom: 0;
	color: #000;
}
.widget-feature-02 .item-info .icon {
	background-color: transparent;
	margin-bottom: 0;
	margin-top: 10px;
	position: relative;
	display: block;
	font-size:40px;
	z-index: 1;
	color: #000;
}
.widget-feature-02 .item-info .icon:after {
	background: #e6e6e6;
	content: "";
	height: 1px;
	left: 0;
	position: absolute;
	width: 100%;
	z-index: -1;
	top: 50%;
}
.widget-feature-02 .item-info .icon i.fa {
	background-color: #fff;
	padding: 0 15px;
	top: 0;
	transform: translateY(0);
	display: inline-block;
}
/*===================== Widget_32 (End) =====================*/

/*===================== Widget_33 (Start) =====================*/
.widget-intro-02[class*="theme-light-color"] .widget-intro-content *{color:#000;}
.widget-intro-02[class*="theme-dark-color"] .widget-intro-content *{color:#fff;}
.widget-intro-02 {
	overflow: visible !important;
}
.widget-intro-02 .widget-intro-content {
	padding: 15px;
	text-align: left;
}
.widget-intro-02 .widget-intro-content h2 {
	font-size: 32px;
	line-height: normal;
	font-weight: bold;
}
.widget-intro-02 .widget-intro-content p, .widget-intro-02 .widget-intro-content h2 {
	margin-bottom: 10px;
}
.widget-intro-02 .simple-image {
	height: 460px;
}
.widget-intro-02 .simple-image img {
	width: 100%;
	max-height: 100%;
	border-radius: 10px;
}
.widget-intro-02 .borderd-image {
	position: relative;
	top: -100px;
	z-index: 111;
	height: 460px;
}
.widget-intro-02 .borderd-image:before {
	content: '';
	width: 100%;
	position: absolute;
	top: 50px;
	background-color: #120f08;
	height: 460PX;
	z-index: -11111;
	left: auto;
	right: -30px;
	border-radius: 0px 0px 10px 10px;
}
.widget-intro-02 .borderd-image img {
	width: 100%;
	max-height: 100%;
	border-radius: 10px;
}

@media (max-width: 991px) {
.widget-intro-02 .widget-intro-content h2 {
	font-size: 24px;
}
.widget-intro-02 .widget-intro-content p {
	font-size: 14px;
}
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-intro-02 .widget-intro-content {
	margin-bottom: 50px;
}
}

@media (max-width: 640px) {
.widget-intro-02 .widget-intro-content {
	text-align: center;
}
.widget-intro-02 .simple-image img {
	max-width: 100%;
}
.widget-intro-02 .borderd-image {
	top: auto;
}
.widget-intro-02 .borderd-image:before {
	top: 30px;
	height: 380PX;
	right: -16px;
}
}
/*===================== Widget_33 (End) =====================*/

/*===================== Widget_34 (Start) =====================*/
.widget-product-01 .product {
	width: 100%;
	height: 100%;
}
.widget-product-01 .product .product-thumbnail {
	width: 100%;
	height: 360px;
}
.widget-product-01 .product .product-thumbnail img {
	width: 100%;
	height: 100%;
}
.widget-product-01 .product .product-detail {
	-webkit-box-shadow: 0 0 30px -10px rgba(0,0,0,.1);
	box-shadow: 0 0 30px -10px rgba(0,0,0,.1);
	background: #fff;
	padding: 30px 20px;
}
.widget-product-01 .product .product-detail h3 {
	font-size: 18px;
	color: #000;
	text-transform: capitalize;
	font-weight: 900;
	margin-bottom: 0;
}
.widget-product-01 .product .product-detail p {
	font-size: 14px;
	line-height: normal;
	font-weight: 600;
	color: #000;
}
.widget-product-01 .product-price {
}
.widget-product-01 .product-price p {
	margin-bottom: 0;
	font-size: 12px;
	font-weight: normal;
	color: #000;
}
.widget-product-01 .product .product-detail .cart-btn {
	margin-top: 10px;
	text-align: left;
}
.widget-product-01 .product .product-detail .cart-btn a {
	font-size: 12px;
	background-color: #000;
	padding: 7px 15px;
	display: inline-block;
	color: #fff;
	border-radius: 100px;
}
.widget-product-01[class*="theme-light-color"] .page-heading * {
	color: #000;
}

@media (min-width: 768px) and (max-width: 1024px) {
.widget-product-01 .product {
	margin-bottom: 30px;
}
.widget-product-01 .product .product-detail .cart-btn {
	text-align: center;
}
}

@media (max-width: 640px) {
.widget-product-01 .product {
	margin-bottom: 30px;
}
.widget-product-01 .product .product-detail .cart-btn {
	text-align: center;
}
}
/*===================== Widget_34 (End) =====================*/

/*===================== Widget_35 (Start) =====================*/
.widget-banner-02 {
}
.widget-banner-02 .thumbnail {
	height: 260px;
	padding: 0;
	border-radius: 0;
	border: 0;
	line-height: normal;
	margin-bottom: 0;
	width: 100%;
	background-color: #111;
}
.widget-banner-02 .thumbnail img {
	width: 100%;
	height: 100%;
	opacity: 0.5;
}
.widget-banner-02 .content {
	position: absolute;
	top: 50%;
	transform: translateY(-50%);
	left: 20px;
}
.widget-banner-02 .content h6 {
	font-weight: 900;
	text-transform: uppercase;
	margin-bottom: 0;
	color: #fff;
	font-size: 20px;
}
.widget-banner-02 .content a {
	font-size: 12px;
	text-transform: uppercase;
	border-bottom: 1px solid #fff;
	color: #fff;
}
.widget-banner-02 .banner-cover {
	width: 100%;
	height: 100%;
	position: relative;
}
.widget-banner-02 .content p {
	font-size: 14px;
	color: #fff;
	margin-bottom: 0;
}

@media (min-width: 768px) and (max-width: 1023px) {
}

@media (max-width: 640px) {
.widget-banner-02 .banner-cover {
	margin-bottom: 30px;
}
}
/*===================== Widget_35 (End) =====================*/

/*===================== Widget_36 (Start) =====================*/
.widget-categorie-01[class*="theme-light-color"] .page-heading * {
	color: #000;
}
.widget-categorie-01[class*="theme-dark-color"] .page-heading * {
	color: #fff;
}
.widget-categorie-01[class*="theme-dark-color"] .item-box-content *, .widget-categorie-01[class*="theme-light-color"] .item-box-content * {
	color: #000;
}
.widget-categorie-01 .item-box {
	width: 100%;
	float: left;
	position: relative;
}
.widget-categorie-01 .item-box .item-box-image {
	width: 100%;
	height: 200px;
}
.widget-categorie-01 .item-box .item-box-image img {
	width: 100%;
	height: 100%;
}
.widget-categorie-01 .item-box .item-box-content {
	position: absolute;
	width: 100%;
	top: 50%;
	transform: translateY(-50%);
	text-align: center;
	background-color: rgba(255,255,255,0.9);
	padding: 8px 0;
}
.widget-categorie-01 .item-box .item-box-content h6 {
	margin-bottom: 0;
}
.widget-categorie-01 .item-box .item-box-content p {
	font-size: 12px;
	margin-bottom: 0;
}
section.widget-categorie-01[class*="theme-light-color"] .item-box-content *, section.widget-categorie-01[class*="theme-light-color"] .page-heading * {
	color: #000;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-categorie-01 .item-box {
	margin-bottom: 30px;
}
}

@media (max-width: 640px) {
.widget-categorie-01 .item-box {
	margin-bottom: 30px;
}
}
/*===================== Widget_36 (End) =====================*/

/*===================== Widget_37 (Start) =====================*/
.widget-service-07[class*="theme-light-color"] .page-heading * {
	color: #000;
}
.widget-service-07[class*="theme-dark-color"] .page-heading * {
	color: #fff;
}
.widget-service-07[class*="theme-dark-color"] .content *, .widget-team-member-02[class*="theme-light-color"] .content * {
	color: #000;
}
.widget-service-07 {
}
.widget-service-07 .item {
	margin: 0;
	position: relative;
	background: #ffffff;
	margin-bottom: 30px;
	border-radius: 10px;
	padding: 20px 40px 40px 40px;
	text-align: center;
	box-shadow: 0 5px 5px rgba(86, 86, 86, 0.1);
}
.widget-service-07 .item .icon {
	background-color: transparent;
	margin-bottom: 10px;
	font-size: 40px;
	color: #000;
}
.widget-service-07 .item .icon i.fa {
	top: 0;
	transform: translateY(0);
}
.widget-service-07 .item .content p {
	margin-bottom: 0;
	font-size: 14px;
}
.widget-service-07[class*="theme-light-color"] .item .content *, .widget-service-07[class*="theme-light-color"] .page-heading * {
	color: #000;
}
.widget-service-07 .item:before {
	content: '';
	position: absolute;
	left: 50%;
	-webkit-transform: translate(-50%, -50%);
	-moz-transform: translate(-50%, -50%);
	-ms-transform: translate(-50%, -50%);
	-o-transform: translate(-50%, -50%);
	transform: translate(-50%, -50%);
	z-index: 3;
	top: -15px;
	border-bottom: 30px solid #ffffff;
	width: 0;
	height: 0;
	border-right: 80px solid transparent;
	border-left: 80px solid transparent;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-service-07 .item {
	padding: 10px;
}
}

@media (max-width: 640px) {
.widget-service-07 .item {
	margin-bottom: 60px;
}
}
/*===================== Widget_37 (End) =====================*/

/*===================== Widget_38 (Start) =====================*/
.widget-form-03[class*="theme-light-color"] .page-heading * {
	color: #000;
}
.widget-form-03[class*="theme-dark-color"] .page-heading * {
	color: #fff;
}
.widget-form-03[class*="theme-dark-color"] .content *, .widget-form-03[class*="theme-light-color"] .content *, .widget-form-03[class*="theme-light-color"] .form-box {
	color: #000;
}
.widget-form-03 .item {
	margin-bottom: 15px;
	text-align: center;
}
.widget-form-03 .item .icon {
	margin: 0 auto;
	text-align: center;
	display: block;
	background-color: transparent;
	width: 50px;
	height: 50px;
	border-radius: 3px;
	color: #000;
	font-size: 24px;
}
.widget-form-03 .item .content {
	padding: 10px 0;
}
.widget-form-03 .item:last-child {
	margin-bottom: 0;
}
.widget-form-03 .form-box {
	border: 1px solid #dddddd;
	padding: 45px;
	border-radius: 10px;
	background-color: #fafafa;
}
.widget-form-03 form input, .widget-form-03 form textarea {
	border: 1px solid #ccc;
	font-size: 14px;
	padding: 15px;
	margin-bottom: 15px;
	width: 100%;
	box-shadow: 0 2px 4px rgba(126,142,177,.12);
}
.widget-form-03 form textarea {
	min-height: 187px;
}

@media only screen and (min-width: 768px) and (max-width: 1023px) {
.widget-form-03 .item {
	width: 33.3%;
	float: left;
	padding-right: 15px;
	padding-left: 15px;
}
}
/*===================== Widget_38 (End) =====================*/

/*===================== Widget_39 (Start) =====================*/
.widget-form-04 form input, .widget-form-04 form textarea {
	border: 1px solid #f9b522;
	font-size: 14px;
	padding: 15px;
	color: #f9b522;
	margin-bottom: 15px;
	width: 100%;
	box-shadow: 0 2px 4px rgba(126,142,177,.12);
	background-color: #000;
}
.widget-form-04 form textarea {
	min-height: 150px;
}
.widget-form-04 .item-box {
	padding: 20px;
	background-color: #000;
	border: 1px solid #f9b522;
	float: left;
	width: 100%;
	min-height: 315px;
}
.widget-form-04 .item-box .item {
	margin-bottom: 20px;
	float: left;
	width: 100%;
	text-align: left;
}
.widget-form-04 {
}
.widget-form-04 .item-box .item .icon {
	border: 1px solid #f9b522;
	margin-bottom: 0;
	color: #f9b522;
	font-size: 24px;
	float: left;
	width: 50px;
	background-color: transparent;
	height: 50px;
	border-radius: 100px;
	margin-right: 20px;
}
.widget-form-04 .item-box .item .icon i.fa {
}
.widget-form-04 .item-box .item .item-content {
	overflow: hidden;
}
.widget-form-04 .item-box .item .item-content h6, .widget-form-04 .item-box .item .item-content p {
	color: #fff;
}
.widget-form-04 .item-box .item .item-content p {
	font-size: 14px;
}
.widget-form-04 .item-box .item .item-content h6 {
	font-size: 16px;
	margin-bottom: 0;
}
.widget-form-04 .item-box .item:last-child {
	margin-bottom: 0;
}

@media (max-width: 640px) {
.widget-form-04 .item-box {
	min-height: auto;
	height: auto;
	padding: 15px;
}
.widget-form-04 .item-box .item .item-content p {
	font-size: 12px;
}
}
/*===================== Widget_39 (End) =====================*/

/*===================== Widget_40 (Start) =====================*/
.widget-banner-03 {
	position: relative;
	height: 400px;
}
.widget-banner-03 .banner-content {
	padding: 50px 50px;
	background-color: #000;
	outline-offset: 5px;
	position: absolute;
	top: 50%;
	text-align: center;
	width: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
}
.widget-banner-03 .banner-content h6 {
	font-weight: bold;
	color: #ffffff;
	margin-bottom: 0;
	text-transform: uppercase;
}
.widget-banner-03 .banner-content h2 {
	text-transform: uppercase;
	margin-bottom: 0;
	color: #000;
}
.widget-banner-03 .banner-content p {
	font-size: 14px;
	margin-bottom: 0;
	color: #fff;
	font-weight: normal;
}

@media only screen and (min-width: 768px) and (max-width: 1024px) {
.widget-banner-03 .banner-content {
	width: 75%;
}
}

@media (max-width: 640px) {
.widget-banner-03 {
	height: 210px;
}
.widget-banner-03 .banner-content {
	width: 80%;
	padding: 10px;
}
.widget-banner-03 .banner-content h2 {
	font-size: 20px;
}
.widget-banner-03 .banner-content h6 {
	font-size: 12px;
}
.widget-banner-03 .banner-content p {
	font-size: 12px;
	line-height: 22px;
}
}
/*===================== Widget_40 (End) =====================*/

/*===================== Widget_41 (Start) =====================*/
.widget-funfact-01 {
}
.widget-funfact-01:before {
	content: '';
	width: 100%;
	height: 100%;
	position: absolute;
	top: 0;
	left: 0;
	background-color: rgba(0,0,0,0.5);
}
.widget-funfact-01 .item {
	text-align: center;
}
.widget-funfact-01 .item .icon {
	background-color: transparent;
	margin-bottom: 10px;
	color: #5352ed;
	font-size: 60px;
}
.widget-funfact-01 .item .icon i.fa {
	transform: translateY(0);
	top: 0;
}
.widget-funfact-01 .item .item-content {
}
.widget-funfact-01 .item .item-content p, .widget-funfact-01 .item .item-content h4 {
	color: #fff;
}
.widget-funfact-01 .item .item-content p {
	margin-bottom: 0;
}
.widget-funfact-01 .item .item-content h4 {
	position: relative;
	display: block;
	font-size: 70px;
	margin-bottom: 0;
	line-height: normal;
}
/*===================== Widget_41 (End) =====================*/

/*===================== Widget_42 (Start) =====================*/
.widget-intro-06 .item-box {
	width: 100%;
	position: relative;
	transition: all 0.2s ease-in-out;
	transform: translateY(0px);
}
.widget-intro-06 .item-box:hover {
	box-shadow: 0 4px 11px rgba(0, 0, 0, 0.12);
	position: relative;
	transition: all 0.2s ease-in-out;
	transform: translateY(-10px);
}
.widget-intro-06 .item-box .item-box-image {
	width: 100%;
	height: 240px;
	position: relative;
}
.widget-intro-06 .item-box .item-box-image img {
	width: 100%;
	height: 100%;
}
.widget-intro-06 .item-box .item-box-content {
	position: absolute;
	text-align: center;
	transform: translateX(-50%);
	left: 50%;
	width: 100%;
	bottom: -60px;
	transition: all 0.5s ease;
}
.widget-intro-06 .item-box .item-box-image:before {
	content: '';
	width: 100%;
	height: 100%;
	position: absolute;
	top: 0;
	left: 0;
	opacity: 0;
	background-color: #fff;
	transition: all 0.5s ease;
}
.widget-intro-06 .item-box .item-box-content h6 a {
	color: #000;
	font-size: 20px;
}
.widget-intro-06 .item-box:hover .item-box-image:before {
	opacity: 0.5;
	transition: all 0.5s ease;
}
.widget-intro-06 .item-box:hover .item-box-content {
	bottom: 0;
	background-color: #000;
	width: 100%;
	transition: all 0.5s ease;
	padding: 10px;
}
.widget-intro-06 .item-box:hover .item-box-content h6 a {
	color: #fff;
}
.widget-intro-06 .item-box .item-box-content h6 {
	margin-bottom: 0;
	padding: 10px 0;
}

@media (max-width: 1023px) and (min-width: 768px) {
.widget-intro-06 .item-box {
	margin: 30px 0;
}
.widget-intro-06 .item-box:last-child {
	margin-bottom: 0;
}
.widget-intro-06 .item-box .item-box-image {
	height: 260px;
}
}

@media (max-width: 640px) {
.widget-intro-06 .item-box {
	margin: 100px 0;
}
.widget-intro-06 .item-box:last-child {
	margin-bottom: 50px;
}
}
/*===================== Widget_42 (End) =====================*/

/*===================== Widget_43 (Start) =====================*/
.widget-feature-03 {
}
.widget-feature-03 .item-box-wrapper {
	padding-left: 50px;
}
.widget-feature-03 .item-box {
	width: 100%;
	display: table;
	border-top: 1px solid #f0f0f0;
	border-left: 1px solid #f0f0f0;
}
.widget-feature-03 .item-box .item {
	height: 213px;
	width: 33.333%;
	background-color: #ffffff;
	border-right: 1px solid #f0f0f0;
	border-bottom: 1px solid #f0f0f0;
	margin: 0;
	float: left;
	padding: 35px 30px;
	-webkit-box-shadow: 0 0.75rem 1.5rem rgba(18, 38, 63, 0.03);
	box-shadow: 0 0.75rem 1.5rem rgba(18, 38, 63, 0.03);
	position: relative;
}
.widget-feature-03 .item-box .item:hover {
	/*z-index: 999;*/
	-webkit-transform: scale(1.03);
	-ms-transform: scale(1.03);
	transform: scale(1.03);
	-o-transition: all 0.3s ease-in-out;
	transition: all 0.3s ease-in-out;
}
.widget-feature-03 .item-box .item:before {
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	opacity: 1;
	content: '';
	z-index: -1;
	background-color: #000;
	position: absolute;
	/* -webkit-transition: all 0.3s ease-in-out; */
	-o-transition: all 0.3s ease-in-out;
	transition: all 0.3s ease-in-out;
}
.widget-feature-03 .item-box .item:hover .icon, .widget-feature-03 .item-box .item:hover .item-content * {
	color: #fff;
}
.widget-feature-03 .item-box .item .icon {
	margin-bottom: 10px;
	background-color: transparent;
	color: #000;
	font-size: 48px;
	display: table;
	margin: 0 auto 15px;
}
.widget-feature-03 .item-box .item .icon i.fa {
	-webkit-transition: all 0.3s ease-in-out;
	-o-transition: all 0.3s ease-in-out;
	transition: all 0.3s ease-in-out;
	top: 0;
	transform: translateY(0);
}
.widget-feature-03 .item-box .item .item-content {
	text-align: center;
}
.widget-feature-03 .item-box .item .item-content h4 {
	font-size: 16px;
	margin-bottom: 0;
}
.widget-feature-03 .item-box .item .item-content p {
	font-size: 14px;
	text-align: center;
	margin-bottom: 0;
	line-height: 24px;
}
.widget-feature-03 .item-box-wrapper {
	padding-left: 50px;
}

@media (max-width: 1024px) and (min-width: 768px) {
.widget-feature-03 .item-box-wrapper {
	padding: 30px 0 0 0;
}
}

@media (max-width: 640px) {
.widget-feature-03 .item-box-wrapper {
	padding: 30px 0 0 0;
}
.widget-feature-03 .item-box .item {
	width: 100%;
	height: auto;
}
}
/*===================== Widget_43 (End) =====================*/

/*===================== Widget_44 (Start) =====================*/
.widget-service-09 {
}
.widget-service-09 .item {
	text-align: center;
	float: left;
	width: 100%;
}
.widget-service-09 .item .icon {
	background-color: #000;
	width: 100px;
	height: 100px;
	border-radius: 100px;
	line-height: 80px;
	font-size: 30px;
	text-align: center;
	position: relative;
}
.widget-service-09 .item .icon:after {
	top: 1px;
	left: 1px;
	content: '';
	width: 90px;
	height: 90px;
	margin: 5px;
	border-radius: 50%;
	position: absolute;
	border: 1px dashed #fff;
}
.widget-service-09 .item .item-content {
}
.widget-service-09 .item .item-content h6 {
	font-size: 20px;
}
.widget-service-09 .item .item-content p {
	font-size: 14px;
	margin: 0;
}
section.widget-service-09[class*="theme-dark-color"] .item-content * {
	color: #fff;
}
section.widget-service-09[class*="theme-dark-color"] .item .icon {
	background-color: #fff;
	width: 100px;
	height: 100px;
	border-radius: 100px;
	color: #000;
}
section.widget-service-09[class*="theme-dark-color"] .item .icon:after {
	border: 1px dashed #000;
}

@media (min-width: 768px) and (max-width: 1024px) {
.widget-service-09 .item {
	margin-bottom: 30px;
	padding: 0 30px;
}
}

@media (max-width: 640px) {
.widget-service-09 .item {
	margin-bottom: 30px;
}
}
/*===================== Widget_44 (End) =====================*/

/*===================== Widget_45 (Start) =====================*/
.widget-feature-05 {
	position: relative;
}
.widget-feature-05::before {
	content: '';
	position: absolute;
	left: 50%;
	z-index: 3;
	width: 280px;
	height: 39px;
	background: url(../images/arrow-top.png) no-repeat;
	transform: translateX(-50%);
	top: 0;
}
.widget-feature-05::after {
	content: '';
	position: absolute;
	left: 50%;
	z-index: 3;
	width: 280px;
	height: 39px;
	background: url(../images/arrow-bottom.png) no-repeat;
	transform: translateX(-50%);
	bottom: 0;
}
.widget-feature-05 .feature-box {
	float: left;
	width: 100%;
}
.widget-feature-05 .feature-box-image {
	margin: 0 auto -110px auto;
	width: 220px;
	position: relative;
	height: 220px;
	z-index: 99;
}
.widget-feature-05 .feature-box-image img {
	display: block;
	margin: 0 auto;
	border-radius: 100%;
	width: 100%;
	height: 100%;
}
.widget-feature-05 .feature-box-image:after {
	top: 0;
	left: 50%;
	content: '';
	width: 220px;
	height: 220px;
	position: absolute;
	margin: 0 0 0 -110px;
	border-radius: 100%;
	border: 10px solid rgba(225, 225, 225, 0.5);
}
.widget-feature-05 .feature-box-content {
	background: #fff;
	border-radius: 10px;
	padding: 140px 20px 0;
	text-align: center;
}
.widget-feature-05 .feature-box-content h4 {
	font-size: 20px;
}
.widget-feature-05 .feature-box-content p {
	font-size: 14px;
}
.widget-feature-05 .feature-box-content a.theme-button {
	margin: 0 auto -20px;
}
section.widget-feature-05[class*="theme-dark-color"] .feature-box-content * {
	color: #000;
}
.widget-feature-05 .feature-box-content a.theme-button {
	color: #fff;
}
.widget-feature-05 .feature-box-content a.theme-button:hover {
	color: #000;
}

@media (max-width: 991px) {
.widget-feature-05 .feature-box {
	margin: 0 0 40px;
}
}
/*===================== Widget_45 (End) =====================*/

/*===================== Widget_46 (Start) =====================*/
.widget-feature-04 {
}
.widget-feature-04 .item {
	position: relative;
	width: 100%;
	float: left;
	transition: all 0.5s ease;
}
.widget-feature-04 .item .item-thumb {
	width: 100%;
	height: 360px;
	border: 6px solid #f4f4f4;
}
.widget-feature-04 .item .item-thumb img {
	width: 100%;
	height: 100%;
}
.widget-feature-04 .item .item-info {
	background-color: rgba(255,255,255,0.7);
	z-index: 111;
	text-align: center;
	border-radius: 10px 10px 0 0;
	position: absolute;
	width: 80%;
	left: 50%;
	transform: translateX(-50%);
	bottom: 0;
	transition: all 0.5s ease;
}
.widget-feature-04 .item:hover .item-info .item-button {
	margin-bottom: 20px;
	transition: all 0.5s ease;
}
.widget-feature-04 .item .item-info p {
	font-weight: normal;
}
.widget-feature-04 .item .item-info h4 {
	font-size: 16px;
	margin-bottom: 0;
	background-color: #000;
	padding: 8px 0;
	color: #fff;
}
.widget-feature-04 .item .item-info .item-button {
	margin-bottom: -61px;
	margin-top: 20px;
}
.widget-feature-04 .item .item-info .item-button a {
	font-size: 14px;
	text-transform: uppercase;
	font-family: 'Open Sans', sans-serif;
	font-weight: normal;
}

@media (max-width: 1023px) and (min-width: 768px) {
.widget-feature-04 .item .item-thumb {
	height: 200px;
}
.widget-feature-04 .item .item-info .item-button {
	margin-bottom: -39px;
	margin-top: 10px;
}
.widget-feature-04 .item .item-info h4 {
	font-size: 13px;
}
.widget-feature-04 .item .item-info .item-button a {
	font-size: 12px;
	padding: 8px 12px;
}
.widget-feature-04 .item:hover .item-info .item-button {
	margin-bottom: 15px;
}
}

@media (max-width: 640px) {
.widget-feature-04 .item {
	margin-bottom: 90px;
}
.widget-section.widget-feature-04 div[class*="col-"]:last-child .item {
	margin-bottom: 90px;
}
}
/*===================== Widget_46 (End) =====================*/

/*===================== Widget_47 (Start) =====================*/
.widget-about-04 {
}
.widget-about-04 .about-img {
	width: 100%;
	height: 360px;
}
.widget-about-04 .about-img img {
	width: 100%;
	height: 100%;
}
.widget-about-04 .about-content {
	padding: 20px;
	width: 100%;
	float: left;
}
.widget-about-04 .about-content ul {
	list-style: none;
	margin: 0;
	padding: 0;
}
.widget-about-04 .about-content ul li {
	margin-bottom: 10px;
	font-size: 16px;
	text-transform: capitalize;
	color: #000;
	position: relative;
	padding-left: 20px;
}
.widget-about-04 .about-content ul li:after {
	top: 0;
	left: 0;
	font-size: 14px;
	content: '\f00c';
	position: absolute;
	font-weight: 900;
	font-family: FontAwesome;
	color: #000;
}
.widget-about-04 .about-content ul li:last-child {
	margin-bottom: 0;
}
.widget-about-04 .funfact {
	width: 100%;
	float: left;
	padding: 10px 20px 0 20px;
}
.widget-about-04 .funfact .item {
	width: 25%;
	float: left;
	text-align: left;
}
.widget-about-04 .funfact .item h4 {
	margin-bottom: 0;
	color: #000;
}
.widget-about-04 .funfact .item p {
	margin-bottom: 0;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-about-04 .about-content {
	text-align: left;
}
.widget-about-04 .about-content h2 {
	text-align: center;
}
.widget-about-04 .about-content ul {
}
.widget-about-04 .about-content ul li {
	display: block;
	width: 50%;
	font-size: 14px;
	float: left;
}
.widget-about-04 .funfact .item {
	text-align: center;
}
}

@media (max-width: 640px) {
.widget-about-04 .about-img {
	height: 200px;
}
.widget-about-04 .about-content {
	padding: 20px 0;
	text-align: left;
}
.widget-about-04 .about-content ul li {
	font-size: 13px;
	width: 100%;
	float: left;
	margin-bottom: 20px;
}
.widget-about-04 .about-content ul li:after {
	font-size: 12px;
}
.widget-about-04 .funfact {
	padding: 0;
}
.widget-about-04 .funfact .item {
	text-align: center;
	padding-bottom: 10px;
	width: 50%;
}
}
/*===================== Widget_47 (End) =====================*/

/*===================== Widget_48 (Start) =====================*/
.widget-about-05 .widget-about-content ul {
	list-style: none;
	margin: 0;
	padding: 10px 0;
	text-align: left;
	width: 100%;
	float: left;
}
.widget-about-05 .widget-about-content ul li {
	margin-bottom: 10px;
	color: #000;
	font-size: 14px;
	display: block;
	width: 50%;
	float: left;
}
.widget-about-05 .widget-about-content ul li:before {
    content: '';
    font-family: 'FontAwesome';
    content: '\f111';
    margin: 0 5px 0 0px;
    color: #000;
	
}
.widget-about-05 .widget-about-content ul li:last-child {
	margin-bottom: 0;
}
.widget-about-05 .widget-about-content ul li span.fa {
	font-size: 14px;
	color: #000;
	margin-right: 10px;
	display:none !important;
}
.widget-about-05 .widget-about-content p {
	text-align: left;
}
.widget-about-05 .widget-about-image {
	height: 360px;
	width: 100%;
}
.widget-about-05 .widget-about-image img {
	width: 100%;
	height: 100%;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-about-05 .widget-about-content {
	text-align: center;
	margin-bottom: 30px;
}
.widget-about-05 .widget-about-content p {
	text-align: center;
}
.widget-about-05 .widget-about-content ul {
	text-align: center;
}
.widget-about-05 .widget-about-content ul li {
	text-align: left;
	width: auto;
	margin-right: 15px;
	display: inline-block;
	float: none;
}
.widget-about-05 .widget-about-image {
	height: 400px;
}
.widget-about-05 .widget-about-image img {
	height: 100%;
}
}

@media (max-width: 640px) {
.widget-about-05 .widget-about-content {
	text-align: center;
}
.widget-about-05 .widget-about-content p {
	text-align: center;
}
.widget-about-05 .widget-about-content ul {
	text-align: center;
	margin-bottom: 10px;
}
.widget-about-05 .widget-about-content ul li {
	display: block;
	float: none;
	text-align: left;
	width: auto;
}
.widget-about-05 .widget-about-image {
	height: 200px;
}
}
/*===================== Widget_48 (End) =====================*/

/*===================== Widget_49 (Start) =====================*/
.widget-banner-04 .banner-thumb {
	width: 100%;
	height: 360px;
	position: relative;
	border-radius: 10px;
}
.widget-banner-04 .banner-thumb img {
	width: 100%;
	height: 100%;
	border-radius: 10px 0px 0 10px;
}
.widget-banner-04 .banner-content {
	padding: 85px 40px;
	text-align: center;
	box-shadow: 0px 0px 10px 0px rgba(0,0,0,.1);
	border-radius: 0px 10px 10px 0;
	height: 360px;
}
.widget-banner-04 .banner-content h2 {
	font-size: 36px;
	font-weight: 900;
	margin-bottom: 10px;
	color: #000;
}
.widget-banner-04 .banner-content p {
	font-size: 16px;
	text-transform: capitalize;
	margin-bottom: 10px;
}
.widget-banner-04 .banner-content h6 {
	font-family: 'Open Sans', sans-serif;
	margin-bottom: 10px;
	font-weight: bold;
	font-size: 16px;
}
.widget-banner-04 .banner-content p strong {
	color: #000000;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-banner-04 .banner-thumb img {
	border-radius: 10px 10px 0 0;
}
.widget-banner-04 .banner-content {
	border-radius: 0px 0px 10px 10px;
}
}

@media (max-width: 640px) {
.widget-banner-04 .banner-thumb {
	height: 180px;
}
.widget-banner-04 .banner-thumb img {
	border-radius: 0;
}
.widget-banner-04 .banner-content {
	border-radius: 0;
	padding: 50px 20px;
}
.widget-banner-04 .banner-content h6 {
	font-size: 14px;
	margin-bottom: 10px;
}
.widget-banner-04 .banner-content h2 {
	font-size: 20px;
	margin-bottom: 10px;
}
.widget-banner-04 .banner-content p {
	font-size: 14px;
}
}
/*===================== Widget_49 (End) =====================*/

/*===================== Widget_50 (Start) =====================*/
.widget-about-06 {
}
.widget-about-06 .about-content {
	width: 100%;
	float: left;
}
.widget-about-06 .item {
	width: 50%;
	float: left;
	margin: 20px 0;
}
.widget-about-06 .item .icon {
	color: #000;
	margin-bottom: 0;
	background-color: transparent;
	float: left;
	font-size: 24px;
	margin-right: 15px;
	width: 50px;
	height: 50px;
}
.widget-about-06 .item .icon i.fa {
	top: 0;
	transform: translateY(0);
	line-height: 50px;
}
.widget-about-06 .item .item-content {
	overflow: hidden;
}
.widget-about-06 .item .item-content h6, .widget-about-05 .item .item-content p {
	margin-bottom: 0;
}
.widget-about-06 .item .item-content p {
	font-size: 14px;
}
.widget-about-06 .about-image-small {
	overflow: hidden;
	width: 100%;
	float: left;
}
.widget-about-06 .about-image-small .image-list {
	overflow: hidden;
	margin-bottom: 10px;
	width: 100%;
	height: 180px;
}
.widget-about-06 .about-image-small .image-list img {
	width: 50%;
	float: left;
	height: 100%;
}
.widget-about-06 .about-image-small .image-list img:first-child {
	padding-right: 10px;
}
.widget-about-06 .about-image-large {
	width: 100%;
	height: 250px;
	float: left;
}
.widget-about-06 .about-image-large img {
	width: 100%;
	height: 100%;
}

@media (max-width: 1023px) and (min-width: 768px) {
.widget-about-06 .item {
	padding: 20px 50px;
	margin: 0;
}
.widget-about-06 .item .icon {
	float: none;
	margin-bottom: 10px;
	margin-right: 0;
}
.widget-about-06 .item .item-content {
	text-align: center;
}
.widget-about-06 .about-image-large {
	height: 360px;
}
}

@media (max-width: 640px) {
.widget-about-06 .item {
	width: 100%;
	float: none;
	text-align: center;
}
.widget-about-06 .item .icon {
	float: none;
	margin-right: 0;
	margin-bottom: 15px;
}
.widget-about-06 .about-image-small .image-list {
	height: 80px;
}
.widget-about-06 .about-image-large {
	height: 180px;
}
}
/*===================== Widget_50 (End) =====================*/

/*===================== Widget_51 (Start) =====================*/
.widget-team-member-07 {
	position: relative;
}
.widget-team-member-07 .team {
	background: #fff;
	padding: 10px;
	-moz-transition-duration: .3s;
	-webkit-transition-duration: .3s;
	-o-transition-duration: .3s;
	transition-duration: .3s;
	position: relative;
	box-shadow: 0 1px 15px 1px rgba(52,40,104,.1);
	margin-bottom: 30px;
}
.widget-team-member-07 .team .team-thumb {
	width: 100%;
	height: 240px;
	position: relative;
}
.widget-team-member-07 .team .team-thumb:before {
	content: '';
	width: 100%;
	height: 100%;
	position: absolute;
	top: 0;
	left: 0;
	background-color: rgba(0,0,0,0.5);
	opacity: 0;
}
.widget-team-member-07 .team:hover .team-thumb:before {
	opacity: 1;
}
.widget-team-member-07 .team .team-thumb img {
	width: 100%;
	height: 100%;
}
.widget-team-member-07 .team .team-content {
	text-align: center;
	margin-top: 15px;
	position: absolute;
	bottom: 30px;
	left: 50%;
	transform: translateX(-50%);
	-webkit-transition: all .3s ease-in-out 0s;
	-moz-transition: all .3s ease-in-out 0s;
	-o-transition: all .3s ease-in-out 0s;
	transition: all .3s ease-in-out 0s;
	width: 95%;
}
.widget-team-member-07 .team:hover .team-content {
	bottom: 100px;
	opacity: 1;
	visibility: visible;
	width: 100%;
}
.widget-team-member-07 .team .team-content * {
	color: #fff;
}
.widget-team-member-07 .team .team-content ul {
	list-style: none;
	margin: 0;
	padding: 0;
}
.widget-team-member-07 .team .team-content ul li {
	display: inline-block;
	margin-right: 15px;
}
.widget-team-member-07 .team .team-content h4 {
	font-size: 20px;
	margin-bottom: 0;
}
.widget-team-member-07 .team .team-content p {
	margin-bottom: 0;
}
.widget-team-member-07 .team:hover {
	background-color: 000;
}
.widget-team-member-07 .team .socail-media-icons {
	position: absolute !important;
	opacity: 0;
	width: 50px;
	visibility: hidden;
	-webkit-transition: all 0.3s ease-in;
	-moz-transition: all 0.3s ease-in;
	-ms-transition: all 0.3s ease-in;
	-o-transition: all 0.3s ease-in;
	top: 50%;
	transition: all 0.3s ease-in;
	right: -30px;
	transform: translateY(-50%);
	background-color: #000;
}
.widget-team-member-07 .team .socail-media-icons ul {
	list-style: none;
	padding: 0;
	text-align: center;
	margin: 0 auto;
}
.widget-team-member-07 .team .socail-media-icons ul li {
	display: block;
	width: 30px;
	height: 30px;
	text-align: center;
	margin: 10px auto;
	line-height: 30px;
}
.widget-team-member-07 .team .socail-media-icons ul li a span {
	color: #ffffff;
	font-size: 20px;
}
.widget-team-member-07 .team:hover .socail-media-icons {
	opacity: 1;
	visibility: visible;
	right: 0;
}
.widget-team-member-07 .team:hover {
	background-color: #000;
}
.widget-team-member-07 .team:hover .team-content {
	bottom: 100px;
	opacity: 1;
	visibility: visible;
	width: 100%;
}
.widget-team-member-07 a.theme-button {
	margin: 20px 0 0 0;
}
/*===================== Widget_51 (End) =====================*/

/*===================== Widget_52 (Start) =====================*/
.widget-service-10 {
	position: relative;
}
.widget-service-10:before {
	content: '';
	width: 100%;
	height: 100%;
	position: absolute;
	top: 0;
	left: 0;
	background-color: rgb(0, 0, 0, 0.7);
}
.widget-service-10 .item {
	text-align: center;
	padding: 30px;
	border: 1px solid #fff;
}
.widget-service-10 .item .icon {
	margin-bottom: 10px;
	background-color: transparent;
	color: #fff;
	font-size: 50px;
}
.widget-service-10 .item .icon i.fa {
	top: 0;
	transform: translateY(0);
}
.widget-service-10 .item .item-content {
}
.widget-service-10.item .item-content h4 {
	color: #fff;
	margin-bottom: 0;
}
.widget-service-10 .item .item-content p, .widget-service-10 .item .item-content h4 {
	color: #fff;
}
.widget-service-10 .item .item-content p {
	margin-bottom: 0;
	color: #fff;
	font-size: 14px;
}

@media (max-width: 1023px) and (min-width: 768px) {
.widget-service-10 .item {
	width: 50%;
	margin: 0 auto 30px auto;
	text-align: center;
}
}
/*===================== Widget_52 (End) =====================*/

/*===================== Widget_53 (Start) =====================*/
.widget-table-list-02 .table {
	width: 100%;
}
.widget-table-list-02 .table .srial {
	width: 70px;
	text-align: center;
	font-weight: 600;
}
.widget-table-list-02.table .session {
	padding: 0px 37px;
	width: 310px;
}
.widget-table-list-02 .table .session i {
	margin-right: 10px;
}
.widget-table-list-02 .table .speakers {
	padding: 0px 35px;
	width: 300px;
}
.widget-table-list-02 .table .time {
	padding: 0px 40px;
	width: 195px;
}
.widget-table-list-02 .table .time i {
	margin-right: 10px;
	font-size: 15px;
}
.widget-table-list-02 .table .venue {
	padding: 0px 35px;
	width: 185px;
}
.widget-table-list-02 .table thead tr {
	background-color: #000;
	height: 75px;
}
.widget-table-list-02 .table-hover tbody tr:hover {
	background: #f3f3f3!important;
}
.widget-table-list-02 .table thead tr th, .widget-table-list-02 .table tbody tr td {
	border-right: 1px solid #ccc;
}
.widget-table-list-02 .table tbody tr td {
	border-left: 1px solid #ccc;
	border-bottom: 1px solid #ccc;
}
.widget-table-list-02 .table thead tr th {
	font-size: 20px;
	font-weight: bold;
	color: #fff;
	vertical-align: middle;
	text-align: left;
	border-bottom: 0;
	padding: 20px;
}
.widget-table-list-02 .table tbody tr td {
	font-size: 16px;
	font-weight: 400;
	color: #000000;
	vertical-align: middle;
	text-align: left;
	padding: 20px;
	background-color: #fff;
}
.widget-table-list-02 .table .speakers {
	position: relative;
}
.widget-table-list-02 .table .speakers figure {
	margin-bottom: 0px;
}

.widget-table-list-02 .table .speakers img {
	position: absolute;
	top: 10px;
	left: 30px;
	border-radius: 50%;
}
.widget-table-list-02 .table .speakers h6 {
	position: relative;
	padding-left: 60px;
	vertical-align: middle;
	font-family: 'Robtoto', sans-serif;
	font-size: 18px;
	font-weight: 500;
}
/*===================== Widget_53 (End) =====================*/

/*===================== Widget_54 (Start) =====================*/
.widget-pricing-02 .plan {
	position: relative;
	padding: 0;
	border: 1px solid #eaeaea;
	cursor: pointer;
	text-align: center;
	transition: all 300ms ease;
	box-shadow: 0 0 20px 7px #f7f7f7;
	border-radius: 10px;
}
.widget-pricing-02 .plan .plan-header {
	padding: 30px 0;
}
.widget-pricing-02 .plan .plan-header h6 {
	font-weight: normal;
	margin-bottom: 0;
}
.widget-pricing-02 .plan .plan-header h4 {
	font-weight: 900;
	margin-bottom: 0;
	color: #000;
}
.widget-pricing-02 .plan .plan-body {
	padding: 30px 0;
	background-color: #000;
}
.widget-pricing-02 .plan .plan-body ul {
	list-style: none;
	margin: 0;
	padding: 0;
}
.widget-pricing-02 .plan .plan-body ul li {
	padding: 10px 0;
	font-weight: normal;
	color: #fff;
	text-transform: uppercase;
}
.widget-pricing-02 .plan .plan-body ul li span.fa {
	color: #fff;
	position: relative;
	left: 10px;
}
.widget-pricing-02 .plan .plan-button {
	padding: 20px 0;
}
.widget-pricing-02 .plan .plan-button a {
	color: #000;
	text-transform: uppercase;
	font-size: 14px;
	text-decoration: none;
	font-weight: bold;
}
.widget-pricing-02[class*="theme-dark-color-"] .page-heading * {color:#fff;}
.widget-pricing-02[class*="theme-light-color-"] .page-heading * {color:#000;}
/*===================== Widget_54 (End) =====================*/

/*===================== Widget_55 (Start) =====================*/
.widget-form-05 .form-box {
	padding: 50px;
	background-color: #000;
	margin: 80px 0;
}
.widget-form-05 form h2 {
	margin-bottom: 50px;
	color: #fff;
}
.widget-form-05 form input, .widget-form-05 form textarea {
	border: 1px solid #ccc;
	font-size: 14px;
	padding: 15px;
	margin-bottom: 15px;
	width: 100%;
	box-shadow: 0 2px 4px rgba(126,142,177,.12);
}
.widget-form-05 form textarea {
	min-height: 187px;
}
.widget-form-05 .item {
}
.widget-form-05 .item .icon {
	background-color: transparent;
	color: #000;
	font-size: 36px;
	margin-bottom: 10px;
}
.widget-form-05 .item .icon i.fa {
	top: 0;
	transform: translateY(0);
}
.widget-form-05 .item-content {
	overflow: hidden;
}
.widget-form-05 .item-content h4 {
	font-size: 20px;
	margin-bottom: 0;
}
.widget-form-05 .item-content p {
	margin-bottom: 0;
}
/*===================== Widget_55 (End) =====================*/

/*===================== Widget_56 (Start) =====================*/
.widget-intro-07 .simple-image {
	width: 100%;
	height: 450px;
	position: relative;
	z-index: 9;
}
.widget-intro-07 .simple-image:before {
	content: "";
	background-color: #000;
	width: 100%;
	height: 100%;
	position: absolute;
	left: -20px;
	top: 20px;
	z-index: -1;
}
.widget-intro-07 .simple-image img {
	width: 100%;
	height: 100%;
}
.widget-intro-07 .widget-content {
	padding: 0;
	width: 100%;
	float: left;
}
.widget-intro-07 .widget-content ul {
	padding-left: 0;
	margin-bottom: 0;
	list-style: none;
	padding-top: 20px;
}
.widget-intro-07 .widget-content ul li {
	font-weight: normal;
	text-transform: capitalize;
	text-align: left;
	font-size: 14px;
	transition: all 0.5s ease;
	margin-bottom: 10px;
	display: block;
	float: left;
	width: 33.3%;
}
.widget-intro-07 .widget-content ul li:before {
    font-family: 'FontAwesome';
    content: '\f105';
    margin: 0 5px 0 0px;
    font-weight: bold;
	color:#000;
}
.widget-intro-07 .widget-content ul li span.fa {
	color: #F39C12;
	font-size: 20px;
	font-weight: bold;
	margin-right: 10px;
	display:none !important;
}
.widget-intro-07 .widget-content ul li:hover a {
	padding-left: 5px;
	color: #000;
	transition: all 0.5s ease;
	font-weight: bold;
}
.widget-intro-07 p:first-child:first-letter {
	font-size: 70px;
	font-weight: bold;
	color: #000;
	line-height: 40px;
	margin-right: 5px;
	float: left;
	padding-right: 10px;
}

@media (max-width: 768px) {
.widget-intro-07 .simple-image {
	height: 260px;
}
.widget-intro-07 .widget-content {
	text-align: left;
}
}

@media (max-width: 640px) {
.widget-intro-07 .simple-image {
	height: 360px;
	margin-bottom: 60px;
}
.widget-intro-07 .widget-content {
	text-align: left;
}
.widget-intro-07 .widget-content p {
	font-size: 14px;
}
.widget-intro-07 .widget-content ul li {
	width: 50%;
}
}
/*===================== Widget_56 (End) =====================*/

/*===================== Widget_57 (Start) =====================*/
.widget-banner-05 {
	position: relative;
}
.widget-banner-05:before {
	content: '';
	width: 100%;
	height: 100%;
	left: 0;
	position: absolute;
	top: 0;
	background-color: #000;
	opacity: 0.7;
}
.widget-banner-05 .content {
	padding: 50px;
}
.widget-banner-05 .content h6 {
	font-size: 18px;
	font-weight: 100;
	margin-bottom: 0;
	color: #fff;
}
.widget-banner-05 .content p {
	color: #fff;
}
.widget-banner-05 .content h2 {
	color: #fff;
	font-size: 40px;
}
.widget-banner-05 .content p {
	font-size: 16px;
	line-height: 25px;
	margin-bottom: 0;
	font-weight: 100;
}
.widget-banner-05 form {
	padding: 20px;
	background-color: rgba(255,255,255,0.1);
	border: 1px solid #cdcdcd;
}
.widget-banner-05 form label, .widget-banner-05 form textarea label {
	color: #fff;
	font-size: 14px;
	font-weight: 400;
	font-family: 'Open Sans', sans-serif;
}
.widget-banner-05 form input[type="text"], .widget-banner-05 form input[type="email"], .widget-banner-05 form textarea {
	padding: 10px;
	border: 0;
	border: 1px solid #cdcdcd;
	color: #000;
	width: 100%;
	outline: 0;
	background-color: rgba(255,255,255,0.5);
}
.widget-banner-05 form input[type="text"], .widget-banner-05 form input[type="email"], .widget-banner-05 form textarea {
}
.widget-banner-05 form button.theme-button {
	background-color: #000;
	color: #fff;
	font-size: 14px;
	font-weight: bold;
	display: block;
	border-radius: 5px;
	padding: 10px 20px;
	margin: 0 auto;
}
.form-btn {
	text-align: center;
}
.widget-banner-05[class*="theme-dark-color"] *  {
	color: #fff;
}
@media (max-width: 640px) {
.widget-banner-05 .content {
	padding: 20px;
	text-align: center;
	margin-bottom: 30px;
}
.widget-banner-05 .content h6 {
	font-size: 16px;
}
.widget-banner-05 .content h2 {
	font-size: 24px;
}
.widget-banner-05 .content p {
	font-size: 14px;
}
}
/*===================== Widget_57 (End) =====================*/

/*===================== Widget_58 (Start) =====================*/
.widget-about-07 .item-box {
	margin-bottom: 30px;
}
.widget-about-07 .item-box .item-box-image {
	width: 100%;
	height: 330px;
	margin-bottom: 10px;
}
.widget-about-07 .item-box .item-box-image img {
	width: 100%;
	height: 100%;
}
.widget-about-07 .item-box .item-box-content {
	text-align: left;
	padding-top: 20px;
}
.widget-about-07 .item-box .item-box-content:nth-child(1) {
	padding-top: 20px;
	padding-bottom: 50px;
}
.widget-about-07 .item-box .item-box-content:nth-child(2) {
	padding-top: 20px;
	padding-bottom: 20px;
}
/*===================== Widget_58 (End) =====================*/

/*===================== Widget_59 (Start) =====================*/
.widget-service-11 .item {
	border: 1px solid #ddd;
	background: #fff;
	text-align: center;
	margin-bottom: 30px;
	box-shadow: 0px 0px 4px 0px rgba(0,0,0,0.06);
	transition: all .3s ease;
	-webkit-transition: all .3s ease;
	-moz-transition: all .3s ease;
	-o-transition: all .3s ease;
	-ms-transition: all .3s ease;
}
.widget-service-11 .item:hover {
	transform: translateY(-5px);
	box-shadow: 0px 6px 14px 0px rgba(0,0,0,0.05);
}
.widget-service-11 .item:hover .icon {
	transform: rotateY(180deg);
	transition: all .7s ease;
	-webkit-transition: all .7s ease;
	-moz-transition: all .7s ease;
	-o-transition: all .7s ease;
	-ms-transition: all .7s ease;
}
.widget-service-11 .item .icon {
	margin: auto;
	position: relative;
	padding: 19px 19px 19px 17px;
	color: #000;
	font-size: 50px;
	background-color: transparent;
}
.widget-service-11 .item .icon:after {
	position: absolute;
	content: "";
	background: #f39c12;
	bottom: 0;
	width: 65px;
	height: 1px;
	margin: auto;
	left: 0;
	text-align: center;
	right: 0;
}
.widget-service-11 .item .icon i.fa {
	top: 0;
	transform: translateY(0);
}
.widget-service-11 .item-content {
	padding: 20px 60px 50px;
}
.widget-service-11 .item-content h3 {
	color: #000;
	font-size: 24px;
}
.widget-service-11 .item-content p {
	font-size: 15px;
	color: #000;
	margin-bottom: 0;
}
/*===================== Widget_59 (End) =====================*/

/*===================== Widget_60 (Start) =====================*/
.widget-form-07 .heading {
	text-align: left;
	padding: 30px 0 30px 50px;
	display: block;
	float: left;
}
.widget-form-07 .form-box form label {
	display: none;
}
.widget-form-07 .form-box {
	background-color: #fff;
}
.widget-form-07 .form-box form {
	padding: 50px;
	position: relative;
	text-align: left;
}
.widget-form-07 .form-heading {
	text-align: left;
	margin-bottom: 30px;
}
.widget-form-07 .contact-information {
	position: absolute;
	top: 50%;
	right: -50px;
	width: 300px;
	background-color: #000;
	padding: 30px;
	-webkit-box-shadow: 0px 10px 20px 0px rgba(0, 25, 50, 0.1);
	box-shadow: 3px 5px 5px 0px rgba(0, 0, 0, 0.5);
	transform: translateY(-50%);
}
.widget-form-07 .contact-information .item {
	margin-bottom: 10px;
	width: 100%;
	float: left;
}
.widget-form-07 .contact-information .item .icon {
	background-color: transparent;
	display: block;
	text-align: left;
	font-size: 20px;
	float: left;
	color: #f39c12;
	margin-right: 20px;
	position: relative;
	top: 2px;
}
.widget-form-07 .contact-information .item .icon i.fa {
	top: 0;
	transform: translateY(0);
}
.widget-form-07 .contact-information .item .item-content {
	float: left;
	width: 80%;
	text-align: left;
}
.widget-form-07 .contact-information .item .item-content h6 {
	color: #fff;
	margin-bottom: 0;
}
.widget-form-07 .contact-information .item .item-content p {
	color: #fff;
	font-size: 14px;
}
.widget-form-07 .submit-btn {
	text-align: left;
}
.widget-form-07 .contact-information .item:last-child {
	margin-bottom: 0;
}
.widget-form-07 .social-icons {
	width: 100%;
	float: left;
	padding: 20px 0 0 0;
}
.widget-form-07 .social-icons ul {
	list-style: none;
	margin: 0;
}
.widget-form-07 .social-icons ul li {
	background-color: transparent;
	width: 36px;
	height: 36px;
	line-height: 36px;
	font-size: 16px;
	border: 1px solid #f39c12;
	float: left;
	margin-right: 15px;
}
.widget-form-07 .social-icons ul li a {
}
.widget-form-07 .social-icons ul li a i.fa {
	color: #f39c12;
}
.widget-form-07 .social-icons ul li a span.fa {
	color: #f39c12;
}
.widget-form-07 .contact-information .item .icon:after {
	width: 2px;
	height: 20px;
	position: absolute;
	top: 0;
	right: -10px;
	background-color: #f39c12;
}
.widget-form-07 .form-box form input, .widget-form-07 .form-box form textarea {
	width: 65%;
	padding: 10px;
	outline: 0;
	font-size: 14px;
	box-shadow: 0 2px 4px rgba(126,142,177,.12);
	border: 1px solid #2b3d4f;
	margin-bottom: 20px;
}
.widget-form-07 .form-box form textarea {
	min-height: 150px;
}
/*===================== Widget_60 (End) =====================*/

/*===================== Widget_61 (Start) =====================*/
.widget-intro-08 .about-image {
	width: 100%;
	height: 460px;
	position: relative;
}
.widget-intro-08 .about-image img {
	width: 100%;
	height: 100%;
	position: relative;
	border-radius: 7px;
}
section.widget-section.widget-intro-08 p {
	color: #000;
}
section.widget-section.widget-intro-08 h2 {
	font-size: 60px;
}
section.widget-section.widget-intro-08 h6 {
	font-size: 20px;
	font-weight: 100;
}
section.widget-section.widget-intro-08 p {
	-webkit-column-count: 2;
	-moz-column-count: 2;
	column-count: 2;
}

.widget-intro-08 .info-list ul {
	list-style: none;
	margin: 20px 0 0 0;
	padding: 0;
}
.widget-intro-08 .info-list ul li {
	display: inline-block;
	width: 49%;
	margin-bottom: 20px;
	font-size: 16px;
	color: #000;
}
.widget-intro-08 .info-list ul li span.fa {
	margin-right: 10px;
	color: #000;
	font-size: 16px;
}
.widget-intro-08 .row.mt-50 {
	margin-top: 100px;
}

@media (min-width: 768px) and (max-width: 1023px) {
section.widget-section.widget-intro-08 .about-image {
	height: 600px;
}
section.widget-section.widget-intro-08 h2 {
	margin-top: 30px;
}
section.widget-section.widget-intro-08 h2, section.widget-section.widget-intro-08 h6, section.widget-section.widget-intro-08 p, section.widget-section.widget-intro-08 ul li {
	text-align: left;
}
}

@media (max-width: 640px) {
section.widget-section.widget-intro-08 p {
	-webkit-column-count: 2;
	-moz-column-count: 1;
	column-count: 1;
}
section.widget-section.widget-intro-08 h2 {
	font-size: 40px;
	margin-top: 20px;
}
section.widget-section.widget-intro-08 ul li {
	width: 100%;
	text-align: center;
}
section.widget-section.widget-intro-08 ul li span.fa {
	width: 100%;
	margin-bottom: 10px;
}
.widget-intro-08 .about-image {
	height: 360px;
}
}
/*===================== Widget_61 (End) =====================*/

/*===================== Widget_62 (Start) =====================*/
section.widget-feature-06 .row.mb-50 {
	margin-bottom: 50px;
}
section.widget-section.widget-feature-06 .feature-box {
	margin-bottom: 70px;
	position: relative;
	padding: 0 0 0 50px;
}
section.widget-section.widget-feature-06 .feature-box::before {
	content: "";
	background-color: #dcdcdc;
	width: 1px;
	height: 100%;
	position: absolute;
	left: 0;
	top: 0;
}
section.widget-section.widget-feature-06 .feature-box::after {
	content: "";
	background-color: #fff;
	width: 13px;
	height: 13px;
	border: 2px solid #fff;
	border-radius: 50%;
	position: absolute;
	left: -6px;
	top: 41px;
}
.widget-feature-06 .feature-box h6, .widget-feature-06 .feature-box h3, .widget-feature-06 .feature-box p {
	color: #fff;
}
section.widget-section.widget-feature-06 .feature-box h6 {
	font-weight: normal;
}
section.widget-section.widget-feature-06 .feature-box h3 {
	font-size: 24px;
	font-weight: bold;
	position: relative;
	line-height: normal;
}
section.widget-section.widget-feature-06 .feature-box h3:before {
	content: "";
	background-color: #dcdcdc;
	width: 33px;
	height: 1px;
	position: absolute;
	left: -50px;
	top: 42%;
	transform: translateY(-50%);
}
section.widget-section.widget-feature-06 .feature-box p {
	margin-bottom: 0;
	line-height: 30px;
}

@media (min-width: 768px) and (max-width: 1023px) {
section.widget-section.widget-feature-06 .feature-box {
	text-align: left;
}
}

@media (max-width: 640px) {
section.widget-section.sec-padding-xl.widget-feature-06 .page-heading {
	padding: 30px 0;
}
section.widget-section.widget-feature-06 .feature-box {
	text-align: left;
}
}
/*===================== Widget_62 (End) =====================*/

/*===================== Widget_63 (Start) =====================*/
section.widget-service-12 .row.mb-50 {
	margin-bottom: 50px;
}
.widget-service-12 .item {
	padding: 35px 30px 30px 30px;
	position: relative;
	background-color: #fff;
	border: 2px dashed #f1f2f6;
	-webkit-transition: transform 0.3s;
	transition: transform 0.3s;
	margin-left: -2px;
	border-radius: 15px;
}
.widget-service-12 .item:hover .icon {
	-webkit-animation: icon-updown 600ms ease-in-out 0ms;
	animation: icon-updown 600ms ease-in-out 0ms;
	-webkit-animation-iteration-count: infinite;
	animation-iteration-count: infinite;
}
.widget-service-12 .item .icon {
	background-color: transparent;
	color: #fff;
	font-size: 31px;
	margin-top: 30px;
	line-height: 1;
	width: 70px;
	height: 70px;
	background-color: #000;
	border-radius: 46px;
	margin-bottom: 0;
}
.widget-service-12 .item .icon i.fa {
	top: 0;
	transform: translateY(0);
	line-height: 70px;
}
.widget-service-12 .item:hover {
	-webkit-transition: transform 0.3s;
	transition: transform 0.3s;
	-webkit-transform: translateY(-20px);
	transform: translateY(-20px);
}
@keyframes icon-updown {
0%, 100% {
-webkit-transform:translateY(0);
transform:translateY(0)
}
40% {
-webkit-transform:translateY(-8px);
transform:translateY(-8px)
}
}
section.widget-service-12[class*="theme-dark-color"] .item * {
	color: #000;
}
section.widget-service-12[class*="theme-dark-color"] .icon i {
	color: #fff !important;
}

@media (min-width: 768px) and (max-width: 1023px) {
section.widget-section.widget-service-12 .col-lg-3.col-md-3.col-sm-6.p-0 {
	padding-left: 15px;
	padding-right: 15px;
}
}

@media (max-width: 640px) {
section.widget-section.widget-service-12 .page-heading {
	padding: 30px 0;
}
section.widget-section.widget-service-12 .col-lg-3.col-md-3.col-sm-3.p-0 {
	padding-left: 15px;
	padding-right: 15px;
}
}
/*===================== Widget_63 (End) =====================*/

/*===================== Widget_64 (Start) =====================*/
.widget-intro-09 {
	overflow: visible;
}
.widget-intro-09 .time-table {
	border-color: transparent transparent #000 #000;
	border-style: solid;
	border-width: 5px;
	padding: 15px 20px 50px 50px;
	position: relative;
	width: 80%;
	margin-top: 40px;
}
.widget-intro-09 .time-table:before, .widget-intro-09 .time-table:after {
	background: #000;
	content: "";
	height: 5px;
	left: -5px;
	position: absolute;
	top: -5px;
	width: 50%;
}
.widget-intro-09 .time-table:after {
	bottom: -5px;
	height: 50px;
	left: auto;
	right: -5px;
	top: auto;
	width: 5px;
}
.widget-intro-09 .time-table table {
	margin-bottom: 0;
}
.widget-intro-09 .time-table .table>tbody>tr>td {
	font-weight: bold;
	font-size: 13px;
	padding: 10px 0;
}
.widget-intro-09 .appointment-form {
	padding: 50px;
	margin-top: -175px;
	background-color: #fff;
	box-shadow: 0 10px 20px 0 rgba(153,153,153,.1);
	z-index: 999;
}
.widget-intro-09 .appointment-form .form-heading h4 {
	margin-bottom: 30px;
	color: #000;
}
.widget-intro-09 .appointment-form form input[type="text"], .widget-intro-09 .appointment-form form input[type="email"], .widget-intro-09 .appointment-form form textarea {
	width: 100%;
	outline: none;
	padding: 12px;
	height: 100%;
	border: 2px solid #000;
	border-radius: 3px;
	margin-bottom: 10px;
	background-color: #fafafa;
}
.widget-intro-09 .appointment-form form label {
	display: none;
}

@media (min-width: 768px) and (max-width: 1024px) {
.widget-intro-09 .time-table {
	margin: 0;
	padding: 20px;
	width: 100%;
	text-align: left;
}
.widget-intro-09 .appointment-form {
	margin-top: -140px;
}
}

@media (max-width: 640px) {
.widget-intro-09 .time-table {
	margin-top: 0;
	padding: 20px;
	width: 100%;
}
.widget-intro-09 .time-table:before {
	width: 100%;
}
.widget-intro-09 .time-table h2, .widget-intro-09 .time-table p {
	text-align: left;
}
.widget-intro-09 .time-table .table>tbody>tr>td {
	text-align: left;
	padding: 7px;
}
.widget-intro-09 .appointment-form {
	margin-top: 30px;
	padding: 25px;
}
}
/*===================== Widget_64 (End) =====================*/

/*===================== Widget_65 (Start) =====================*/
.widget-tab-01 .page-heading * {
	color: #fff;
}
/*.widget-tab-01 .nav-tabs li {
	width: 20%;
	text-align: center;
}
.widget-tab-01 .nav-tabs li.active a {
	background-color: #fff;
	color: #000;
}
.widget-tab-01 .nav-tabs li a {
	background-color: transparent;
	color: #fff;
	padding: 30px;
}
.widget-tab-01 .nav-tabs li a:hover:before {
	background-color: transparent;
	color: #000;
}
.widget-tab-01 .nav-tabs li a img {
	width: 50px;
	height: 50px;
	margin: 0 auto;
	display: block;
	margin-bottom: 10px;
}
.widget-tab-01 .tab-content {
	background-color: #fff;
	padding: 50px;
}
.widget-tab-01 .tab-content h4, .widget-tab-01 .tab-content p {
	color: #000;
}
.widget-tab-01 .tab-content p {
	color: #000;
	font-size: 14px;
}
.widget-tab-01 .tab-content .simple-image {
	width: 100%;
	height: 300px;
}
.widget-tab-01 .tab-content .simple-image img {
	width: 100%;
	height: 100%;
}

@media (min-width: 768px) and (max-width: 1024px) {
.widget-tab-01 .tab-content .simple-image {
	height: 400px;
	margin-top: 20px;
}
}

@media (max-width: 640px) {
.widget-tab-01 .nav-tabs li {
	width: 100%;
}
.widget-tab-01 .nav-tabs li a {
	padding: 15px;
}
.widget-tab-01 .tab-content {
	padding: 15px;
	text-align: left;
}
}*/
/*===================== Widget_65 (End) =====================*/

/*===================== Widget_66 (Start) =====================*/
.widget-about-08 .item {
	padding: 0;
	background-color: #fff;
	text-align: center;
	margin-right: 20px;
	width: 46%;
	margin-bottom: 20px;
	display: block;
	float: left;
	position: relative;
	box-shadow: 0 2px 48px 0 rgba(0, 0, 0, 0.03);
	border-radius: 10px;
	min-height: 220px;
}
.widget-about-08 .item .item-content {
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	width: 100%;
}
.widget-about-08 .item .item-content .icon {
	background-color: transparent;
	margin-bottom: 0;
	color: #000;
	font-size: 40px;
}
.widget-about-08 .item .item-content .icon i.fa {
	top: 0;
	transform: translateY(0);
	
}
.widget-about-08 .item .item-content h4 {
	color: #000;
	font-size: 16px;
	font-weight: 600;
	font-family: 'Poppins', sans-serif;
	letter-spacing: normal;
}
.widget-about-08 .item .item-content p {
	margin-bottom: 0;
	color: #000;
	font-size: 14px;
}
.widget-about-08 .item:before {
	content: '';
	position: absolute;
	top: -10px;
	left: 0;
	right: 0;
	height: 1px;
	border-top: 3px solid #000;
}
.widget-about-08 .item:after {
	content: '';
	position: absolute;
	right: -10px;
	top: 0;
	bottom: 0;
	width: 1px;
	border-left: 3px solid #000;
}
.widget-about-08 .item:nth-child(1):before {
	border-top: 0;
}
.widget-about-08 .item:nth-child(2):before {
	border-top: 0;
}
.widget-about-08 .item:nth-child(2):after {
	border-left: 0;
}
.widget-about-08 .item:nth-child(4):after {
	border-left: 0;
}
.widget-about-08 .content ul {
	list-style: none;
	margin: 0 0 10px 0;
	padding: 0;
}
.widget-about-08 .content ul li {
	margin-bottom: 0;
	position: relative;
	margin-left: 20px;
}
.widget-about-08 .content ul li:before {
	content: '';
	width: 8px;
	height: 8px;
	background-color: #000;
	position: absolute;
	top: 50%;
	left: -20px;
	transform: translateY(-50%);
}

@media (min-width: 768px) and (max-width: 1024px) {
.widget-about-08 .content ul {
	text-align: center;
	margin-bottom: 30px;
}
.widget-about-08 .content ul li {
	display: inline-block;
	margin: 0 0 0 30px;
}
}

@media (max-width: 640px) {
.widget-about-08 .item {
	width: 80%;
	margin-right: 0;
	text-align: center;
	margin: 0 auto 30px auto;
	display: block;
	float: none;
}
.widget-about-08 .item:before, .widget-about-08 .item:after {
	display: none;
}
.widget-about-08 .content ul {
	text-align: left;
	margin: 0 auto 20px auto;
	display: inline-block;
}
.widget-about-08 .content a.theme-button {
	margin-bottom: 20px;
}
}
/*===================== Widget_66 (End) =====================*/

/*===================== Widget_67 (Start) =====================*/
.widget-gallery-01 .small-image {
	width: 100%;
	height: 230px;
	overflow: hidden;
	position: relative;
}
.widget-gallery-01 .large-image {
	width: 100%;
	height: 460px;
	overflow: hidden;
	position: relative;
}
.widget-gallery-01 .large-image img, .widget-gallery-01 .small-image img {
	width: 100%;
	height: 100%;
	transition: transform 3s;
	-o-object-fit: cover;
	object-fit: cover;
}
.widget-gallery-01 .large-image:hover img, .widget-gallery-01 .small-image:hover img {
	transform: scale(1.1);
}
/*===================== Widget_67 (End) =====================*/

/*===================== Widget_68 (Start) =====================*/
.widget-team-member-08 .team {
	padding: 55px 45px;
	-webkit-transition: all 0.3s ease-out 0s;
	-moz-transition: all 0.3s ease-out 0s;
	-ms-transition: all 0.3s ease-out 0s;
	-o-transition: all 0.3s ease-out 0s;
	transition: all 0.3s ease-out 0s;
	border: 5px solid #f1f2f6;
}
.widget-team-member-08 .team .team-thumb {
	width: 205px;
	height: 205px;
	margin: 0 auto;
}
.widget-team-member-08 .team .team-thumb img {
	width: 100%;
	height: 100%;
	border-radius: 50%;
}
.widget-team-member-08 .team .team-content {
	margin-top: 35px;
	text-align: center;
}
.widget-team-member-08 .team .team-content .team-socail-icons ul {
	list-style: none;
	margin: 0;
	padding: 0;
	border-top: 1px solid #ddd;
	padding-top: 20px;
}
.widget-team-member-08 .team .team-content .team-socail-icons ul li {
	display: inline-block;
}
.widget-team-member-08 .team .team-content .team-socail-icons ul li a {
	width: 36px;
	height: 36px;
	display: block;
	line-height: 36px;
	border-radius: 100%;
	background-color: #000;
	color: #fff;
}
.widget-team-member-08 .team:hover {
	border-color: #fff;
	-webkit-box-shadow: 0px 0px 16px 0px rgba(72, 127, 255, 0.21);
	-moz-box-shadow: 0px 0px 16px 0px rgba(72, 127, 255, 0.21);
	box-shadow: 0px 0px 16px 0px rgba(72, 127, 255, 0.21);
}

@media (min-width: 768px) and (max-width: 1024px) {
.widget-team-member-08 .team {
	padding: 15px;
}
.widget-team-member-08 .team .team-thumb {
	width: 100%;
	height: 180px;
}
.widget-team-member-08 .team .team-content {
	margin-top: 20px;
}
}

@media (max-width: 640px) {
.widget-team-member-08 .team {
	padding: 10px;
	margin-bottom: 30px;
}
.widget-team-member-08 .team .team-content {
	margin-top: 15px;
	margin-bottom: 15px;
}
}
/*===================== Widget_68 (End) =====================*/

/*===================== Widget_69 (Start) =====================*/
.widget-service-13 .item-box {
	text-align: center;
	padding: 35px;
	margin-bottom: 30px;
}
.widget-service-13 .item-box .item .icon {
	background-color: transparent;
	color: #31609f;
	font-size: 36px;
}
.widget-service-13 .item-box .item .icon i.fa {
	top: 0;
	transform: translateY(0);
}
.widget-service-13 .item-box {
	text-align: center;
	padding: 30px 10px;
}
.widget-service-13 .item-box {
	text-align: center;
	padding: 30px 10px;
}
.widget-service-13 .item_box-icon {
	width: 70px;
	height: 70px;
	margin: 0 auto;
	border-radius: 50%;
	text-align: center;
	position: relative;
	margin-bottom: 20px;
	background-color: #000;
}
.widget-service-13 .item_box-icon::before {
	transition: all 0.4s;
	content: "";
	position: absolute;
	top: -10px;
	left: -10px;
	width: 90px;
	height: 90px;
	border: 10px solid #F0F1F5;
	-webkit-border-radius: 50%;
	-moz-border-radius: 50%;
	border-radius: 50%;
}
.widget-service-13 .item-box i.fa {
	/*font-size: 24px;
	color: #efefef;*/
	line-height: 70px;
	text-align: center;
	display: block;
}
.widget-service-13 .item-box h6 {
	font-size: 18px;
	font-weight: bold;
	text-transform: uppercase;
	margin-top: 0;
	margin-bottom: 10px;
	cursor: default;
}
.widget-service-13 .item-box p {
	font-size: 14px;
	color: #000;
	line-height: 1.5;
	margin-top: 0;
	margin-bottom: 10px;
	cursor: default;
}
.widget-service-13 .item-box:before, .widget-service-13 .item-box .item:before, .widget-service-13 .item-box:after, .item-box .item:after {
	position: absolute;
	content: "";
	background-color: #000;
	z-index: 1
}
.widget-service-13 .item-box:before, .widget-service-13 .item-box .item:before {
	right: 12px;
	top: -3px;
	transition-duration: 0.5s;
	-webkit-transition-duration: 0.5s;
	-moz-transition-duration: 0.5s;
	-ms-transition-duration: 0.5s;
	-o-transition-duration: 0.5s;
}
.widget-service-13 .item-box:after, .widget-service-13 .item-box .item:after {
	left: 12px;
	bottom: 27px;
	transition-duration: 0.5s;
	-webkit-transition-duration: 0.5s;
	-moz-transition-duration: 0.5s;
	-ms-transition-duration: 0.5s;
	-o-transition-duration: 0.5s;
}
.widget-service-13 .item-box:hover:before, .widget-service-13 .item-box:hover:after {
	transform: scaleY(0.91);
	transition-duration: 0.5s;
	-webkit-transition-duration: 0.5s;
	-moz-transition-duration: 0.5s;
	-ms-transition-duration: 0.5s;
	-o-transition-duration: 0.5s;
}
.widget-service-13 .item-box:before {
	transform-origin: right top 0;
	-webkit-transform-origin: right top 0;
	-moz-transform-origin: right top 0;
	-ms-transform-origin: right top 0;
	-o-transform-origin: right top 0;
}
.widget-service-13 .item-box:after {
	transform-origin: left bottom 0;
	-webkit-transform-origin: left bottom 0;
	-moz-transform-origin: left bottom 0;
	-ms-transform-origin: left bottom 0;
	-o-transform-origin: left bottom 0;
}
.widget-service-13 .item-box .item:before {
	transform-origin: right top 0;
	-webkit-transform-origin: right top 0;
	-moz-transform-origin: right top 0;
	-ms-transform-origin: right top 0;
	-o-transform-origin: right top 0;
}
.widget-service-13 .item-box .item:after {
	transform-origin: top left 0;
	-webkit-transform-origin: top left 0;
	-moz-transform-origin: top left 0;
	-ms-transform-origin: top left 0;
	-o-transform-origin: top left 0;
}
.widget-service-13 .item-box:before, .widget-service-13 .item-box:after {
	height: 100%;
	width: 3px;
	transform: scaleY(0);
	-webkit-transform: scaleY(0);
	-moz-transform: scaleY(0);
	-ms-transform: scaleY(0);
	-o-transform: scaleY(0);
	transition-duration: 0.5s;
	-webkit-transition-duration: 0.5s;
	-moz-transition-duration: 0.5s;
	-ms-transition-duration: 0.5s;
	-o-transition-duration: 0.5s;
}
.widget-service-13 .item-box:hover .item:before, .widget-service-13 .item-box:hover .item:after {
	transform: scaleX(0.93);
	-webkit-transform: scaleX(0.93);
	-moz-transform: scaleX(0.93);
	-ms-transform: scaleX(0.93);
	-o-transform: scaleX(0.93);
	transition-duration: 0.5s;
	-webkit-transition-duration: 0.5s;
	-moz-transition-duration: 0.5s;
	-ms-transition-duration: 0.5s;
	-o-transition-duration: 0.5s;
}
.widget-service-13 .item-box .item:before, .widget-service-13 .item-box .item:after {
	width: 100%;
	height: 3px;
	transform: scaleX(0);
	-webkit-transform: scaleX(0);
	-moz-transform: scaleX(0);
	-ms-transform: scaleX(0);
	-o-transform: scaleX(0);
	transition-duration: 0.5s;
	-webkit-transition-duration: 0.5s;
	-moz-transition-duration: 0.5s;
	-ms-transition-duration: 0.5s;
	-o-transition-duration: 0.5s;
}
/*===================== Widget_69 (End) =====================*/

/*===================== Widget_70 (Start) =====================*/
.widget-gallery-02 .item {
	width: 100%;
	position: relative;
}
.widget-gallery-02 .small-image, .widget-gallery-02 .large-image {
	position: relative;
	padding: 5px;
}
.widget-gallery-02 .small-image {
	height: 200px;
	width: 100%;
	-webkit-transition: all 0.3s ease-in-out;
	-o-transition: all 0.3s ease-in-out;
	transition: all 0.3s ease-in-out;
}
.widget-gallery-02 .small-image:before {
	width: 97%;
	height: 94%;
}
.widget-gallery-02 .small-image:before, .widget-gallery-02 .large-image:before {
	position: absolute;
	content: '';
	height: 100%;
	width: 100%;
	background: #80091d;
	opacity: 0;
	-webkit-transition: all 0.3s ease-in-out;
	-o-transition: all 0.3s ease-in-out;
	transition: all 0.3s ease-in-out;
}
.widget-gallery-02 .small-image img {
	width: 100%;
	height: 100%;
}
.widget-gallery-02 .item .content {
	position: absolute;
	bottom: 20px;
	left: 20px;
	width: 90%;
	text-align: right;
	transition: all 0.4s ease-out 0s;
	height: auto;
}
.widget-gallery-02 .item .content h4 {
	width: 100%;
	transition: all 0.4s ease-out 0s;
	position: absolute;
	bottom: 20px;
}
.widget-gallery-02 .item .content h4, .widget-gallery-02 .item .content p {
	margin-bottom: 0;
	color: #fff;
}
.widget-gallery-02 .item .content p {
	width: 100%;
	transition: all 0.4s ease-out 0s;
	position: absolute;
	bottom: 0;
}
.widget-gallery-02 .large-image {
	width: 100%;
	height: 360px;
	-webkit-transition: all 0.3s ease-in-out;
	-o-transition: all 0.3s ease-in-out;
	transition: all 0.3s ease-in-out;
}
.widget-gallery-02 .large-image:before {
	width: 97%;
	height: 97%;
}
.widget-gallery-02 .small-image:before {
	width: 97%;
	height: 94%;
}
.widget-gallery-02 .large-image img {
	width: 100%;
	height: 100%;
}
.widget-gallery-02 .item:hover .content h4 {
	bottom: 50px;
}
.widget-gallery-02 .item:hover .content p {
	bottom: 20px;
}
.widget-gallery-02 .small-image:before, .widget-gallery-02 .large-image:before {
	position: absolute;
	content: '';
	background: #80091d;
	opacity: 0;
	-webkit-transition: all 0.3s ease-in-out;
	-o-transition: all 0.3s ease-in-out;
	transition: all 0.3s ease-in-out;
}
.widget-gallery-02 .small-image:hover:before, .widget-gallery-02 .large-image:hover:before {
	opacity: 0.55;
}
/*===================== Widget_70 (End) =====================*/

/*===================== Widget_71 (Start) =====================*/
.widget-news-01 .item {
}
.widget-news-01 .item .thumb {
	width: 100%;
	height: 200px;
}
.widget-news-01 .item .thumb img {
	width: 100%;
	height: 100%;
}
.widget-news-01 .item .content {
	background-color: #fff;
	padding: 25px 30px 23px 30px;
	-webkit-box-shadow: 0px 50px 100px 0px rgba(37, 46, 89, 0.08);
	box-shadow: 0px 50px 100px 0px rgba(37, 46, 89, 0.08);
}
.widget-news-01[class*="theme-dark-color"] .content *{
	color:#000;
}
.widget-news-01[class*="theme-dark-color"] .content .theme-button {
	color:#fff;
}
.widget-news-01[class*="theme-dark-color"] .content .theme-button:hover {
	color:#000;
}
/*===================== Widget_71 (End) =====================*/

/*===================== Widget_72 (Start) =====================*/
.widget-feature-07 .item {
	display: block;
	width: 100%;
	position: relative;
	margin-bottom: 30px;
}
.widget-feature-07 .item:first-child {
	margin-top: 30px;
}
.widget-feature-07 .item .icon {
	position: relative;
	font-size: 30px;
	width: 70px;
	height: 70px;
	color: #ffffff;
	background-color: #80091d;
	float: left;
	margin-bottom: 0;
	top: 6px;
	border-radius: 100% 50% 50% 100% / 75% 69% 69% 75%;
	border: 2px solid #ffffff;
	border-bottom: 0;
	border-right: 0;
}
.widget-feature-07 .item .item-content {
	text-align: left;
	overflow: hidden;
	padding-left: 20px;
}
.widget-feature-07 .item .item-content * {
	color: #fff;
}
.widget-feature-07 .item .item-content p, .widget-feature-07 .item .item-content h5 {
	margin-bottom: 0;
}
.widget-feature-07 .item .icon i.fa {
}
.widget-feature-07 .image {
	width: 570px;
	height: 420px;
	position: absolute;
	top: 50%;
	right: 0;
	transform: translateY(-50%);
}
.widget-feature-07 .image img {
	width: 100%;
	height: 100%;
}
.widget-feature-07 {
	position: relative;
}
.widget-feature-07 .item {
}
.widget-feature-07 .item-wrapper {
	padding: 0;
	float: left;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-feature-07 .item-wrapper {
	float: left;
	padding: 0px;
}
.widget-feature-07 .item {
	padding: 0;
	display: block;
	width: 33%;
	float: left;
	padding-left: 15px;
	padding-right: 15px;
	margin-bottom: 0;
}
.widget-feature-07 .item:first-child {
	margin-top: 0;
}
.widget-feature-07 .item .icon {
	display: block;
	text-align: center;
	margin: 0 auto;
	float: none;
}
.widget-feature-07 .item .icon:before {
	width: 80%;
	height: 1px;
	left: 50%;
	transform: translateX(-50%);
	bottom: 5px;
	top: auto;
}
.widget-feature-07 .item .item-content {
	text-align: center;
	padding: 10px;
}
.widget-feature-07 .image {
	width: 90%;
	height: 300px;
	position: static;
	top: 0;
	bottom: 0;
	overflow: hidden;
	transform: translateY(0);
	margin: 0 auto;
	margin-bottom: 30px;
}
}

@media (max-width: 640px) {
.widget-feature-07 .item {
	padding: 0;
}
.widget-feature-07 .item .icon {
	margin: 0 auto;
	display: block;
	float: none;
	margin-bottom: 20px;
}
.widget-feature-07 .item .item-content {
	overflow: visible;
	padding: 0;
	text-align: center;
}
.widget-feature-07 .image {
	height: 200px;
	transform: translateY(0);
	position: static;
	overflow: hidden;
}
}
/*===================== Widget_72 (End) =====================*/

/*===================== Widget_73 (Start) =====================*/

.widget-form-06 .form-box {
	padding: 50px;
	background-color: #5352ed;
	margin: 80px 0;
}
.widget-form-06 form h2 {
	margin-bottom: 50px;
	color: #fff;
}
.widget-form-06 form input, .widget-form-06 form textarea {
	border: 1px solid #000;
	font-size: 14px;
	padding: 15px;
	margin-bottom: 15px;
	width: 100%;
	background-color: transparent;
	border-right: 0;
	border-left: 0;
	border-top: 0;
}
.widget-form-06 form textarea {
	min-height: 187px;
}
.widget-form-06 .item {
}
.widget-form-06 .item .icon {
	background-color: transparent;
	color: #5352ed;
	font-size: 36px;
	margin-bottom: 10px;
}
.widget-form-06 .item .icon i.fa {
	top: 0;
	transform: translateY(0);
}
.widget-form-06 .item-content {
}
.widget-form-06 .item-content h4 {
	font-size: 20px;
	margin-bottom: 0;
}
.widget-form-06 .item-content p {
	margin-bottom: 0;
}
.widget-contact-info .item {
	position: relative;
	text-align: center;
	margin: 0px 0px 0px;
	padding: 85px 20px 80px;
	background-color: #FFF;
	box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.1);
	font-size: 14px;
	font-weight: 500;
	line-height: 24px;
}
.widget-contact-info .item .icon {
	background-color: transparent !important;
	color: #000;
	font-size: 40px;
	margin-bottom: 0;
	padding: 20px 0;
}
.widget-contact-info .item h4 {
	margin-bottom: 0;
}
.widget-contact-info .item .icon i.fa {
	top: 0;
	transform: translateY(0);
}
.widget-contact-info .item .item-content p {
	margin-bottom: 0;
}

@media (max-width: 768px) {
.widget-contact-info .item {
	margin-bottom: 30px;
}
}
/*===================== Widget_73 (End) =====================*/

/*===================== Widget_74 (Start) =====================*/
.widget-feature-08 .item {
	text-align: center;
}
.widget-feature-08 .item .icon {
	width: 100px;
	height: 100px;
	font-size: 40px;
	text-align: center;
	background: #6ab04c;
	background: #000;
	border-radius: 100% 50% 50% 100% / 75% 69% 69% 75%;
	-webkit-box-shadow: 2px 2px 20px rgba(0, 0, 0, 0.1);
	box-shadow: 2px 2px 20px rgba(0, 0, 0, 0.1);
	-webkit-transition: .3s ease-in;
	-o-transition: .3s ease-in;
	transition: .3s ease-in;
	color: #ffffff;
	position: relative;
}
.widget-feature-08 .item .item-content {
}
.widget-feature-08 .item .icon:after {
	top: -10px;
	left: -10px;
	content: '';
	width: 110px;
	height: 110px;
	margin: 5px;
	border-radius: 100% 50% 50% 100% / 75% 69% 69% 75%;
	position: absolute;
	border: 2px dashed #868686;
}

@media (min-width: 768px) and (max-width: 1023px) {
}

@media (max-width: 640px) {
}
/*===================== Widget_74 (End) =====================*/

/*===================== Widget_75 (Start) =====================*/
section.widget-about-09 {
	padding: 150px 0;
}
.widget-about-09 .image-box {
	position: relative;
}
.widget-about-09 .image-box .about-image-1 {
	width: 358px;
	height: 324px;
	position: absolute;
	z-index: 3;
	top: 200px;
	left: 80px;
	-webkit-transition: all 0.5s ease-in;
	-moz-transition: all 0.5s ease-in;
	-o-transition: all 0.5s ease-in;
	transition: all 0.5s ease-in;
}
.widget-about-09 .image-box .about-image-1:hover {
	z-index: 3;
	-ms-transform: translate(10%, -10%);
	/* IE 9 */
	-webkit-transform: translate(10%, -10%);
	/* Chrome, Safari, Opera */
	transform: translate(10%, -10%);
}
.widget-about-09 .image-box .about-image-2 {
	width: 374px;
	height: 334px;
	position: absolute;
	z-index: 2;
	top: 60px;
	left: 160px;
	-webkit-transition: all 0.5s ease-in;
	-moz-transition: all 0.5s ease-in;
	-o-transition: all 0.5s ease-in;
	transition: all 0.5s ease-in;
}
.widget-about-09 .image-box .about-image-2:hover {
	z-index: 4;
	-ms-transform: translate(-10%, 10%);
	/* IE 9 */
	-webkit-transform: translate(-10%, 10%);
	/* Chrome, Safari, Opera */
	transform: translate(-10%, 10%);
}
.widget-about-09 .image-box .about-image-3 {
	width: 374px;
	height: 334px;
	position: absolute;
	z-index: 1;
	-webkit-transition: all 0.3s ease-in;
	-moz-transition: all 0.3s ease-in;
	-o-transition: all 0.3s ease-in;
	transition: all 0.3s ease-in;
}
.widget-about-09 .image-box .about-image-3:hover {
	z-index: 5;
	-ms-transform: translate(-10%, -10%);
	/* IE 9 */
	-webkit-transform: translate(-10%, -10%);
	/* Chrome, Safari, Opera */
	transform: translate(-10%, -10%);
}
.widget-about-09 .image-box .about-image-1 img, .widget-about-09 .image-box .about-image-2 img, .widget-about-09 .image-box .about-image-3 img {
	width: 100%;
	height: 100%;
	border-radius: 7px;
	box-shadow: 0 5px 10px 2px rgba(0,0,0,0.3);
}
.widget-about-09 .content-box {
	padding: 30px;
}
.widget-about-09 .content-box ul {
	list-style: none;
	padding: 0;
	margin-bottom: 10px;
}
.widget-about-09 .content-box ul li {
	position: relative;
	padding-left: 20px;
	font-weight: normal;
}
.widget-about-09 .content-box ul li:before {
	top: 0;
	left: 0;
	font-size: 14px;
	content: '\f069';
	position: absolute;
	font-weight: 900;
	font-family: FontAwesome;
	color: #000;
}

@media (min-width: 768px) and (max-width: 1023px) {
section.widget-about-09 {
	padding: 100px 0;
}
.widget-about-09 .image-box {
	position: relative;
	float: left;
	margin-bottom: 30px;
}
.widget-about-09 .image-box .about-image-1, .widget-about-09 .image-box .about-image-2, .widget-about-09 .image-box .about-image-3 {
	position: static;
	width: 33%;
	float: left;
	height: 240px;
}
.widget-about-09 .content-box {
	padding: 0;
}
.widget-about-09 .content-box ul li {
	display: inline-block;
    padding: 0;
    margin-right: 15px;
    padding-left: 20px;
}
}

@media (max-width: 640px) {
.widget-about-09 .image-box .about-image-1, .widget-about-09 .image-box .about-image-2, .widget-about-09 .image-box .about-image-3 {
	position: static;
	margin-bottom: 30px;
	width: 100%;
	top:0;
	left:0;
}
.widget-about-09 .image-box .about-image-1:hover, .widget-about-09 .image-box .about-image-2:hover, .widget-about-09 .image-box .about-image-3:hover {
	z-index: auto;
	-ms-transform: translate(0, 0%);
	-webkit-transform: translate(0, 0%);
	transform: translate(0, 0%);
}
.widget-about-09 .content-box ul li {
    text-align: left;
}
}
/*===================== Widget_75 (End) =====================*/

/*===================== Widget_76 (Start) =====================*/
.widget-video-01 .video-cover {
	padding: 15px;
	width: 100%;
	height: 500px;
	border-radius: 5px;
	box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.05);
}
.widget-video-01 .video-cover img {
	width: 100%;
	height: 100%;
	border-radius: 5px;
}
.widget-video-01 .video-content {
	margin-top: 50px;
}
.widget-video-01 .video-content .page-heading {
	margin-bottom: 0;
}
.widget-video-01 .video-content h6 {
	margin-bottom: 0;
	letter-spacing: normal;
	font-weight: bold;
	font-family: 'Raleway', sans-serif;
}
.widget-video-01 .video-content p {
	-webkit-column-count: 3;
	-moz-column-count: 3;
	column-count: 3;
	-webkit-column-rule: 5px double #f5f5f5;
	-moz-column-rule: 5px double #f5f5f5;
	column-rule: 5px double#f5f5f5;
	text-align: left;
	-webkit-column-gap: 40px; /* Chrome, Safari, Opera */
	-moz-column-gap: 40px; /* Firefox */
	column-gap: 40px;
}

@media (min-width: 768px) and (max-width: 1023px) {
}

@media (max-width: 640px) {
.widget-video-01 .video-cover {
	height: 220px;
}
.widget-video-01 .video-content p {
	-webkit-column-count: 1;
	-moz-column-count: 1;
	column-count: 1;
	text-align: center;
}
}
/*===================== Widget_76 (End) =====================*/

/*===================== Widget_77 (Start) =====================*/
.widget-funfact-04 .page-heading {
	margin-bottom: 0;
}
.widget-funfact-04 .item {
	padding: 20px;
	box-shadow: 11px 8px 5px -4px #f1f1f1;
	background: #fff;
	position: relative;
	overflow: hidden;
	border: solid 1px #ececec;
}
.widget-funfact-04 .row:last-child {
	margin-top: 50px;
}
.widget-funfact-04 .item .icon {
	font-size: 30px;
	margin-bottom: 10px;
}
.widget-funfact-04 .item .item-content {
}
.widget-funfact-04 .item .item-content h4 {
	margin-bottom: 0;
	font-size: 20px;
}
.widget-funfact-04 .item .item-content p {
	margin-bottom: 0;
}
.widget-funfact-04[class*="theme-dark-color"] .page-heading * {
	color:#fff;
}
@media (min-width: 768px) and (max-width: 1023px) {
}

@media (max-width: 640px) {
.widget-funfact-04 .item {
	width: 60%;
	margin: 0 auto 30px auto;
}
}
/*===================== Widget_77 (End) =====================*/

/*===================== Widget_78 (Start) =====================*/
.widget-event-01 .event-block {
	width: 100%;
	float: left;
	background-color: #fff;
	box-shadow: 1px 0px 40px 0px rgba(0,0,0,.06);
	margin-bottom: 30px;
}
.widget-event-01 .event-block .event-image {
	width: 100%;
	/* height: 290px;*/
	height: 220px;
}
.widget-event-01 .event-block .event-image img {
	width: 100%;
	height: 100%;
}
.widget-event-01 .event-block .event-content {
	text-align: left;
	padding: 20px;
	position: relative;
}
.widget-event-01 .event-block .event-info {
	width: 100%;
	float: left;
}
.widget-event-01 .event-block .event-info p {
	float: left;
	font-size: 14px;
	margin-bottom: 0;
	font-weight: bold;
}
.widget-event-01 .event-block .event-info p span.fa {
	color: #000;
	margin-right: 5px;
	font-weight: normal;
}
.widget-event-01 .event-block .event-info p strong {
	margin-right: 5px;
}
.widget-event-01 .event-block .event-info a {
	float: right;
	font-weight: bold;
	background-color: #000;
	color: #ffffff;
	padding: 5px 10px;
	font-size: 14px;
	border-radius: 3px;
}
.widget-event-01 .event-block:last-child {
	margin-bottom: 0;
}
.widget-event-01[class*="theme-dark-color"] .event-content * {
	color:#000;
}
.widget-event-01[class*="theme-light-color"] .event-content * {
	color:#000;
}
@media (min-width: 768px) and (max-width: 1023px) {
}

@media (max-width: 640px) {
.widget-event-01 .event-block .col-sm-5.p-0 {
	padding-right: 15px;
	padding-left: 15px;
}
}
/*===================== Widget_78 (End) =====================*/

/*===================== Widget_79 (Start) =====================*/
.widget-form-10 .page-heading {
	margin-bottom: 60px;
}
.widget-form-10 .page-heading * {
	color: #fff;
}
.widget-form-10 .page-heading h2:before, .widget-form-10 .page-heading h2:after {
	border-color: #fff;
}
.widget-form-10 form .input {
	width: 48%;
	float: left;
	margin-right: 11px;
}
.widget-form-10 form .input input[type="text"], .widget-form-10 form .input input[type="email"] {
	color: #666;
	width: 100%;
	font-size: 14px;
	font-family: FontAwesome, 'Raleway', "Helvetica Neue", Helvetica, Arial, sans-serif;
	padding: 10px 15px;
	margin-bottom: 20px;
	border: 0;
	background-color: #ffffff;
	border-radius: 3px;
}
.widget-form-10 form textarea {
	width: 98%;
	float: left;
	margin-bottom:30px;
}
.widget-form-10 form .textarea textarea {
	width: 100%;
	min-height: 150px;
	border: 0;
	background-color: #ffffff;
	padding: 10px;
	border-radius: 3px;
	margin: 0 auto;
}
.widget-form-10 form .submit-btn {
	float: left;
	width: 100%;
	display: inline-block;
	margin-top: 20px;
}
.widget-form-10 form .submit-btn button {
	background-color: #fff;
	color: #000;
}

@media (min-width: 768px) and (max-width: 1023px) {
}

@media (max-width: 640px) {
}
/*===================== Widget_79 (End) =====================*/

/*===================== Widget_80 (Start) =====================*/
.widget-gallery-03 .thumb-box {
	width: 100%;
	height: 100%;
	float: left;
	border: 1px solid #fff;
}
.widget-gallery-03 .thumb-box .thumb {
	height: 400px;
	width: 100%;
	position: relative;
	border-radius: 10px;
}
.widget-gallery-03 .thumb-box .thumb img {
	width: 100%;
	height: 100%;
}

@media (min-width: 768px) and (max-width: 1023px) {
.widget-gallery-03 .thumb-box .thumb {
	height: 320px;
}
.widget-gallery-03 .row:last-child .thumb-box .thumb {
	height: 270px;
}
}

@media (max-width: 640px) {
.widget-gallery-03 .p-0 {
	padding-left: 15px;
	padding-right: 15px;
}
.widget-gallery-03 .thumb-box .thumb {
	margin-bottom: 15px;
}
.widget-gallery-03 .thumb-box .thumb {
	height: 270px;
}
}
/*===================== Widget_80 (End) =====================*/

/*===================== Widget_81 (Start) =====================*/
.widget-form-08 form input, .widget-form-08 form textarea {
	background-color: transparent;
	width: 100%;
	margin-bottom: 30px;
	padding: 10px;
	outline: none;
	border: 1px solid #fff;
	border-radius: 3px;
}
.widget-form-08 .theme-button-second {
	background-color: transparent;
	border: 1px solid #fff;
	color: #fff;
}
.widget-form-08 form textarea {
	min-height: 180px;
}
.widget-form-08 .page-heading * {
	color: #fff;
}
.widget-form-08 form label {
	display: none;
}
/*===================== Widget_81 (End) =====================*/

/*===================== Widget_82 (Start) =====================*/
.widget-social-icon-01 .socail-icon-wrapper {
	text-align: center;
}
.widget-social-icon-01 .socail-icons .item {
	margin: 0 15px;
	display: inline-block;
}
.widget-social-icon-01 .socail-icons .item .icon {
	width: 76px;
	height: 76px;
	margin-bottom: 0;
	border-radius: 100% 50% 50% 100% / 75% 69% 69% 75%;
	transform: rotate(36deg);
	font-size: 30px;
}
.widget-social-icon-01 .socail-icons .item .icon i {
	transform: translateY(-50%) rotate(-36deg);
}
.widget-social-icon-01 .socail-icons .item fb {
	background-color: #000;
}
.widget-social-icon-01 .socail-icons .item.fb .icon {
	background-color: #3b5998;
}
.widget-social-icon-01 .socail-icons .item.tw .icon {
	background-color: #38A1F3;
}
.widget-social-icon-01 .socail-icons .item.ln .icon {
	background-color: #0e76a8;
}
.widget-social-icon-01 .socail-icons .item.yt .icon {
	background-color: #c4302b;
}
.widget-social-icon-01 .page-heading {
	margin-bottom: 50px;
}

@media (min-width: 768px) and (max-width: 1023px) {
}

@media (max-width: 640px) {
}
/*===================== Widget_82 (End) =====================*/

/*===================== Widget_83 (Start) =====================*/
.widget-intro-02-2 {
}
.widget-intro-02-2 .widget-intro-thumb {
	width: 100%;
	height: 350px;
}
.widget-intro-02-2 .widget-intro-thumb img {
	width: 100%;
	height: 100%;
}
.widget-intro-02-2 .widget-intro-content {
	text-align: left;
	padding: 30px;
}
.widget-intro-02-2 .widget-intro-content h2 {
	font-size: 32px;
	margin-bottom: 10px;
	font-weight: bold;
	line-height: 1.5;
	padding: 0;
}

/*===================== Widget_83 (End) =====================*/

/*===================== Widget_84 (Start) =====================*/
.widget-about-02-2 {
}
.widget-about-02-2 .widget-about-content {
	padding: 42px 60px;
}
.widget-about-02-2 .widget-about-image {
	height: 390px;
}
.widget-about-02-2 .widget-about-image img {
	height: 100%;
}
.widget-about-02-2[class*="theme-light-color"] .widget-about-content * {
	color: #000;
}

@media (max-width: 1023px) {
.widget-about-02-2 .widget-about-content {
	padding: 0 0 30px 0;
}
}
/*===================== Widget_84 (End) =====================*/

/*===================== Widget_85 (Start) =====================*/
.widget-testimonial-01 .item {
    background: #f5f5f5;
    padding: 40px 20px;
    position: relative;
}
.widget-testimonial-01 .item p {
    font-size: 14px;
    margin-bottom: 0;
    text-align: left;
}
.widget-testimonial-01 .item p span.fa {
    margin-right: 10px;
    position: relative;
    top: -10px;
    font-size: 16px;
    color: #fa0f0c;
}
.widget-testimonial-01 .item-author {
    padding: 25px;
    display: table;
    width: 100%;
}
.widget-testimonial-01 .item-author .item-author-image {
    width: 80px;
    height: 80px;
    display: table-cell;
    vertical-align: middle;
}
.widget-testimonial-01 .item-author .item-author-image img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
}
.widget-testimonial-01 .item-author .item-author-content {
    text-align: left;
    display: table-cell;
    vertical-align: middle;
    padding-left: 15px;
}
.widget-testimonial-01 .item-author .item-author-content h6 {
    font-weight: bold;
    color: #000;
    margin-bottom: 0;
}
.widget-testimonial-01 .item-author .item-author-content p {
    font-size: 14px;
    margin-bottom: 0;
    color: #fa0f0c;
    font-weight: normal;
}
/*===================== Widget_85 (End) =====================*/
.dynamic-form-widget .form-box {
	width: 100%;
    float: left;
    padding: 10px;
    background-color: #fbfbfb;
    border-radius: 5px;
    text-align: center;
}
.dynamic-form-widget .form-box .form-group {
	/*width:100%;
	float:left;*/
	margin-bottom:15px;
	text-align: left;
}
.dynamic-form-widget .form-box .form-group label{
	padding: 0;
    margin: 0 0 7px 0;
    font-size: 14px;
    font-weight: 600;
    text-transform: capitalize;
}
.dynamic-form-widget .form-box .form-group input[type="text"],
.dynamic-form-widget .form-box .form-group input[type="email"],
.dynamic-form-widget .form-box .form-group input[type="date"],
.dynamic-form-widget .form-box .form-group input[type="password"],
.dynamic-form-widget .form-box .form-group textarea,
.dynamic-form-widget .form-box .form-group select{
	width: 100%;
    border: 1px solid #eee;
    background-color: #fff;
    padding: 8px;
    margin: 0;
    line-height: normal;
    font-size: 14px;
    min-height: 40px;
}
.dynamic-form-widget .form-box .form-group input[type="text"]:focus, .dynamic-form-widget .form-box .form-group input[type="email"]:focus, .dynamic-form-widget .form-box .form-group input[type="date"]:focus, .dynamic-form-widget .form-box .form-group input[type="password"]:focus, .dynamic-form-widget .form-box .form-group textarea:focus, .dynamic-form-widget .form-box .form-group select:focus {
    outline: none;
}
.dynamic-form-widget .form-box .form-group textarea {
	min-height:150px;
}
.dynamic-form-widget .form-box .form-group .checkbox,
.dynamic-form-widget .form-box .form-group .radio {
    width: 100%;
    float: left;
    text-align: left;
    margin-left: 20px;
}
.dynamic-form-widget .form-box .form-group .checkbox label, .dynamic-form-widget .form-box .form-group .radio label {
    font-size: 14px;
    margin: 0;
}
.dynamic-form-widget .form-box .form-group .checkbox input[type="checkbox"], .dynamic-form-widget .form-box .form-group .radio input[type="radio"] {
    margin: 7px 0 0 -20px;
}/*-------------------------------- widget-section-18-1 ------------------------------------*/
.widget-section.widget-section-18-1 h2 { font-size: 35px; font-family: roboto; }
.widget-section.widget-section-18-1 p { font-family: open sans; font-weight: 300; font-size: 20px;}
.widget-section-18-1 .partner-bg {    background-color: #fff;    padding: 25px;    min-height: 115px;    text-align: center;    margin-bottom: 10px;    border: 1px solid #ccc;}
.widget-section-18-1 .partner-bg img {    max-width: 100%;    max-height: 65px; }
.widget-section.widget-section-18-1 .section-title { margin-bottom: 40px; }

/*-------------------------------- widget-section-19-1 ------------------------------------*/
.widget-section.widget-section-19-1 h2 { font-size: 42px; font-family: roboto;  margin-bottom: 22px; }
.widget-section.widget-section-19-1 p { font-family: open sans; font-weight: 300; font-size: 22px;}
.widget-section.widget-section-19-1 .section-title { margin-bottom: 50px; }
.widget-section.widget-section-19-1  .theme-button-request {background-color: #f46e2f; font-size: 20px; padding: 12px 36px 12px;
    color: #ffffff; border-radius: 4px; font-family: open sans; font-weight: 300;}
.theme-button-request:hover { text-decoration:none; color:#fff;}

/*-------------------------------- widget-section-20-1 ------------------------------------*/
.widget-section-20-1 h2{font-family:roboto; font-size:32px; margin-top:8px;}
.widget-section-20-1 p{font-family:open sans; font-size:14px; line-height: 1.7;}
.widget-section-20-1 img { border-radius:5px; box-shadow: 0 3px 9px 0 rgba(0, 0, 0, .1); border: 1px solid #fff; max-width: 100%; margin: 10px auto; display: block; }
.widget-section-20-1 .our-team-section { border:1px solid #000; padding: 12px 15px; border-radius:5px; min-height:120px;}

/*-------------------------------- widget-section-21-1 ------------------------------------*/
.widget-section-21-1 h2{font-family:roboto; font-size:39px;  margin-top: 27px;   line-height: 1.3;}
.widget-section-21-1 p{font-family:open sans; font-size:15px; line-height: 1.8;}
.img-effect img {     border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
    border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
    -webkit-border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
    -o-border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
    -moz-border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
    -ms-border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
    box-shadow: 0 15px 38px 0 rgba(0, 0, 0, 0.2);
    -webkit-box-shadow: 0 15px 38px 0 rgba(0, 0, 0, 0.2);
    -ms-box-shadow: 0 15px 38px 0 rgba(0, 0, 0, 0.2);
    -o-box-shadow: 0 15px 38px 0 rgba(0, 0, 0, 0.2);
    -moz-box-shadow: 0 15px 38px 0 rgba(0, 0, 0, 0.2);
    max-width: 270px;
    height: auto;}


/*-------------------------------- widget-section-22-1 ------------------------------------*/
.widget-section-22-1 {padding:0px; width:100%; display:table;}
.widget-section-22-1 h2{font-family: open sans; font-size:62px; font-weight:bold; color:#fff;}
.widget-section-22-1 p{ font-family:open sans; font-size: 25px; text-transform: capitalize;color:#fff; font-weight:300;}
.widget-section-22-1 .wedgit-item {min-height:200px; text-align:center; padding-top:40px;}

/*-------------------------------- widget-section-23-1 ------------------------------------*/
.widget-section-23-1 { background-size:cover;}
.widget-section-23-1 h2{ font-family: open sans; font-size:45px;  margin-bottom:18px;}
.widget-section-23-1 p{font-family: open sans; font-size: 17px; color: #fff; font-weight: 300; line-height: 1.6; max-width: 1000px; margin: 0px auto;}
.widget-section.widget-section-23-1  .theme-button-request { background-color: #000; font-size: 20px; padding: 12px 36px 14px; color: #ffffff; border-radius: 4px; font-family: open sans; font-weight: 300; margin-top: 22px; display: inline-block;}
.widget-section.widget-section-23-1 .theme-button-request:hover { text-decoration:none; color:#fff;}

/*-------------------------------- widget-section-24-1 ------------------------------------*/
.widget-section-24-1 h2{font-family: open sans; font-size: 60px; font-weight: 700;color: #fff; margin-top: 80px; line-height: 1.2;}
.widget-section-24-1 p{font-family: open sans; font-size: 15px; text-transform: capitalize; color: #fff; font-weight: 300; line-height: 1.6;margin-top: 22px;}
.widget-section-24-1 img {max-width:100%; max-height:350px;}

/*-------------------------------- widget-section-25-1 ------------------------------------*/
.widget-section-25-1 {padding:0px; width:100%; display:table;}
.widget-section-25-1 h2{font-family: open sans;font-size: 30px;font-weight: bold;color: #fff;margin-bottom: 20px;}
.widget-section-25-1 p{font-family: open sans;font-size: 14px;text-transform: capitalize;color: #fff;font-weight: 300;text-align: justify;line-height: 1.6;}
.widget-section-25-1 .wedgit-item { padding: 40px 30px 25px;}

/*-------------------------------- widget-section-26-1 ------------------------------------*/

.widget-section-26-1 {padding:0px; width:100%; display:table;}
.widget-section-26-1 h2{font-family: open sans;font-size: 35px;font-weight: bold;color: #fff;margin-bottom: 20px;}
.widget-section-26-1 p{font-family: open sans;font-size: 14px;text-transform: capitalize;color: #fff;font-weight: 300;text-align: justify;line-height: 1.6; margin-bottom: 20px;}
.widget-section-26-1 img {max-width:100%;}
.p-0 {padding:0px;}
.widget-section.widget-section-26-1  .theme-button-request { background-color: #fff; font-size: 18px; padding: 12px 36px 14px; color: #000; border-radius: 4px; font-family: open sans; font-weight: 300; margin-top: 22px; display: inline-block;}
.widget-section-26-1 .slider-item {padding:50px 25px 0px;}

/*--------------------------------------------------------------------*/
/*** -------------------------- New Pages css -------------------------- ***/
.centered-row {
	text-align: center;
}
.centered-col {
	display: inline-block;
	float: none;
}
.sec-padding-xl {padding: 100px 0;}
section.section-inner-bg h1, section.section-inner-bg h2, section.section-inner-bg h3, section.section-inner-bg h4, section.section-inner-bg h5, section.section-inner-bg h6, section.section-inner-bg p {
 margin-bottom:10px;color: #fff;}
.section-inner-bg:before{content:'';width:100%;height: 100%;top:0;left:0;background:rgba(0,0,0,0.3);position: absolute;}
section.sec-text h1, section.sec-text h2, section.sec-text h3, section.sec-text h4, section.sec-text h5, section.sec-text h6, section.sec-text p {
    color: #000 !important;
}
.sec-icon-text .item {
    text-align: center;
    padding: 10px;
}
.sec-icon-text .item .icon {
    background-color: transparent;
    font-size: 36px;
    margin-bottom: 10px;
	color: #fff;

}
section.sec-icon-text[class*="theme-dark-color"] * {color:#fff;}
section.sec-icon-text[class*="theme-light-color"] * {color:#000;}
.sec-icon-text .item .icon i.fa {
    top: 0;
    transform: translateY(0);
}
.default-section {
    position: relative;
}

.default-section:before {
    content: '';
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    background-color: rgba(0,0,0,0.7);
}
.default-img {
    width: 100%;
    height: 460px;
}

.default-img img {
    width: 100%;
    height: 100%;
}

.default-section h1, .default-section h2, .default-section h3, .default-section h4, .default-section h5, .default-section h6, .default-section p {
    color: #fff;
}
.faq-heading .page-heading, .faq-heading-2 .page-heading, .testimonial-heading .page-heading, .project-section .page-heading {
    margin: 70px 0;
}
section .faqs h4, section .faqs p {
    margin-bottom: 20px !important;
}
section .faqs h4:last-child, section .faqs p:last-child {
    margin-bottom: 0 !important;
}

section .faqs p {
    font-size: 14px;
}
section .faqs h4 {
    font-size: 20px;
}
.faq-heading-2{position:relative;}
.faq-heading-2:before, .testimonial-heading-2:before{
		content:'';
		width:100%;
		height:100%;
		position:absolute;
		top:0;
		left:0;
		background-color:rgba(0,0,0,0.5);
}
.faq-heading-2 h1, .testimonial-heading-2 h1, .faq-heading-2 h2, .testimonial-heading-2 h2, .faq-heading-2 h3, .testimonial-heading-2 h3, .faq-heading-2 h4, .testimonial-heading-2 h4, .faq-heading-2 h5, .testimonial-heading-2 h5, .faq-heading-2 h6, .testimonial-heading-2 h6, .faq-heading-2 p, .testimonial-heading-2 p {
	
	color:#fff;
}
.testimonial-01 .testimonialStyle1 {background-color: #fff;-webkit-box-shadow: 0px 3px 5px 0px rgb(0, 0, 0, 0.1);-moz-box-shadow: 0px 3px 5px 0px rgb(0, 0, 0, 0.1);box-shadow: 0px 3px 5px 0px rgb(0, 0, 0, 0.1);}

.widget-section.widgetBlock1 .heroHeading1 {
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 50px;
    width: 50%;
}
.service-style-1 .item .icon {
    color: #000;
}

.service-style-1 .item {
    margin-bottom: 10px;
    padding: 15px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
}
.bio-image {
    width: 100%;
    height: 260px;
}

.bio-image img {
    width: 100%;
    height: 100%;
}
.contact-information h2, .contact-information h6, .contact-information p {
    text-align: left;
}
.bio-info {
    text-align: left;
}
.blog-content h3, .blog-content h4, .blog-content p{text-align:left;}

.sec-form input[type="text"], .sec-form input[type="email"], .sec-form textarea {
    width: 100%;
    padding: 8px;
    outline:none;
}
.sec-form label{text-align:left;}
.sec-form h3 {
    font-size: 20px;
}

.sec-form p {
    font-size: 14px;
}

@media (min-width: 768px) and (max-width: 1024px) {
.widget-section.widgetBlock1 .heroHeading1 {
    width: 75%;
    padding: 25px;
}

.widget-section.widgetBlock1 .heroHeading1 h1 {
    font-size: 25px;
}

.widget-section.widgetBlock1 .heroHeading1 p {
    font-size: 14px;
}

}
@media (max-width: 991px) {
.mt-sm {
    margin-top: 30px;
}
}
@media (min-width: 320px) and (max-width: 640px) {
.widget-section.widgetBlock1 .heroHeading1 {
    width: 90%;
    padding: 10px;
	margin:0;
}	
	.widget-section.widgetBlock1 .heroHeading1 h1 {
    font-size: 16px;
}

.widget-section.widgetBlock1 .heroHeading1 p {
    font-size: 14px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
	
}
.widget-section.widgetBlock1 .heroHeading1 a.theme-button-second {
    font-size: 10px;
    padding: 8px 10px;
}
.contact-information {
    padding-top: 30px;
}
.blog-content {padding-top:20px;}
}


/*-------------------------------- widget-section-new-18 ------------------------------------*/
.widget-section.widget-section-new-18 h2 { font-size: 35px; font-family: Montserrat; }
.widget-section.widget-section-new-18 p { font-family: Montserrat; font-weight: 300; font-size: 20px;}
.widget-section-new-18 .partner-bg {    background-color: #fff;    padding: 25px;    min-height: 115px;    text-align: center;    margin-bottom: 10px;}
.widget-section-new-18 .partner-bg img {    max-width: 100%;    max-height: 65px; }
.widget-section.widget-section-new-18 .section-title { margin-bottom: 40px; }
/*a:focus,
button:focus {
    outline: none !important;
}

button::-moz-focus-inner {
    border: 0;
}

*:focus {
    outline: none;
}
*/

input,
button,
select,
textarea {
    outline: none;
}
.no-padding {
    padding: 0;
}
.no-gutters {
    margin-right: 0;
    margin-left: 0;
}
.no-gutters>.col, .no-gutters>[class*=col-] {
    padding-right: 0;
    padding-left: 0;
}
.widget-title {
    background-color: #000;
    color: #fff;
    padding: 20px 0;
}

.widget-title h1 {
    margin: 0;
}
/***** New Widget-01 *****/
.widget-item-04 .item-box {
    width: 100%;
    float: left;
    position: relative;
    overflow: hidden;
    text-align: left;
    max-width: 370px;
    margin-left: auto;
    margin-right: auto;
    color: #777777;
    box-shadow: 0 0 10px 0 rgb(0 0 0 / 15%);
}

.widget-item-04 .item-box .item-box-image {
    width: 100%;
    display: block;
    overflow: hidden;
    height: 240px;
    max-height: 240px;
}

.widget-item-04 .item-box .item-box-image img {
    width: 100%;
    height: 100%;
}

.widget-item-04 .item-box .item-box-content {
    padding-left: 18%;
    padding-right: 18%;
    padding-bottom: 60px;
}
.widget-item-04 .item-box .item-box-content {
    position: relative;
    padding: 18% 15px 30px;
    margin-top: -11.2%;
    z-index: 1;
    display: block !important;
}

.widget-item-04 .item-box .item-box-content:before {
    position: absolute;
    content: '';
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: #ffffff;
    transform-origin: 100% 50%;
    transform: skewY(-6deg);
    will-change: transform;
    transition: all .3s ease;
    pointer-events: none;
    z-index: -1;
}

@media (min-width: 576px) {
    .widget-item-04 .item-box .item-box-content {
        padding-left: 10%;
        padding-right: 10%;
        padding-bottom: 30px;
    }
    .widget-item-04 .item-box span.counter {
        transform: translate3d(105%, -50%, 0);
    }
}


.widget-item-04 .item-box .item-box-content span.counter {
    display: inline-block;
    text-align: center;
    position: absolute;
    top: 0;
    left: 50%;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    font-size: 26px;
    line-height: 50px;
    font-weight: 300;
    letter-spacing: .075em;
    font-family: "Roboto", -apple-system, BlinkMacSystemFont, "Segoe UI", "Helvetica Neue", Arial, sans-serif;
    color: rgba(255, 255, 255, 0.5);
    background: #db2a19;
    transform: translate3d(140%, -50%, 0);
    will-change: transform;
    transition: all .3s ease;
}
@media (min-width: 768px) and (max-width: 1023px) { 
.widget-item-04 .col-sm-6 {
    display: inline-block;
    text-align: center;
    float: none;
    margin-bottom: 30px;
    width: 50%;
}
.widget-item-04 .col-sm-6:last-child {
    margin-bottom:0;

}
}

@media (min-width: 768px){

.widget-item-04 .item-box .item-box-content span.counter {
    width: 70px;
    height: 70px;
    font-size: 36px;
    line-height: 70px;
}
}
@media (min-width: 576px) {

.widget-item-04 .item-box .item-box-content span.counter {
    transform: translate3d(105%, -50%, 0);
}
}

@media (min-width: 992px)
{
.widget-item-04 .item-box:hover .item-box-content::before {
    transform: none;
}
}

@media (min-width: 992px) {
.widget-item-04 .item-box:hover span.counter {
    transform: translate3d(-50%, -50%, 0);
}
}
@media (min-width: 320px) and (max-width: 640px) { 
	.widget-item-04 .item-box {
		margin-bottom:30px;
	}
}

/***** New Widget-02 *****/
.widget-service-15 .item-box {
    padding-top: 50px;
}
.widget-service-15 .item-box-image {
    width:100%;
    height:600px;
}
.widget-service-15 .item-box-image img {
    width:100%;
    height:100%;
    border-radius:10px;
    
}
.widget-service-15 .item-box .item-box-content {
    text-align: center;
}
.widget-service-15 .item-box-icon {
    font-size: 36px;
    text-align: center;
}
.widget-service-15 .item-box .item-box-icon i {
    width: 70px;
    height: 70px;
    line-height: 70px;
    border-radius: 50%;
    background: #ffae00;
    color: #fff;
}

.widget-service-15 .item-box.direction-md-rtl {
    direction: rtl;
}
@media (min-width: 992px){
div.direction-md-rtl.item-box > div.box__left {
    padding-right: 0;
    padding-left: 30px;
}
}

@media (min-width: 992px){
.widget-service-15 .item-box > .box__left {
    padding-right: 20px;
    padding-bottom: 0;
}
}
@media (min-width: 992px) {
.widget-service-15 .item-box > .box__left, .widget-service-15 .item-box > .box__right, .item-box > .item-box-content {
    display: table-cell;
    vertical-align: top;
}
}
@media (min-width: 480px) {
.widget-service-15 .item-box.max-width {
    overflow: hidden;
    max-width: 516px;
    margin-left: auto;
    margin-right: auto;
    padding-right: 10px;
    padding-left: 10px;
}
}
@media (min-width: 320px) and (max-width: 480px)  {
.widget-service-15 .item-box-image {
    height: 300px;
}
}
/***** New Widget-03 *****/
.widget-about-15 .about-content {
    background-color: #fd5d14;
    padding: 70px;
}


.widget-about-15 .about-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
}

.widget-about-15 .left-side, .widget-about-15 .left-side .about-img, .widget-about-15 .right-side {
    height: 700px;
}

.widget-about-15 .left-side {
    position: relative;
}

.widget-about-15 .left-side .about-img-text {
    position: absolute;
    top: 0;
    padding: 30px;
    overflow: hidden;
    max-width: 215px;
    left: 0;
    right: 0;
    background-color: #030e27;
}
.widget-about-15 .left-side .about-img-text * {
    color: #fff;
}
.widget-about-15 .about-content * {
    color: #fff;
}

.widget-about-15 .about-content  h2 {
    line-height: 1.8;
    font-weight: bold;
    margin-top: 0;
    margin-bottom: 20px;
    font-size: 28px;
}

.widget-about-15 .about-content p {
    font-size: 16px;
    font-weight: normal;
    margin-bottom: 20px;
}

.widget-about-15 .about-content .item {
    margin-top: 20px;
    margin-bottom: 40px;
    text-align: left;
    transition: 0.3s all;
}

.widget-about-15 .about-content .item .icon {
    color: #fff;
    margin-bottom: 10px;
    font-size: 45px;
    width: 45px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
    background-color: transparent;
    transition: 0.3s all;
}

.widget-about-15 .about-content .item  .item-content {}

.widget-about-15 .about-content .item .item-content h5 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 20px;
}

.widget-about-15 .about-content .item .item-content p {
    font-size: 16px;
    font-weight: normal;
    margin-bottom: 10px;
}

.widget-about-15 .about-content .item .icon i.fa {
    top: 0;
    position: static;
    transform: translate(0, 0);
}
@media (min-width: 768px) and (max-width: 1023px) {
.widget-about-15 .about-content {
    height: auto;
    padding: 50px 100px;
}
}


@media (min-width: 320px) and (max-width: 480px) {

.widget-about-15 .left-side .about-img {
    height: 200px;
}

.widget-about-15 .left-side .about-img-text {padding: 10px;max-width: 130px;}

.widget-about-15 .left-side .about-img-text h5 {
    font-size: 12px;
}

.widget-about-15 .left-side .about-img-text h2 {
    font-size: 16px;
    font-weight: bold;
}

.widget-about-15 .right-side, .widget-about-15 .left-side {
    height: auto;
}

.widget-about-15 .about-content {
    padding: 15px;
}

.widget-about-15 .about-content h2 {
    font-size: 16px;
    text-align: left;
    margin-bottom: 10px;
}

.widget-about-15 .about-content p {
    font-size: 14px;
    text-align: left;
}

.widget-about-15 .about-content .item {
    margin: 10px 0 10px 0;
}

.widget-about-15 .about-content .item .icon {
    width: 30px;
    height: 30px;
    font-size: 24px;
}

.widget-about-15 .about-content .item .item-content h5 {
    font-size: 14px;
    margin-bottom: 10px;
}

.widget-about-15 .about-content .item .item-content p {
    font-size: 14px;
}


}


.widget-service-16 .rotate {
    margin: auto;
    display: block;
    width: 113px;
    height: 113px;
    background-color: #ffffff;
    border-radius: 100%;
    border: 1px solid #cccccc;
    margin-bottom: 26px;
    margin-top: -78px;
    -webkit-transition: all .5s;
    -moz-transition: all .5s;
    -ms-transition: all .5s;
    -o-transition: all .5s;
}
.widget-service-16 .item-box .icon {
    color: #3a89ff;
    font-size: 36px;
}

.widget-service-16 .item-box:hover .rotate {
    background: #3a89ff;
    border: 1px solid transparent;
    transform: rotateY(180deg) rotate(0deg);
    /*Firefox*/
    
    -moz-transform: rotateY(180deg) rotate(0deg);
    /*Microsoft Internet Explorer*/
    
    -ms-transform: rotateY(180deg) rotate(0deg);
    /*Chrome, Safari*/
    
    -webkit-transform: rotateY(180deg) rotate(0deg);
    /*Opera*/
    
    -o-transform: rotateY(180deg) rotate(0deg);
    /*alter opacity*/
    
    position: relative;
    z-index: 1;
    -webkit-transition: all .9s;
    -moz-transition: all .9s;
    -ms-transition: all .9s;
    -o-transition: all .9s;
}

.widget-service-16 .item-box:hover .rotate i:before {
    color: #fff;
    transform: rotateY(180deg);
    -webkit-transition: all .9s;
    -moz-transition: all .9s;
    -ms-transition: all .9s;
    -o-transition: all .9s;
}

.widget-service-16 .item-box {
    border: 1px solid #cccccc;
    padding: 20px;
    margin-top: 57px;
    margin-bottom: 30px;
    position: relative;
    background: #fff;
    -webkit-transition: all .5s;
    -moz-transition: all .5s;
    -ms-transition: all .5s;
    -o-transition: all .5s;
    text-align:center;
}
.widget-service-16 .item-box:before {
    position: absolute;
    top: 5px;
    right: 5px;
    bottom: 5px;
    left: 5px;
    content: '';
    opacity: 0;
    -webkit-transition: opacity 0.5s, -webkit-transform 1.3s;
    transition: opacity 0.35s, transform 1.3s;
    border-right: 1px solid #3a89ff;
    border-left: 1px solid #3a89ff;
    -webkit-transform: scale(1, 0);
    transform: scale(1, 0);
}
.widget-service-16 .item-box:after {
    position: absolute;
    top: 5px;
    right: 5px;
    bottom: 5px;
    left: 5px;
    content: '';
    opacity: 0;
    -webkit-transition: opacity 0.35s, -webkit-transform 1.3s;
    transition: opacity 0.5s, transform 1.3s;
    border-top: 1px solid #3a89ff;
    border-bottom: 1px solid #3a89ff;
    -webkit-transform: scale(0, 1);
    transform: scale(0, 1);
}
.widget-service-16 .item-box:hover:after,
.widget-service-16 .item-box:hover:before {
    opacity: 1;
    -webkit-transform: scale(1);
    transform: scale(1);
}
.widget-service-16 .item-box:hover {
    border: 1px solid transparent;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    -webkit-transition: all .5s;
    -moz-transition: all .5s;
    -ms-transition: all .5s;
    -o-transition: all .5s;
}
.widget-service-16 .item-box:hover h4 a {
    color: #3a89ff;
    -webkit-transition: all .5s;
    -moz-transition: all .5s;
    -ms-transition: all .5s;
    -o-transition: all .5s;
}
.widget-service-16 .item-box h4 a {
    font-size: 20px;
    font-weight: 600;
    z-index: 10;
    position: relative;
    text-transform: capitalize;
}
.widget-service-16 .item-box h6 {
    text-align: center;
}
.widget-service-16 .item-box h6 a {
    z-index: 10;
    position: relative;
    font-size: 16px;
    color: #3a89ff;
    font-weight: 500;
    display: inline-block;
    text-align: center;
    text-transform: capitalize;
    -webkit-transition: all 0.5s;
    -o-transition: all 0.5s;
    -ms-transition: all 0.5s;
    -moz-transition: all 0.5s;
    transition: all 0.5s;
}
.widget-service-16 .item-box h3 a {
    font-size: 16px;
    color: #202020;
    font-weight: 500;
    z-index: 10;
    position: relative;
}
@media (min-width: 320px) and (max-width: 480px) {
	.widget-service-16 .item-box {
		margin-bottom:100px;
	}
}
/***** New Widget-06 *****/
.widget-about-16 .about-content {
    padding-right: 70px;
}

.widget-about-16 .about-content h2 {
    font-size: 22px;
    color: #00c881;
    margin-bottom: 10px;
    font-weight: 600;
}

.widget-about-16 .about-content  h3 {
    font-size: 36px;
    margin-bottom: 30px;
    font-weight: bold;
    line-height: 1.5;
}

.widget-about-16 
 .about-img {
    padding-right: 100px;
    position: relative;
    height: 650px;
}

.widget-about-16 
 .about-img img {
    border-radius: 20px;
    width: 100%;
    height: 100%;
}

.widget-about-16 .about-img-text {
    position: absolute;
    top: 50%;
    right: 0;
    padding: 60px 43px 60px 50px;
    -webkit-transform: translateY(-50%);
    transform: translateY(-50%);
    width: 300px;
    max-width: 300px;
    border-radius: 30px;
    background-color: #fff;
    -webkit-box-shadow: 0 5px 83px 0 rgb(40 40 40 / 12%);
    box-shadow: 0 5px 83px 0 rgb(40 40 40 / 12%);
    z-index: 3;
}

.widget-about-16 .about-img-text .item {}

.widget-about-16 .about-img-text .item .icon {
    color: #00c881;
    font-size: 70px;
    line-height: 1;
    margin-bottom: 25px;
    background-color: transparent;
}

.widget-about-16 .about-img-text .item .icon i.fa {
    line-height: 1;
    top: 0;
    transform: translate(0,0);
}

.widget-about-16 .about-img-text .item .item-content {}

.widget-about-16 .about-img-text .item .item-content h4 {
    font-size: 17px;
    line-height: 1.6;
    font-weight: bold;
}
@media (min-width: 768px) and (max-width: 1023px) { 
	
.widget-about-16 .about-content {
	padding:0;
	margin-bottom: 30px;
}

.widget-about-16 .about-img {width: 75%;padding-right: 0;}

.widget-about-16 .about-img-text {right: 50px;}
}


@media (max-width: 640px) {

 .widget-about-16 .about-content {
    padding: 0;
}
.widget-about-16 .about-img {
    padding: 30px 0;
    height: 470px;
}
.widget-about-16 .about-img-text {
    bottom: 0;
    padding: 20px 10px;
    width: 200px;
    height: auto;
    left: 50%;
    transform: translateX(-50%);
    top: auto;
    border-radius: 15px;
}

.widget-about-16 .about-img-text .item .item-content h4 {
    font-size: 14px;
}

.widget-about-16 .about-img-text .item .icon {
    font-size: 50px;
    margin-bottom: 10px;
}
}
/***** New Widget-07 *****/


.widget-item-05 .item-box {
    position: relative;
    padding: 40px 40px 0 40px;
    text-align: center;
    background-color: #fff;
    border-radius: 25px;
    margin-bottom: 90px;
    box-shadow: 0 0 15px rgb(51 51 51 / 10%);
}

.widget-item-05 .item-box:after {
    content: "";
    position: absolute;
    top: 50px;
    left: 0;
    width: 2.5px;
    height: calc(100% - 100px);
    background-color: #00c881;
}

.widget-item-05 .item-box .item-box-icon {
    width: 80px;
    height: 80px;
    line-height: 80px;
    text-align: center;
    display: inline-block;
    border-radius: 20px 0px 20px 20px;
    background-color: #fff;
    -webkit-box-shadow: 0 5px 23px 0 rgb(40 40 40 / 12%);
    box-shadow: 0 5px 23px 0 rgb(40 40 40 / 12%);
    margin-bottom: 25px;
    font-size: 30px;
}

.widget-item-05 .item-box .item-box-icon i.fa {
    top: 0;
    transform: translate(0, 0);
}

.widget-item-05 .item-box .item-box-content {}

.widget-item-05 .item-box  .item-box-image {
    border-radius: 3px;
    -webkit-transform: translateY(40px);
    transform: translateY(40px);
    position: relative;
    overflow: hidden;
}

.widget-item-05 .item-box .item-box-image img {
    width: 100%;
    max-width: 100%;
    border-radius: 30px 30px 30px 0px;
    -webkit-transition: all 0.6s linear;
    transition: all 0.6s linear;
}

.widget-item-05 .item-box  .item-box-content {}

.widget-item-05 .item-box  .item-box-content h4 {
    margin-bottom: 20px;
    font-size: 20px;
    font-weight: bold;
}

.widget-item-05 .item-box .item-box-content p {
    font-size: 14px;
    margin-bottom: 20px;
}
@media (min-width: 768px) and (max-width: 1023px) {
.widget-item-05  .col-sm-6 {
    display: inline-block;
    text-align: center;
    float: none;
}
.widget-item-05 .item-box:after {
    content: '';
    width: 80%;
    top: 0;
    height: 2.5px;
    left: 50%;
    transform: translateX(-50%);
}

}
@media (min-width: 768px) and (max-width: 1023px) {
    

.widget-service-17 .col-sm-6 {
    display: inline-block;
    float: none;
}
.widget-service-17 .item-box .step:after {

    content:'';
    display:none
}

}
@media (min-width: 320px) and (max-width: 640px) {
.widget-item-05 .item-box {
        padding: 20px 20px 0 20px;
}

.widget-item-05 .item-box:after {
    content:'';
    height: 2.5px;
    width: 80%;
    left: 50%;
    transform: translateX(-50%);
    top: 0;
}
}




/***** New Widget-08 *****/
.widget-service-17 .item-box {
    padding: 0px 60px;
    text-align: center;
}

.widget-service-17 .item-box .icon {background-color: #e9f1f7;margin-bottom: 20px;display: block;position: relative;width: 140px;height: 110px;font-size: 36px;line-height: 110px;transition: all 0.5s;text-align: center;cursor: pointer;border-radius: 80px 200px 200px 362px;color: #2989d8;margin: 0 auto;}
.widget-service-17 .item-box .item-box-content h3 {
    font-weight: bold;
    margin-bottom: 5px;
    font-size: 28px;
}

.widget-service-17 .item-box .item-box-content p {
    font-size: 16px;
    line-height: 1.9;
}

.widget-service-17 .item-box .step {
    margin-top: 33px;
    margin-bottom: 20px;
    box-shadow: 0 0px 13px 2px rgb(40 127 249 / 50%);
    background: #287ff9;
    text-shadow: 0 4px 8px rgb(40 127 249 / 50%);
    display: inline-block;
    color: #fff;
    font-size: 18px;
    width: 38px;
    height: 38px;
    position: relative;
    border-radius: 50%;
    line-height: 38px;
    font-weight: bold;
    text-align: center;
}

.widget-service-17 .item-box .step:after {
    position: absolute;
    content: '...................................................................';
    height: 31px;
    width: 370px;
    top: -4px;
    font-size: 17px;
    overflow: hidden;
    color: #287ff9;
}
.widget-service-17 .item-box .step.no-line:after {
    content:"";
	display: none;
	
}
@media only screen and (max-width: 1199px) {
.widget-service-17 .item-box .step:after {
    width: 300px;
}
}
@media only screen and (max-width: 991px){
.widget-service-17 .item-box {
    padding: 0px 20px;
}
.widget-service-17 .item-box .step:after {
    width: 230px;
}
}





/***** New Widget-custom *****/
.widget-about-custom .about-content {
    background-color: #3f52e3;
    padding: 70px;
}


.widget-about-custom .about-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center;
}

.widget-about-custom .left-side, .widget-about-custom .left-side .about-img, .widget-about-custom .right-side {
    height: 700px;
}

.widget-about-custom .left-side {
    position: relative;
}

.widget-about-custom .left-side .about-img-text {
    position: absolute;
    top: 0;
    padding: 30px;
    overflow: hidden;
    max-width: 215px;
    left: 0;
    right: 0;
    background-color: #030e27;
}
.widget-about-custom .left-side .about-img-text * {
    color: #fff;
}
.widget-about-custom .about-content * {
    color: #fff;
}

.widget-about-custom .about-content  h2 {
    line-height: 1.8;
    font-weight: bold;
    margin-top: 0;
    margin-bottom: 20px;
    font-size: 28px;
}

.widget-about-custom .about-content p {
    font-size: 16px;
    font-weight: normal;
    margin-bottom: 20px;
}

.widget-about-custom .about-content .item {
    margin-top: 20px;
    margin-bottom: 40px;
    text-align: left;
    transition: 0.3s all;
}

.widget-about-custom .about-content .item .icon {
    color: #fff;
    margin-bottom: 10px;
    font-size: 45px;
    width: 45px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
    background-color: transparent;
    transition: 0.3s all;
}

.widget-about-custom .about-content .item  .item-content {}

.widget-about-custom .about-content .item .item-content h5 {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 20px;
}

.widget-about-custom .about-content .item .item-content p {
    font-size: 16px;
    font-weight: normal;
    margin-bottom: 10px;
}

.widget-about-custom .about-content .item .icon i.fa {
    top: 0;
    position: static;
    transform: translate(0, 0);
}
@media (min-width: 768px) and (max-width: 1023px) {
.widget-about-custom .about-content {
    height: auto;
    padding: 50px 100px;
}
}


@media (min-width: 320px) and (max-width: 480px) {

.widget-about-custom .left-side .about-img {
    height: 200px;
}

.widget-about-custom .left-side .about-img-text {padding: 10px;max-width: 130px;}

.widget-about-custom .left-side .about-img-text h5 {
    font-size: 12px;
}

.widget-about-custom .left-side .about-img-text h2 {
    font-size: 16px;
    font-weight: bold;
}

.widget-about-custom .right-side, .widget-about-custom .left-side {
    height: auto;
}

.widget-about-custom .about-content {
    padding: 15px;
}

.widget-about-15 .about-content h2 {
    font-size: 16px;
    text-align: left;
    margin-bottom: 10px;
}

.widget-about-custom .about-content p {
    font-size: 14px;
    text-align: left;
}

.widget-about-custom .about-content .item {
    margin: 10px 0 10px 0;
}

.widget-about-custom .about-content .item .icon {
    width: 30px;
    height: 30px;
    font-size: 24px;
}

.widget-about-custom .about-content .item .item-content h5 {
    font-size: 14px;
    margin-bottom: 10px;
}

.widget-about-custom .about-content .item .item-content p {
    font-size: 14px;
}
}
/***** New Widget-custom *****/
/* Template : Gallery Style 2 (g2) - START */
.dm-hexagon img {
    width: 100%;
    height: 100%;
}

.hexagon-gallery {
    margin: auto;
    max-width: 1000px;
    display: grid;
    grid-template-columns: repeat(8, 1fr);
    grid-auto-rows: 200px;
    grid-gap: 14px;
    padding-bottom: 50px;
}

.dm-hexagon {
    display: flex;
    position: relative;
    max-width: 240px;
    height: 265px;
    background-color: #424242;
    -webkit-clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
    clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
}

.dm-hexagon:first-child {
    grid-row-start: 1;
    grid-column: 2 / span 2;
}

.dm-hexagon:nth-child(2) {
    grid-row-start: 1;
    grid-column: 4 / span 2;
}

.dm-hexagon:nth-child(3) {
    grid-row-start: 1;
    grid-column: 6 / span 2;
}

.dm-hexagon:nth-child(4) {
    grid-row-start: 2;
    grid-column: 1 / span 2;
}

.dm-hexagon:nth-child(5) {
    grid-row-start: 2;
    grid-column: 3 / span 2;
}

.dm-hexagon:nth-child(6) {
    grid-row-start: 2;
    grid-column: 5 / span 2;
}

.dm-hexagon:nth-child(7) {
    grid-row-start: 2;
    grid-column: 7 / span 2;
}

.dm-hexagon:nth-child(8) {
    grid-row-start: 3;
    grid-column: 2 / span 2;
}

.dm-hexagon:nth-child(9) {
    grid-row-start: 3;
    grid-column: 4 / span 2;
}

.dm-hexagon:nth-child(10) {
    grid-row-start: 3;
    grid-column: 6 / span 2;
}

@media (max-width: 600px) {
    .hexagon-gallery {
        display: block;
        text-align: center;
    }

    .hexagon-gallery .dm-hexagon {
        display: inline-block;
        margin-bottom: 15px;
    }

    .hexagon-gallery .dm-hexagon img {
        height: 100%;
    }
}

/* Template : Gallery Style 2 - END */ /* Template : Gallery Style 3 (g3) - START */
a.polaroid {
    display: block;
    text-decoration: none;
    color: #333;
    padding: 10px 10px 20px 10px;
    width: 150px;
    border: 1px solid #BFBFBF;
    background-color: white;
    z-index: 2;
    font-size: 0.7em;
    -webkit-box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    -moz-box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    -webkit-transition: -webkit-transform 0.5s ease-in;
}

a.polaroid:hover, a.polaroid:focus, a.polaroid:active {
    z-index: 999;
    border-color: #6A6A6A;
    -webkit-box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    -moz-box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    -webkit-transform: rotate(0deg);
    -moz-transform: rotate(0deg);
    transform: rotate(0deg);
}

.grid-gallery-style-3 .polaroid img {
    margin: 0 0 15px;
    width: 150px;
    max-height: 150px;
    width: 100%;
}

.grid-gallery-style-3 a img {
    border: none;
    display: block;
}

.grid-gallery-style-3 {
    position: relative;
    width: 80%;
    margin: 0 auto;
    max-width: 70em;
    height: 450px;
    min-width: 800px;
    max-width: 900px;
}

.grid-gallery-style-3 .polaroid {
    position: absolute;
}

.grid-gallery-style-3 h1 {
    position: absolute;
    z-index: 5;
    top: 150px;
    text-align: center;
    width: 100%;
    line-height: 1.9;
}

.grid-gallery-style-3 h1 span {
    background-color: white;
    font-family: "Helvetica Neue", Arial, Helvetica, sans-serif;
    padding: 0.4em 0.8em 0.3em 0.8em;
    -webkit-box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    -moz-box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    border: 1px solid #6A6A6A;
}

.grid-gallery-style-3 .small {
    width: 75px;
    padding: 6px 6px 12px 6px;
    font-size: 0.6em;
}

.grid-gallery-style-3 .small img {
    width: 100%;
    max-height: 75px;
}

.grid-gallery-style-3 .medium {
    width: 200px;
    padding: 13px 13px 26px 13px;
    font-size: 0.8em;
}

.grid-gallery-style-3 .medium img {
    width: 100%;
    max-height: 200px;
}

.grid-gallery-style-3 .large {
    width: 300px;
    padding: 20px 20px 30px 20px;
    font-size: 1em;
}

.grid-gallery-style-3 .large img {
    width: 100%;
    max-height: 300px;
}

.grid-gallery-style-3 .img1 {
    bottom: 10px;
    right: 365px;
    -webkit-transform: rotate(10deg);
    -moz-transform: rotate(10deg);
    transform: rotate(10deg);
}

.grid-gallery-style-3 .img2 {
    top: 50px;
    right: 20px;
    -webkit-transform: rotate(-4deg);
    -moz-transform: rotate(-4deg);
    transform: rotate(-4deg);
}

.grid-gallery-style-3 .img3 {
    left: 400px;
    top: 0;
    -webkit-transform: rotate(-5deg);
    -moz-transform: rotate(-5deg);
    transform: rotate(-5deg);
}

.grid-gallery-style-3 .img4 {
    top: 10px;
    left: 495px;
    -webkit-transform: rotate(-20deg);
    -moz-transform: rotate(-20deg);
    transform: rotate(-20deg);
}

.grid-gallery-style-3 .img5 {
    bottom: 0;
    right: 0;
    -webkit-transform: rotate(1deg);
    -moz-transform: rotate(1deg);
    transform: rotate(1deg);
}

.grid-gallery-style-3 .img6 {
    bottom: 10px;
    right: 156px;
    -webkit-transform: rotate(6deg);
    -moz-transform: rotate(6deg);
    transform: rotate(6deg);
}

.grid-gallery-style-3 .img7 {
    bottom: 0;
    left: 400px;
    -webkit-transform: rotate(-10deg);
    -moz-transform: rotate(-10deg);
    transform: rotate(-10deg);
}

.grid-gallery-style-3 .img8 {
    bottom: -20px;
    left: 700px;
    -webkit-transform: rotate(-8deg);
    -moz-transform: rotate(-8deg);
    transform: rotate(-8deg);
}

.grid-gallery-style-3 .img9 {
    bottom: 0;
    left: 0;
    -webkit-transform: rotate(-8deg);
    -moz-transform: rotate(-8deg);
    transform: rotate(-8deg);
}

.grid-gallery-style-3 .img10 {
    top: 0;
    left: 20px;
    -webkit-transform: rotate(8deg);
    -moz-transform: rotate(8deg);
    transform: rotate(8deg);
}

.grid-gallery-style-3 .img11 {
    top: 0;
    right: 0;
    -webkit-transform: rotate(-8deg);
    -moz-transform: rotate(-8deg);
    transform: rotate(-8deg);
}

.grid-gallery-style-3 .img12 {
    top: 0;
    left: 680px;
    -webkit-transform: rotate(18deg);
    -moz-transform: rotate(18deg);
    transform: rotate(18deg);
}

.grid-gallery-style-3 .img13 {
    bottom: -20px;
    right: 630px;
    -webkit-transform: rotate(4deg);
    -moz-transform: rotate(4deg);
    transform: rotate(4deg);
}

.grid-gallery-style-3 .img14 {
    top: 90px;
    left: 430px;
    -webkit-transform: rotate(15deg);
    -moz-transform: rotate(15deg);
    transform: rotate(15deg);
}

.grid-gallery-style-3 .img15 {
    left: 176px;
    top: 20px;
    -webkit-transform: rotate(-8deg);
    -moz-transform: rotate(-8deg);
    transform: rotate(-8deg);
}

/* Template : Gallery Style 3 - END */ /* Template : Gallery Style 4 (g4) - START */
.grid-gallery-style-1 {
    -webkit-column-count: 4;
    -moz-column-count: 4;
    column-count: 4;
    -webkit-column-gap: 20px;
    -moz-column-gap: 20px;
    column-gap: 20px;
    margin-top: 25px;
}

@media (max-width: 1200px) {
    .grid-gallery-style-1 {
        -webkit-column-count: 3;
        -moz-column-count: 3;
        column-count: 3;
        -webkit-column-gap: 20px;
        -moz-column-gap: 20px;
        column-gap: 20px;
    }
}

@media (max-width: 800px) {
    .grid-gallery-style-1 {
        -webkit-column-count: 2;
        -moz-column-count: 2;
        column-count: 2;
        -webkit-column-gap: 20px;
        -moz-column-gap: 20px;
        column-gap: 20px;
    }
}

@media (max-width: 600px) {
    .grid-gallery-style-1 {
        -webkit-column-count: 1;
        -moz-column-count: 1;
        column-count: 1;
    }
}

.grid-gallery-style-1 .img-card {
    width: 100%;
    height: auto;
    margin: 4% auto;
    box-shadow: -3px 5px 15px #000;
    cursor: pointer;
}

/* Template : Gallery Style 3 - END */
/*** Soical Icon Style CSS ***/
.new-social-icons > ul {
    list-style: none;
    margin: 0;
    padding: 0;
}
.new-social-icons.left-align > ul {
    text-align:left;
}
.new-social-icons.center-align > ul {
    text-align:center;
}
.new-social-icons.right-align > ul {
    text-align:right;
}
.new-social-icons.font-16 > ul {
    padding: 10px 0;
}
.new-social-icons > ul > li {
    display: inline-block !important;
    margin-right: 10px;

}
.new-social-icons > ul > li:last-child {
    margin-right: 0;
}
.new-social-icons > ul > li > a {
    width: 40px;
    height: 40px;
    display: block;
    background-color: #686868;
    text-align: center;
    line-height:normal !important;
}
.new-social-icons> ul > li > a > span.fa, .new-social-icons> ul > li > a > i.fa {
    margin: 0;
    color: #fff;
    line-height:40px;
	font-size:16px;
}
/*** hexagon css ***/
.new-social-icons.shape-hexagon {
    padding: 15px 0;
}
.new-social-icons.shape-hexagon > ul > li {
    margin-bottom: 40px;
}
.new-social-icons.shape-hexagon > ul > li > a,
.new-social-icons.font-16.shape-hexagon > ul > li > a {
    width: 50px !important;
    height: 30px !important;
    position: relative;
    border-radius: 0 !important;
    display: block;
    background-color: #686868;
}
.new-social-icons.shape-hexagon > ul > li > a:before,
.new-social-icons.font-16.shape-hexagon > ul > li > a:before  {
    content: "";
    position: absolute;
    top: -15px;
    left: 0;
    width: 0;
    height: 0;
    border-left: 25px solid transparent;
    border-right: 25px solid transparent;
    border-bottom: 15px solid #686868;
    -webkit-transition: all 0.3s ease-in-out;
    -moz-transition: all 0.3s ease-in-out;
    -ms-transition: all 0.3s ease-in-out;
    -o-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
}
.new-social-icons.shape-hexagon > ul > li > a:after,
.new-social-icons.font-16.shape-hexagon > ul > li > a:after  {
    content: "";
    position: absolute;
    bottom: -15px;
    left: 0;
    width: 0;
    height: 0;
    border-left: 25px solid transparent;
    border-right: 25px solid transparent;
    border-top: 15px solid #686868;
    -webkit-transition: all 0.3s ease-in-out;
    -moz-transition: all 0.3s ease-in-out;
    -ms-transition: all 0.3s ease-in-out;
    -o-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
}
.new-social-icons.shape-hexagon > ul > li > a > span.fa,
.new-social-icons.font-16.shape-hexagon > ul > li > a > span.fa,
.new-social-icons.shape-hexagon > ul > li > a > i.fa,
.new-social-icons.font-16.shape-hexagon > ul > li > a > i.fa {
    line-height: 30px;
}
.new-social-icons.font-32.shape-hexagon > ul > li > a {
    width: 60px !important;
    height: 40px !important;
}
.new-social-icons.font-32.shape-hexagon > ul > li > a::before {
    border-left: 30px solid transparent;
    border-right: 30px solid transparent;
    border-bottom: 20px solid #686868;
    top: -20px;
}
.new-social-icons.font-32.shape-hexagon > ul > li > a:after {
    border-left: 30px solid transparent;
    border-right: 30px solid transparent;
    border-top: 20px solid #686868;
    bottom: -20px;
}
.new-social-icons.font-32.shape-hexagon > ul > li > a > span.fa,
.new-social-icons.font-32.shape-hexagon > ul > li > a > i.fa {
    line-height: 40px;
}
.new-social-icons.font-48.shape-hexagon > ul > li > a {
    width: 80px !important;
    height: 60px !important;
}
.new-social-icons.font-48.shape-hexagon > ul > li > a::before {
    border-left: 40px solid transparent;
    border-right: 40px solid transparent;
    border-bottom: 30px solid #686868;
    top: -30px;
}
.new-social-icons.font-48.shape-hexagon > ul > li > a::after {
    border-left: 40px solid transparent;
    border-right: 40px solid transparent;
    border-top: 30px solid #686868;
    bottom: -30px;
}
.new-social-icons.font-48.shape-hexagon > ul > li > a > span.fa {
    line-height: 60px;
}
/*** circle & square css ***/
.new-social-icons.shape-circle > ul > li,
.new-social-icons.shape-square > ul > li {
    margin-bottom:10px;
}
.new-social-icons.shape-circle > ul > li > a {
    border-radius: 100% !important;
}
.new-social-icons.shape-circle > ul > li > a, .new-social-icons.shape-square > ul > li > a {
    background-color: #686868;
    display: block;
    width: 60px !important;
    height: 60px !important;
}
.new-social-icons.shape-circle > ul > li > a > span.fa, .new-social-icons.shape-circle > ul > li > a > i.fa {
    line-height: 60px;
}
.new-social-icons.shape-square > ul > li > a {
    border-radius: 0% !important;
}
/*** Alignment css ***/
.new-social-icons.left-align {
    text-align: left;
}
.new-social-icons.center-align {
    text-align: center;
}
.new-social-icons.right-align {
    text-align: right;
}
/*** font-size css ***/
.new-social-icons.font-16 > ul > li > a {
    width: 40px !important;
    height: 40px !important;
}
.new-social-icons.font-16 ul > li > a > span.fa,
.new-social-icons.font-16 ul > li > a > i.fa {
    font-size: 16px;
    line-height:40px;
}
.new-social-icons.font-32 > ul > li > a {
    width: 60px !important;
    height: 60px !important;
}
.new-social-icons.font-32 ul > li > a > span.fa,
.new-social-icons.font-32 ul > li > a > i.fa {
    font-size: 32px;
    line-height:60px;
}
.new-social-icons.font-48 > ul > li > a {
    width: 80px !important;
    height: 80px !important;
}
.new-social-icons.font-48 ul > li > a > span.fa,
.new-social-icons.font-48 ul > li > a > i.fa {
    font-size: 48px;
    line-height:80px;
}
/*** color css ***/
.new-social-icons.shape-hexagon.color-black ul > li > a, .new-social-icons.shape-circle.color-black ul > li > a, .new-social-icons.shape-square.color-black ul > li > a {
    background-color: #000 !important;
    color: #fff !important;
}
.new-social-icons.shape-hexagon.color-white ul > li > a, .new-social-icons.shape-circle.color-white ul > li > a, .new-social-icons.shape-square.color-white ul > li > a {
    background-color: #fff;
    color: #000;
}
.new-social-icons.shape-hexagon.color-black > ul > li > a:before {
    border-bottom-color:#000;
}
.new-social-icons.shape-hexagon.color-black > ul > li > a:after {
    border-top-color:#000;
}
.new-social-icons.shape-hexagon.color-white > ul > li > a:before {
    border-bottom-color:#fff;
}
.new-social-icons.shape-hexagon.color-white > ul > li > a:after {
    border-top-color:#fff;
}
/*** icon color css ***/
.new-social-icons.color-black ul > li > a > span.fa, .new-social-icons.color-black ul > li > a > i.fa {
    color: #fff !important;
}
.new-social-icons.color-white ul > li > a > span.fa, .new-social-icons.color-white ul > li > a > i.fa {
    color: #000 !important;
}
.new-social-icons.shape-hexagon ul > li > a > span.fa, .new-social-icons.shape-hexagon ul > li > a > i.fa {
    line-height: 30px;
}@charset "utf-8";

img {
	max-width: 200%;
	height: auto;
}
/* heading */
/* h1, h2, h3, h4, h5, h6 {
	margin: 0 0 10px;
	padding: 0;
	letter-spacing: 0;
	font-weight: bold;
}
h1 {
	font-size: 55px;
	line-height: 70px;
}
h2 {
	font-size: 48px;
	line-height: 60px
}
h3 {
	font-size: 36px;
	line-height: 54px
}
h4 {
	font-size: 32px;
	line-height: 46px
}
h5 {
	font-size: 24px;
	line-height: 40px
}
h6 {
	font-size: 18px;
	line-height: 30px
}
p {
	font-size: 16px;
	line-height: 25px;
	margin:0 0 10px;
}*/

/*section {
	padding: 80px 0;
	position: relative;
	width: 100%;
	overflow: hidden;
	z-index: 1;
	background-color: #fff;
}*/
.section-heading {
    text-align: center;
    margin-bottom: 60px;
}
.breadcrumb-section {
	position: relative;
	height: 400px;
}
.breadcrumb-section:before {
	content: '';
	width: 100%;
	height: 100%;
	background-color: #341010;
	position: absolute;
	top: 0;
	left: 0;
}

.centered-row {
	text-align: center;
}
.centered-col {
	display: inline-block;
	float: none;
}
.page-title {
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	text-align: center;
}
.page-title * {
	color: #fff;
}
.page-title h1 {
	font-weight: bold;
	text-transform: uppercase;
}
.page-title p {
	font-size: 20px;
	font-weight: normal;
	text-transform: capitalize;
}
/* About Us Page */
/* Services Page */
/* Client Page */
/* Pricing Page */
/* Privacy Page */
/* Term-Condition Page */
/* Faqs Page */
/* Contact Us Page */



.box-fancy {
	padding: 5%!important;
}
.box-fancy * {
    color: #fff;
}
.team-member {
	border: 1px solid #eee;
	box-shadow: 0 3px 16px rgb(0 0 0 / 3%);
}
 .team-member {
	background-color: #fff;
	text-align: center;
	position: relative;
	overflow: hidden;
	margin-bottom: 30px;
	border-radius: 4px;
}
.team-member .team-image {
	margin-bottom: 20px;
	height: 270px;
	width: 100%;
}
.team-member .team-image>img {
	border-radius: 0;
}
.team-member .team-image>img {
	width: 100%;
	height: 100%;
	object-fit: cover;
}
 .team-member .team-desc {
	padding: 20px;
}
.team-member .team-desc>h3 {
	font-size: 16px;
	line-height: 22px;
	margin-bottom: 0;
	margin-top: 0;
}
.team-member .team-desc>span {
	font-size: 13px;
	color: #bbb;
	line-height: 18px;
}
.team-member .team-desc>p {
	margin-top: 10px;
	font-size: 14px;
}
.align-center {
	display: inline-flex;
	text-align: center;
}
 .team-member .social-media-icons {
	margin: 0;
	padding: 0;
	text-align: center;
	display: inline-block;
}
.team-member .social-media-icons ul {
	list-style: none;
	margin: 0;
	padding: 0;
}
.team-member .social-media-icons ul li {
}
 .team-member .social-media-icons ul li {
	display: inline-block;
}
 .team-member .social-media-icons ul li a {
	display: block;
	width: 30px;
	height: 30px;
	border: 1px solid #e6e8eb;
	background-color: #fff;
	color: #4c5667;
	line-height: 30px;
	border-radius: 50%;
}
.service-sec-1 .cover-image {
	width: 100%;
	height: 400px;
}
.service-sec-1 .cover-image img {
	width: 100%;
	height: 100%;
}
.service-sec-1 .text-box {
	text-align: left;
	margin-top: 50px;
}
.feature-box, .feature-box-right {
	float: left;
}
.feature-box .icon {
    text-align: center;
    font-size: 30px;
}

.feature-box * {
    color: #fff;
}
.feature-box i {
	margin-bottom: 20px;
	display: inline-block;
}
.feature-box .pull-left {
	width: 15%;
}
.feature-box .pull-right {
	width: 80%;
}
.feature-box-right .pull-left {
	width: 80%;
}
.feature-box-right .pull-right {
	width: 15%;
}
.box-image {
	width: 100%;
	height: 385px;
}
.box-image img {
	width: 100%;
	height: 100%;
}

.service-sec-3 .content ul {
	margin: 0;
	padding: 30px 0;
	list-style: none;
}
.service-sec-3 .content ul li {
	position: relative;
	padding: 0 0 10px 22px;
	margin: 0 0 10px 0;
	border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}
.service-sec-3 .content ul li:before {
	content: "\f00c";
	position: absolute;
	top: 1px;
	left: 0;
	font-family: 'FontAwesome';
	font-weight: 900;
}
.contact-sec-2 .box-image {
	height: 450px;
	width: 100%;
}
.contact-sec-2 .box-image img {
	width: 100%;
	height: 100%;
}
.height-350px {
	height: 350px;
}
.contact-sec-2 .content-box {
	height: 450px;
}
.contact-sec-2 .content-box .item {
	padding: 40px 0;
	max-height: 256px;
	height: 225px;
	text-align: center;
}
.contact-sec-2 .content-box .item .content {
	width: 60%;
	margin: 0 auto;
}
.contact-sec-2 .content-box .item .icon {
	font-size: 35px;
	color: #fff;
}
.contact-sec-2 .content-box .item .content p, .contact-sec-2 .content-box .item .content a {
	color: #6f6f6f;
}
.contact-sec-2 .content-box .item .content h5 {
	color: #fff;
	font-size:20px;
}
.contact-sec-3 input, .contact-sec-3 textarea, .contact-sec-3 select {
	width: 100%;
	padding: 18px 25px;
	border: 1px solid #d1d1d1;
	font-size: 14px;
	margin: 0 0 20px 0;
	max-width: 100%;
	resize: none;
	color: inherit;
	border-radius: 0;
}
.accordion-color .panel {
	box-shadow: none;
	border: 0;
	border-radius: 0;
}
.accordion-color .panel .panel-heading {
	position: relative;
	padding: 0;
	border-bottom: 0px solid #fff;
	text-align: left;
}
.accordion-color .panel-title a.collapsed {
	display: block;
	color: #212121;
	background-color: #fff;
	border-color: #f1f1f1;
	padding: 22px 15px 22px 64px;
	border-radius: 0px;
}
.accordion-color .panel .panel-heading .panel-title {
    line-height: normal;
}
.accordion-color .panel-title a {
	display: block;
	color: #fff;
	border-color: #f1f1f1;
	padding: 22px 15px 22px 64px;
	background-color: #2196F3;
	border-bottom: 1px solid #2196F3;
}
.accordion-color .panel .panel-heading a.collapsed:after {
	content: "\f068";
	font-family: fontawesome;
}
.accordion-color .panel .panel-heading a:after {
	font-family: fontawesome;
	content: "\f067";
	font-size: 24px;
	width: 64px;
	height: 64px;
	line-height: 64px;
	text-align: center;
	position: absolute;
	top: 0;
	left: 0;
}
.accordion-color .panel-default>.panel-heading+.panel-collapse>.panel-body {
	border: 1px solid #fff;
	background: #fff;
	text-align: left;
}
.pricing-box {
	border: 1px solid #ededed;
}
.pricing-head {
	background-color: #fafafa;
	padding: 55px;
}
.pricing-title i.fa {
	font-size: 50px;
	padding: 30px;
	margin-bottom: 25px;
	background-color: #fff;
	box-shadow: 0 0 3px rgb(0 0 0 / 10%);
	border-radius: 50%;
	width: 110px;
	height: 110px;
}
.pricing-price {
}
.pricing-price p {
	font-weight: 600;
	color: #232323;
	text-transform: uppercase;
}
.pricing-price h4 {
	font-weight: 600;
	font-size: 40px;
	line-height: 46px;
	color: #232323;
	margin-bottom: 0;
}
.pricing-price span {
	margin-top: 5px;
	display: block;
	font-size: 11px;
	line-height: 14px;
	color: #6f6f6f;
	font-weight: 500;
}
.pricing-body {
	padding: 45px;
}
.pricing-body ul {
	list-style: none;
	margin: 0;
	padding: 0;
}
.pricing-body ul li {
	position: relative;
	padding: 0 0 8px 0;
	margin: 0 0 8px 0;
	border-bottom: 1px solid rgba(0, 0, 0, 0.1);
}
.pricing-footer {
	margin-top: 35px;
}
.theme-btn {
	background: #232323;
	border-color: #232323;
	color: #fff;
}
.client-box {
	height: 190px;
	margin-bottom: 30px;
	width: 100%;
	background-color: #fff;
	box-shadow: 0 5px 15px 3px rgb(17 21 23 / 10%);
	align-items: center;
	justify-content: center;
	display: flex;
}
section.client-sec-2 {
}
.client-sec-2 .box {
	padding-top: 18%;
	border-radius: 4px;
	padding-bottom: 18%;
	position: relative;
	border: 1px solid #ededed;
	background-color: #fff;
	height: 100%;
}
.client-sec-2 .box .icon {
	display: inline-block;
	border-radius: 100%;
	height: 80px;
	margin: 0 auto 20px auto;
	text-align: center;
	width: 80px;
	background-color: #000;
	font-size: 32px;
	color: #fff;
	line-height: 80px;
}
.client-sec-2 .box .content {
}
.client-sec-2 .box .content h4 {
	margin-bottom: 10px;
	font-weight: 600;
	color: #232323;
	font-size: 16px;
}
.client-sec-2 .box .content p {
	width: 75%;
	margin: 0 auto;
}
section.client-sec-3 {
}
.client-sec-3 .testimonial-content-box {
	position: relative;
	padding: 12%;
	border-radius: 6px;
	box-shadow: 0 0 3px rgb(0 0 0 / 20%);
	text-align: left;
	background-color: #fff;
	box-shadow: 0 5px 15px 3px rgb(17 21 23 / 10%);
}
.client-sec-3 .testimonial-content-box:after {
	border-top-color: #d6d5d5;
	left: 15%;
	border-width: 10px;
	margin-left: -10px;
	top: 100%;
	border: solid transparent;
	content: " ";
	height: 0;
	width: 0;
	position: absolute;
	pointer-events: none;
	border-color: rgba(245, 245, 245, 0);
	border-top-color: #ffffff;
	border-width: 15px;
	margin-left: -15px;
	z-index: 9;
}
.client-sec-3 .testimonial-author-box {
	padding: 25px;
}
.client-sec-3 .testimonial-author-box .image {
	width: 20%;
	display: table-cell;
	vertical-align: middle;
}
.client-sec-3 .testimonial-author-box .image img {
	border-radius: 100%;
	width: 62px;
	height: 62px;
}
.client-sec-3 .testimonial-author-box .name {
	display: table-cell;
	vertical-align: middle;
	padding-left: 20px;
}
.client-sec-3 .testimonial-author-box .name h5 {
	font-weight: 600;
	color: #232323;
}
.client-sec-3 .testimonial-author-box .name p {
	color: #939393;
	font-size: 12px;
}
.terms p a {
    color: blue;
}
.svgWidget + .svgHeading  { position: absolute; width: auto !important; top: 0px;transform: translateY(0%);word-break: break-all; }
.svgWidget + .svgHeading  { }
.svgWidget + .svgHeading  p {color: #000 ; text-align: center;}
.svgWidget + .svgHeading  h1, .svgWidget + .svgHeading  h2, .svgWidget + .svgHeading  h3, .svgWidget + .svgHeading  h4 {color: #000 ;text-align: center;}
.left-align + .svgHeading ,  .left-align p {text-align:left!important;padding-left: 20px; left:0px;}
.right-align + .svgHeading , .right-align p {text-align: right !important;padding-right: 20px; right:0px;}
.center-align + .svgHeading , .center-align p {text-align:center!important;left: 0px; right: 0px;}

.top + .svgHeading  {top: 10px !important;transform: translateY(0%)!important;}
.middle + .svgHeading  {top: 50%!important;transform: translateY(-50%)!important;}
.bottom + .svgHeading  {bottom: 22px!important;transform: translateY(0%)!important;top: auto;}
.svgHeading { background-color: transparent; height:auto; }
.svgHeadingInner {}


/*.text-slogan-logo {  position: absolute !important;transform: translateY(-50%);top: 50%; }}*/
.text-slogan-logo {position: relative !important; transform: translateY(0);}
.text-slogan-logo span {display: block;}
.text-slogan-logo span + span { margin-top: 0px;}


.logo_left {float:left;}

.logo_left.text-preview-image-left a img {float:left;}
.logo_left.text-preview-image-left #logoTextWrap {float:right;}

.logo_leftt.text-preview-image-right a img {float:right;}
.logo_left.text-preview-image-right #logoTextWrap {float:left;}

.logo_left.text-preview-image-center  {float:none; width:100%; margin:0px auto; text-align:center;}
.logo_left.text-preview-image-center #logoTextWrap{float:none; width:100%; margin:0px auto; text-align:center;}



/* .logo_right {float:right;} */

.logo_right.text-preview-image-left a img {float:right;}
.logo_right.text-preview-image-left #logoTextWrap {float:left;}

.logo_right.text-preview-image-right a img {float:left;}
.logo_right.text-preview-image-right #logoTextWrap {float:right;}

.logo_right.text-preview-image-center  {float:none; width:100%; margin:0px auto; text-align:center;
	display:block;}

.logo_right.text-preview-image-center #logoTextWrap
{float:none; width:100%; margin:0px auto; text-align:center; display:block;}


.logo_center {width: 100%; margin: 0px auto;text-align: center;}
.logo_center a {display:inline-block;}



.logo_center.text-preview-image-left a img {float:right;}
.logo_center.text-preview-image-left #logoTextWrap {float:left;}

.logo_center.text-preview-image-right a img {float:left;}
.logo_center.text-preview-image-right #logoTextWrap {float:right;}

.logo_center.text-preview-image-center  {float:none; width:100%; margin:0px auto; text-align:center;}
.logo_center.text-preview-image-center #logoTextWrap {float:none; width:100%; margin:0px auto; text-align:center;}

.logoWidget.logo a{display: inline-block;}

.logoWidget.logo-text-left.text-preview-image-right a img{float:left;}
.logoWidget.logo-text-left.text-preview-image-right a #logoTextWrap{float:right;}

.logoWidget.logo-text-right.text-preview-image-right a img{float:left;}
.logoWidget.logo-text-right.text-preview-image-right a #logoTextWrap{float:right;}

#logoTextWrap span {display: block; float:none;}
.container.boxWidget.img-text-case.logo_right#manageLogoPreviewMainDiv {float:none;}
#manageLogoPreviewMainDiv #logoAllSpansAnchor img.scale-with-grid { width: auto !important; }










/*New Form Widgets - START */
 /*** Widget (46) ***/

body .widget-form-06 .form-box {
    padding: 50px;
    background-color: #000;
    margin: 80px 0;
}

body.widget-form-06 form h2 {
    margin-bottom: 50px;
    color: #fff;
}

body .widget-form-06 form input, body .widget-form-06 form textarea {
    border: 1px solid #000;
	background-color:#fff;
    font-size: 14px;
    padding: 15px;
    margin-bottom: 15px;
    width: 100%;
    background-color: transparent;
    border-right: 0;
    border-left: 0;
    border-top: 0;
}
body .widget-form-06 form textarea {
    min-height: 187px;
}
body .widget-form-06 .item {
}
body .widget-form-06 .item .icon {
    background-color: transparent;
    color: #000;
    font-size: 36px;
    margin-bottom: 10px;
}
body .widget-form-06 .item .icon i.fa {
    top: 0;
    transform: translateY(0);
}
body .widget-form-06 .item-content {
}
body .widget-form-06 .item-content h4 {
    font-size: 20px;
    margin-bottom: 0;
}
body .widget-form-06 .item-content p {
    margin-bottom: 0;
}
body .widget-contact-info .item {
    position: relative;
    text-align: center;
    margin: 0px 0px 0px;
    padding: 85px 20px 80px;
    background-color: #FFF;
    box-shadow: 0px 0px 20px 0px rgba(0,0,0,0.1);
    font-size: 14px;
    font-weight: 500;
    line-height: 24px;
}

body .widget-contact-info .item .icon {
    background-color: transparent;
    color: #000;
    font-size: 40px;
    margin-bottom: 0;
    padding: 20px 0;
}

body .widget-contact-info .item h4 {
    margin-bottom: 0;
}

body .widget-contact-info .item .icon i.fa {
    top: 0;
    transform: translateY(0);
}
 body .widget-contact-info .item .item-content p {
    margin-bottom: 0;
}
@media (max-width: 768px) {
  body .widget-contact-info .item {margin-bottom:30px;}
}
/*** Widget (38) ***/

body .widget-form-03 .item {
    margin-bottom: 15px;
    text-align: center;
}
body .widget-form-03 .item .icon {
    margin: 0 auto;
    text-align: center;
    display: block;
    background-color: transparent;
    width: 50px;
    height: 50px;
    border-radius: 3px;
    /*color: #eb3824;*/
    font-size: 24px;
}
body .widget-form-03 .item .content {
    padding: 10px 0;
}
body .widget-form-03 .item:last-child {
    margin-bottom: 0;
}
body .widget-form-03 .form-box {
    border: 1px solid #dddddd;
    padding: 45px;
    border-radius: 10px;
    background-color: #fafafa;
}
body .widget-form-03 form input, .widget-form-03 form textarea {
    border: 1px solid #ccc;
    font-size: 14px;
    padding: 15px;
    margin-bottom: 15px;
    width: 100%;
    box-shadow: 0 2px 4px rgba(126,142,177,.12);
}
body .widget-form-03 form textarea {
    min-height: 187px;
}
@media only screen and (min-width: 768px) and (max-width: 1023px) {
body .widget-form-03 .item {
    width: 33.3%;
    float: left;
    padding-right: 15px;
    padding-left: 15px;
}
}


body  .widget-form-05.form-box {
    padding: 50px;
    background-color: #000;
    margin: 80px 0;
}
body .widget-form-05 form h2 {
    margin-bottom: 50px;
    color: #fff;
}

body .theme-button.wedgit-margin-bottom {margin-bottom:20px;}

body .widget-form-05 form input, .widget-form-05 form textarea {
    border: 1px solid #ccc;
    font-size: 14px;
    padding: 15px;
    margin-bottom: 15px;
    width: 100%;
    box-shadow: 0 2px 4px rgba(126,142,177,.12);
}
body .widget-form-05 form textarea {
    min-height: 187px;
}
.widget-form-05 .item {
}
body .widget-form-05 .item .icon {
    background-color: transparent;
    color: #000;
    font-size: 36px;
    margin-bottom: 10px;
	float: left;
    margin-right: 10px;
    height: 60px;
}
body .widget-form-05 .item .icon i.fa {
    top: 0;
    transform: translateY(0);
}
body .widget-form-05 .item-content {
}
/*body .widget-form-05 .item-content h1,
body .widget-form-05 .item-content h2,
body .widget-form-05 .item-content h3,
body .widget-form-05 .item-content h4,
body .widget-form-05 .item-content h5,
body .widget-form-05 .item-content h6,
body .widget-form-05 .item-content p,
body .widget-form-05 .item-content a
{
	color: #fff;
}*/
body .widget-form-05 .item-content h4
 {
    font-size: 20px;
    margin-bottom: 0;
}
body .widget-form-05 .item-content p {
    margin-bottom: 0;
}

/*New Form Widgets - END */
.logoWidget.logo a {    text-decoration: none;    cursor: pointer; }

.wb-header.logo_center .logo > a > img {
    max-height: none !important;
}
@media (max-width: 640px) {
	
.wb-page .centered-col {
	display:block;
	float: none;
}
}
/*slider3*/
body {
	margin: 0;
	padding: 0;
}
@-webkit-keyframes zoomIn {
 from {
 opacity: 0;
 -webkit-transform: scale3d(.3, .3, .3);
 transform:scale3d(.3, .3, .3);
}
 50% {
 opacity: 1;
}
}
 @keyframes zoomIn {
 from {
 opacity: 0;
 -webkit-transform: scale3d(.3, .3, .3);
 transform: scale3d(.3, .3, .3);
}
 50% {
 opacity: 1;
}
}
section.wb-slider {
	padding: 0;
	margin: 0;
}
section.wb-slider .carousel {
	width: 100%;
	height: 600px;
}
section.wb-slider .carousel .carousel-inner {
	position: relative;
}
section.wb-slider .carousel .carousel-inner .item {
	height: 600px;
}
section.wb-slider .carousel .carousel-inner .item img {
	width: 100%;
	height: 100%;
}
section.wb-slider .carousel .carousel-inner .item:before {
	content: '';
	width: 100%;
	height: 100%;
	background: #000;
	opacity: 0.5;
	position: absolute;
}
section.wb-slider .carousel .carousel-inner .item .carousel-caption {
	position: absolute;
	top: 50%;
	transform: translate(-50%, -50%);
	left: 50%;
	bottom: auto;
	z-index: 999;
	right: auto;
	padding: 0;
	text-shadow: none;
	text-align: center;
}
section.wb-slider .carousel .carousel-inner .item .carousel-caption h1 {
	font-size: 50px;
	font-weight: 900;
	margin-bottom: 10px;
	margin-top: 0;
	color: #fff;
}
section.wb-slider .carousel .carousel-inner .item .carousel-caption p {
	margin-bottom: 10px;
	margin-top: 0;
	font-weight: normal;
	font-size: 24px;
	color: #fff;
}
section.wb-slider .carousel .carousel-inner .item.active .carousel-caption a.slider-btn {
	background-color: #fff;
	padding: 13px 20px;
	border-radius: 3px;
	color: #000;
	font-size: 16px;
	font-weight: normal;
	text-transform: uppercase;
}
section.wb-slider .carousel .carousel-inner .item.active .carousel-caption h1, section.wb-slider .carousel .carousel-inner .item.active .carousel-caption h2, section.wb-slider .carousel .carousel-inner .item.active .carousel-caption h3, section.wb-slider .carousel .carousel-inner .item.active .carousel-caption h4, section.wb-slider .carousel .carousel-inner .item.active .carousel-caption h5, section.wb-slider .carousel .carousel-inner .item.active .carousel-caption h6, section.wb-slider .carousel .carousel-inner .item.active .carousel-caption p, section.wb-slider .carousel .carousel-inner .item.active .carousel-caption p a.slider-btn {
	-webkit-animation-delay: .4s;
	animation-delay: .4s;
	-webkit-animation-duration: .6s;
	animation-duration: .6s;
	-webkit-animation-fill-mode: both;
	animation-fill-mode: both;
	-webkit-animation-name: fadeInUp;
	animation-name: fadeInUp;
}
section.wb-slider .carousel .carousel-inner .item.active .carousel-caption h1 {
	-webkit-animation-delay: .5s;
	animation-delay: .5s;
}
section.wb-slider .carousel .carousel-inner .item.active .carousel-caption p {
	-webkit-animation-delay: .6s;
	animation-delay: .6s;
}
section.wb-slider .carousel .carousel-inner .item.active .carousel-caption p a.slider-btn {
	-webkit-animation-delay: .7s;
	animation-delay: .7s;
}
section.wb-slider .carousel .carousel-inner .item.active .caption-effect-1 {
	-webkit-animation-delay: .4s;
	animation-delay: .4s;
	-webkit-animation-duration: .6s;
	animation-duration: .6s;
	-webkit-animation-fill-mode: both;
	animation-fill-mode: both;
	-webkit-animation-name: zoomIn;
	animation-name: zoomIn;
}
section.wb-slider .carousel-indicators li, section.wb-slider .carousel-indicators li.active {
	width: 50px;
	height: 6px;
	border-radius: 0;
	margin: 2px;
	background-color: #919191;
	border: 0;
}
section.wb-slider .carousel-indicators li.active {
	background-color: #fff;
}
.carousel-fade .carousel-inner .item {
	opacity: 0;
	-webkit-transition-property: opacity;
	-moz-transition-property: opacity;
	-o-transition-property: opacity;
	transition-property: opacity;
}
.carousel-fade .carousel-inner .active {
	opacity: 1;
}
.carousel-fade .carousel-inner .active.left, .carousel-fade .carousel-inner .active.right {
	left: 0;
	opacity: 0;
	z-index: 1;
}
.carousel-fade .carousel-inner .next.left, .carousel-fade .carousel-inner .prev.right {
	opacity: 1;
}
.carousel-fade .carousel-control {
	z-index: 2;
}
/*** slider caption styles ***/
section.wb-slider .carousel.sliderStyle3 .carousel-inner .item .carousel-caption {
	background-color: rgba(255,255,255,0.7);
	padding: 50px 20px;
	width: 50%;
	border-radius: 4px;
	-webkit-box-shadow: 0 10px 6px -6px #777;
	-moz-box-shadow: 0 10px 6px -6px #777;
	box-shadow: 0 0 12px -6px #000;
}
/*** slider control styles ***/
.carousel.slider-control-1 .carousel-indicators li {
	width: 50px;
	height: 6px;
	border-radius: 3px;
	margin: 2px;
	background-color: #ffffff;
	border: 0;
	transition: background-color 0.5s ease;
}
.carousel.slider-control-1 .carousel-indicators li.active {
	opacity: 0.5;
	border-radius: 3px;
	background-color: #9f9f9f;
	transition: background-color 0.5s ease;
}
.carousel.slider-control-1 .carousel-control.left, .carousel.slider-control-1.carousel-control.right {
	background: none;
}
.carousel.slider-control-1 .carousel-control:hover, .carousel.slider-control-1 .carousel-control:focus {
	color: #fff;
	text-decoration: none;
	filter: alpha(opacity=90);
	outline: 0;
	opacity: .9;
}
.carousel.slider-control-1 .carousel-control.right {
	right: 2%;
}
.carousel.slider-control-1 .carousel-control.left {
	left: 2%;
}
.carousel.slider-control-1 .carousel-control {
	position: absolute;
	top: 50%;
	bottom: 0;
	left: 0;
	width: 60px;
	font-size: 20px;
	color: #fff;
	text-align: center;
	text-shadow: 0 1px 2px rgba(0,0,0,.6);
	background-color: rgba(0,0,0,0);
	filter: alpha(opacity=50);
	opacity: 1;
	height: 60px;
	transform: translateY(-50%);
}
.carousel.slider-control-1 .carousel-control.right {
	left: auto;
}
.carousel.slider-control-1 a.right.carousel-control, .carousel.slider-control-1 a.left.carousel-control {
	border: 1px solid #fff;
	background-color: transparent;
	transition: background-color 0.5s ease;
}
.carousel.slider-control-1 a.right.carousel-control:hover, .carousel.slider-control-1 a.left.carousel-control:hover {
	border: 1px solid transparent;
	background-color: #fff;
	transition: background-color 0.5s ease;
}
.carousel.slider-control-1 a.right.carousel-control:hover span.fa, .carousel.slider-control-1 a.left.carousel-control:hover span.fa {
	color: #013861 !important;
}
.carousel.slider-control-1 a.right.carousel-control span.fa, .carousel.slider-control-1 a.left.carousel-control span.fa {
	background-color: transparent;
	margin: 0;
	border-radius: 0;
	line-height: 60px;
	position: static;
	width: auto;
	font-size: 30px;
	height: auto;
	transition: background-color 0.5s ease;
}
